from __future__ import annotations

import argparse
import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, Response

from server.audio import INTERNAL_SAMPLE_RATE, normalize_pcm_bytes, pcm_duration_ms
from server.engine import BackendError, InferenceWorker
from server.hotwords import MISSING, ParsedHotwords, summarize_hotwords
from server.logging_utils import configure_logging, log_event
from server.protocol import (
    ProtocolError,
    format_response,
    is_heartbeat,
    parse_init_message,
    parse_hotwords_value,
    parse_json_text,
    RUNTIME_CONTROL_KEYS,
    sentence_response_mode,
    streaming_response_mode,
)
from server.runtime import prepare_runtime_environment
from server.settings import AppSettings, SessionConfig
from server.vad import SilenceState, create_vad, process_vad_frame


LOGGER = logging.getLogger(__name__)
ACCESS_LOGGER = logging.getLogger("access")
MAX_LOG_TEXT_CHARS = 200
FAVICON_SVG = (
    "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'>"
    "<rect width='64' height='64' rx='14' fill='#121212'/>"
    "<path d='M16 18h18c9 0 15 5.83 15 14s-6 14-15 14h-8v10H16V18z' fill='#f5f1e8'/>"
    "<path d='M26 26v12h8c4.47 0 7-2.21 7-6s-2.53-6-7-6h-8z' fill='#cb4d2a'/>"
    "</svg>"
)


@dataclass(slots=True)
class ConnectionState:
    session_id: str
    config: SessionConfig
    byte_buffer: bytearray = field(default_factory=bytearray)
    vad_buffer: bytearray = field(default_factory=bytearray)
    segment_active: bool = False
    last_partial_text: str = ""
    silence_state: SilenceState = field(default_factory=SilenceState)
    last_activity_at: float = field(default_factory=time.time)
    total_segment_ms: int = 0
    vad: object | None = None
    segments_completed: int = 0
    pending_final_ack: bool = False
    pending_final_text: str = ""

    @property
    def step_bytes(self) -> int:
        return INTERNAL_SAMPLE_RATE * self.config.step_ms // 1000 * 2


def compact_text(value: str | None, limit: int = MAX_LOG_TEXT_CHARS) -> str:
    if not value:
        return ""
    compact = " ".join(value.split())
    if len(compact) <= limit:
        return compact
    return f"{compact[: limit - 3]}..."


def session_log_context(state: ConnectionState | None) -> dict[str, Any]:
    if state is None:
        return {}
    return {
        "session_id": state.session_id,
        "wav_name": state.config.wav_name,
        "mode": state.config.mode,
        "segment_index": state.segments_completed + 1,
    }


def init_payload_summary(payload: dict[str, Any]) -> dict[str, Any]:
    turn_detection = payload.get("turn_detection")
    turn_detection_summary: dict[str, Any] | None = None
    hotword_summary = summarize_hotwords(
        payload["hotwords"] if "hotwords" in payload else MISSING
    )
    if isinstance(turn_detection, dict):
        turn_detection_summary = {
            "type": turn_detection.get("type"),
            "silence_duration_ms": turn_detection.get("silence_duration_ms"),
            "max_segment_ms": turn_detection.get("max_segment_ms"),
            "aggressiveness": turn_detection.get("aggressiveness"),
        }
    return {
        "mode": payload.get("mode"),
        "wav_name": payload.get("wav_name"),
        "wav_format": payload.get("wav_format"),
        "audio_fs": payload.get("audio_fs"),
        "chunk_size": payload.get("chunk_size"),
        "itn": payload.get("itn"),
        "has_hotwords": hotword_summary["has_hotwords"],
        "hotword_count": hotword_summary["hotword_count"],
        "hotword_terms_preview": hotword_summary["hotword_terms_preview"],
        "hotwords_error": hotword_summary.get("hotwords_error"),
        "turn_detection": turn_detection_summary,
    }


def outbound_payload_summary(payload: dict[str, Any]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "event": payload.get("event"),
        "code": payload.get("code"),
        "mode": payload.get("mode"),
        "wav_name": payload.get("wav_name"),
        "is_final": payload.get("is_final"),
    }
    if "message" in payload:
        message = str(payload.get("message") or "")
        summary["message"] = compact_text(message)
        summary["message_len"] = len(message)
    if "text" in payload:
        text = str(payload.get("text") or "")
        summary["text"] = compact_text(text)
        summary["text_len"] = len(text)
    return summary


def hotword_summary_fields(parsed_hotwords: ParsedHotwords) -> dict[str, Any]:
    return {
        "hotwords_present": bool(parsed_hotwords.terms),
        "hotword_count": len(parsed_hotwords.terms),
        "hotword_terms_preview": list(parsed_hotwords.terms[:3]),
    }


def pcm_byte_duration_ms(byte_count: int, sample_rate: int = INTERNAL_SAMPLE_RATE) -> int:
    sample_count = byte_count // 2
    return int(round((sample_count / float(sample_rate)) * 1000.0))


def buffered_segment_ms(state: ConnectionState) -> int:
    pending_bytes = len(state.byte_buffer) + len(state.vad_buffer)
    return state.total_segment_ms + pcm_byte_duration_ms(pending_bytes)


def should_auto_finalize(state: ConnectionState) -> bool:
    if state.vad is None:
        return False
    if (
        state.silence_state.speech_detected
        and state.silence_state.consecutive_silence_ms
        >= state.config.turn_detection.silence_duration_ms
    ):
        return True
    return buffered_segment_ms(state) >= state.config.turn_detection.max_segment_ms


async def emit_streaming_result(
    websocket: WebSocket,
    state: ConnectionState,
    text: str,
) -> None:
    if (
        not state.config.streaming_enabled
        or not text
        or text == state.last_partial_text
    ):
        return
    state.last_partial_text = text
    payload = format_response(
        state.config.wav_name,
        text,
        is_final=False,
        mode=streaming_response_mode(state.config.mode),
    )
    log_outbound_payload("ws_partial_sent", payload, state=state)
    await websocket.send_json(payload)


async def emit_sentence_result(
    websocket: WebSocket,
    state: ConnectionState,
    text: str,
    *,
    is_final: bool = False,
) -> None:
    if not text and not is_final:
        return
    payload = format_response(
        state.config.wav_name,
        text,
        is_final=is_final,
        mode=sentence_response_mode(state.config.mode),
    )
    log_outbound_payload("ws_sentence_sent", payload, state=state)
    await websocket.send_json(payload)


async def emit_pending_final_ack(
    websocket: WebSocket,
    state: ConnectionState,
) -> bool:
    if not state.pending_final_ack:
        return False
    await emit_sentence_result(websocket, state, state.pending_final_text, is_final=True)
    state.pending_final_ack = False
    state.pending_final_text = ""
    return True


def log_outbound_payload(
    event_name: str,
    payload: dict[str, Any],
    state: ConnectionState | None = None,
    level: int = logging.INFO,
) -> None:
    LOGGER.log(
        level,
        event_name,
        extra={
            "extra_data": {
                **session_log_context(state),
                "payload": outbound_payload_summary(payload),
            }
        },
    )


def create_app(
    settings: AppSettings | None = None,
    backend_factory=None,
) -> FastAPI:
    app_settings = settings or AppSettings()
    configure_logging(app_settings)
    worker = InferenceWorker(app_settings, backend_factory=backend_factory)
    app = FastAPI(title="Qwen3-ASR WebSocket Service")
    app.state.settings = app_settings
    app.state.worker = worker
    app.state.active_connections = 0
    app.state.completed_segments = 0
    app.state.rejected_sessions = 0
    app.state.error_count = 0

    @app.on_event("startup")
    async def startup() -> None:
        runtime_info = prepare_runtime_environment(app_settings.asr_backend)
        app.state.runtime_info = runtime_info
        await worker.start()
        log_event(
            LOGGER,
            "service_started",
            model_path=app_settings.model_path,
            port=app_settings.port,
            **runtime_info.as_log_fields(),
        )

    @app.on_event("shutdown")
    async def shutdown() -> None:
        await worker.stop()
        log_event(LOGGER, "service_stopped")

    @app.get("/", response_class=HTMLResponse)
    async def index() -> HTMLResponse:
        frontend_path = app_settings.frontend_path
        if frontend_path.exists():
            return HTMLResponse(frontend_path.read_text(encoding="utf-8"))
        return HTMLResponse("<h1>Qwen3-ASR service is running.</h1>")

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon() -> Response:
        return Response(
            content=FAVICON_SVG,
            media_type="image/svg+xml",
            headers={"Cache-Control": "public, max-age=86400"},
        )

    @app.get("/healthz")
    @app.get("/ready")
    async def healthz() -> JSONResponse:
        return JSONResponse(
            {
                "status": "ok",
                "active_connections": app.state.active_connections,
                "completed_segments": app.state.completed_segments,
                "max_sessions": app_settings.default_max_sessions,
            }
        )

    @app.get("/metrics")
    async def metrics() -> JSONResponse:
        engine_metrics = await worker.metrics()
        return JSONResponse(
            {
                "active_connections": app.state.active_connections,
                "completed_segments": app.state.completed_segments,
                "rejected_sessions": app.state.rejected_sessions,
                "errors": app.state.error_count,
                "engine": engine_metrics,
            }
        )

    @app.websocket("/ws/asr")
    async def websocket_asr(websocket: WebSocket) -> None:
        await websocket.accept()
        app.state.active_connections += 1
        session_state: ConnectionState | None = None
        try:
            if app.state.active_connections > app_settings.default_max_sessions:
                app.state.rejected_sessions += 1
                await send_error(
                    websocket,
                    "MAX_SESSIONS",
                    "max sessions reached",
                    close_code=1013,
                )
                return
            session_state = await receive_init(websocket, worker, app_settings)
            ACCESS_LOGGER.info(
                "session_connected",
                extra={
                    "extra_data": {
                        "session_id": session_state.session_id,
                        "wav_name": session_state.config.wav_name,
                        "mode": session_state.config.mode,
                    }
                },
            )
            while True:
                try:
                    message = await asyncio.wait_for(
                        websocket.receive(),
                        timeout=app_settings.connection_idle_timeout_sec,
                    )
                except asyncio.TimeoutError:
                    LOGGER.warning(
                        "connection_idle_timeout",
                        extra={"extra_data": session_log_context(session_state)},
                    )
                    await send_error(
                        websocket,
                        "IDLE_TIMEOUT",
                        "connection idle timeout",
                        close_code=1000,
                        state=session_state,
                    )
                    return
                if message.get("type") == "websocket.disconnect":
                    break
                if "text" in message:
                    text = message["text"]
                    if is_heartbeat(text):
                        log_event(LOGGER, "heartbeat_echo", **session_log_context(session_state))
                        await websocket.send_text("HeartBeat")
                        continue
                    payload = parse_json_text(text)
                    if not payload:
                        raise ProtocolError(
                            "UNEXPECTED_TEXT",
                            "only hotwords updates and is_speaking control are allowed after init",
                        )
                    unexpected_keys = set(payload) - RUNTIME_CONTROL_KEYS
                    if unexpected_keys:
                        raise ProtocolError(
                            "UNEXPECTED_TEXT",
                            "only hotwords updates and is_speaking control are allowed after init",
                        )
                    hotwords_updated = False
                    if "hotwords" in payload:
                        parsed_hotwords = parse_hotwords_value(payload["hotwords"])
                        log_event(
                            LOGGER,
                            "hotwords_update_received",
                            **session_log_context(session_state),
                            **hotword_summary_fields(parsed_hotwords),
                        )
                        await worker.update_hotwords(
                            session_state.session_id,
                            parsed_hotwords,
                        )
                        hotwords_updated = True
                    if payload.get("is_speaking") is False:
                        log_event(
                            LOGGER,
                            "segment_end_received",
                            **session_log_context(session_state),
                            payload={"is_speaking": False},
                        )
                        segment_finalized = await finalize_segment_and_emit(
                            websocket,
                            worker,
                            session_state,
                            is_final=True,
                        )
                        if not segment_finalized:
                            segment_finalized = await emit_pending_final_ack(
                                websocket,
                                session_state,
                            )
                        if not segment_finalized:
                            log_event(
                                LOGGER,
                                "segment_end_ignored",
                                **session_log_context(session_state),
                            )
                        session_state.last_activity_at = time.time()
                        continue
                    if hotwords_updated or payload.get("is_speaking") is True:
                        session_state.last_activity_at = time.time()
                        continue
                    raise ProtocolError(
                        "UNEXPECTED_TEXT",
                        "only hotwords updates and is_speaking control are allowed after init",
                    )
                if "bytes" in message:
                    audio_bytes = message["bytes"] or b""
                    if not audio_bytes:
                        continue
                    await handle_audio(websocket, worker, session_state, audio_bytes)
                    continue
        except WebSocketDisconnect:
            pass
        except ProtocolError as exc:
            app.state.error_count += 1
            LOGGER.warning(
                "websocket_protocol_error",
                extra={
                    "extra_data": {
                        **session_log_context(session_state),
                        "error_code": exc.code,
                        "message": exc.message,
                    }
                },
            )
            await send_error(
                websocket,
                exc.code,
                exc.message,
                close_code=1008,
                state=session_state,
            )
        except BackendError as exc:
            app.state.error_count += 1
            LOGGER.error(
                "websocket_backend_error",
                extra={
                    "extra_data": {
                        **session_log_context(session_state),
                        "message": str(exc),
                    }
                },
            )
            await send_error(
                websocket,
                "BACKEND_ERROR",
                str(exc),
                close_code=1011,
                state=session_state,
                level=logging.ERROR,
            )
        except Exception as exc:
            app.state.error_count += 1
            LOGGER.exception(
                "unhandled_websocket_error",
                extra={"extra_data": session_log_context(session_state)},
            )
            try:
                await send_error(
                    websocket,
                    "INTERNAL_ERROR",
                    str(exc),
                    close_code=1011,
                    state=session_state,
                    level=logging.ERROR,
                )
            except Exception:
                pass
        finally:
            app.state.active_connections = max(0, app.state.active_connections - 1)
            if session_state is not None:
                await worker.close_session(session_state.session_id)
                ACCESS_LOGGER.info(
                    "session_disconnected",
                    extra={
                        "extra_data": {
                            "session_id": session_state.session_id,
                            "wav_name": session_state.config.wav_name,
                            "mode": session_state.config.mode,
                            "segments_completed": session_state.segments_completed,
                        }
                    },
                )
                log_event(
                    LOGGER,
                    "session_closed",
                    session_id=session_state.session_id,
                    wav_name=session_state.config.wav_name,
                    segments_completed=session_state.segments_completed,
                )

    return app


async def receive_init(
    websocket: WebSocket,
    worker: InferenceWorker,
    settings: AppSettings,
) -> ConnectionState:
    raw_message = await asyncio.wait_for(
        websocket.receive_text(), timeout=settings.connection_idle_timeout_sec
    )
    if is_heartbeat(raw_message):
        await websocket.send_text("HeartBeat")
        raw_message = await asyncio.wait_for(
            websocket.receive_text(), timeout=settings.connection_idle_timeout_sec
        )
    payload = parse_json_text(raw_message)
    log_event(LOGGER, "init_message_received", payload=init_payload_summary(payload))
    config = parse_init_message(raw_message)
    unsupported_mode_reason = worker.unsupported_mode_reason(config)
    if unsupported_mode_reason is not None:
        raise ProtocolError("UNSUPPORTED_MODE", unsupported_mode_reason)
    session_id = uuid.uuid4().hex
    await worker.open_session(session_id, config)
    connection = ConnectionState(session_id=session_id, config=config)
    if config.turn_detection.enabled:
        connection.vad = create_vad(config.turn_detection.aggressiveness)
    log_event(
        LOGGER,
        "session_initialized",
        session_id=session_id,
        wav_name=config.wav_name,
        mode=config.mode,
        audio_fs=config.audio_fs,
        chunk_size=config.chunk_size,
        hotwords_present=bool(config.hotword_terms),
        hotword_count=len(config.hotword_terms),
        hotword_terms_preview=list(config.hotword_terms[:3]),
        turn_detection={
            "enabled": config.turn_detection.enabled,
            "silence_duration_ms": config.turn_detection.silence_duration_ms,
            "max_segment_ms": config.turn_detection.max_segment_ms,
            "aggressiveness": config.turn_detection.aggressiveness,
        },
    )
    return connection


async def handle_audio(
    websocket: WebSocket,
    worker: InferenceWorker,
    state: ConnectionState,
    audio_bytes: bytes,
) -> None:
    app = websocket.scope["app"]
    normalized_bytes = normalize_pcm_bytes(audio_bytes, state.config.audio_fs)
    if not normalized_bytes:
        return
    projected_buffer_bytes = len(state.byte_buffer) + len(state.vad_buffer) + len(normalized_bytes)
    projected_buffer_ms = pcm_byte_duration_ms(projected_buffer_bytes)
    if projected_buffer_ms > app.state.settings.max_buffer_ms:
        raise ProtocolError("BUFFER_OVERFLOW", "client is sending audio faster than the server can consume")
    state.last_activity_at = time.time()
    if state.vad is None:
        await buffer_audio_for_segment(websocket, worker, state, normalized_bytes)
        return
    pending_vad_audio = bytes(state.vad_buffer) + normalized_bytes
    state.vad_buffer.clear()
    while len(pending_vad_audio) >= state.vad.frame_bytes:
        frame = pending_vad_audio[: state.vad.frame_bytes]
        pending_vad_audio = pending_vad_audio[state.vad.frame_bytes :]
        has_speech = process_vad_frame(state.vad, state.silence_state, frame)
        if state.silence_state.speech_detected or has_speech:
            await buffer_audio_for_segment(websocket, worker, state, frame)
        if should_auto_finalize(state):
            log_event(
                LOGGER,
                "segment_auto_finalize_triggered",
                **session_log_context(state),
                silence_ms=state.silence_state.consecutive_silence_ms,
                total_segment_ms=buffered_segment_ms(state),
            )
            await finalize_segment_and_emit(websocket, worker, state)
    state.vad_buffer.extend(pending_vad_audio)


async def buffer_audio_for_segment(
    websocket: WebSocket,
    worker: InferenceWorker,
    state: ConnectionState,
    audio_bytes: bytes,
) -> None:
    if not audio_bytes:
        return
    state.segment_active = True
    state.byte_buffer.extend(audio_bytes)
    while len(state.byte_buffer) >= state.step_bytes:
        chunk = bytes(state.byte_buffer[: state.step_bytes])
        del state.byte_buffer[: state.step_bytes]
        await process_chunk(websocket, worker, state, chunk)


async def process_chunk(
    websocket: WebSocket,
    worker: InferenceWorker,
    state: ConnectionState,
    chunk: bytes,
) -> None:
    state.total_segment_ms += pcm_duration_ms(chunk)
    chunk_index = max(1, state.total_segment_ms // state.config.step_ms)
    log_event(
        LOGGER,
        "audio_chunk_processed",
        **session_log_context(state),
        chunk_index=int(chunk_index),
        chunk_bytes=len(chunk),
        chunk_ms=pcm_duration_ms(chunk),
        buffered_segment_ms=state.total_segment_ms,
    )
    result = await worker.process_stream_chunk(state.session_id, chunk)
    await emit_streaming_result(websocket, state, result.text)


async def finalize_segment_and_emit(
    websocket: WebSocket,
    worker: InferenceWorker,
    state: ConnectionState,
    *,
    is_final: bool = False,
) -> bool:
    app = websocket.scope["app"]
    if not state.segment_active:
        state.byte_buffer.clear()
        state.vad_buffer.clear()
        return False
    if state.vad_buffer:
        state.byte_buffer.extend(state.vad_buffer)
        state.vad_buffer.clear()
    if state.byte_buffer:
        chunk = bytes(state.byte_buffer)
        state.byte_buffer.clear()
        state.total_segment_ms += pcm_duration_ms(chunk)
        log_event(
            LOGGER,
            "segment_tail_flushed",
            **session_log_context(state),
            chunk_bytes=len(chunk),
            chunk_ms=pcm_duration_ms(chunk),
            buffered_segment_ms=state.total_segment_ms,
        )
        result = await worker.process_stream_chunk(state.session_id, chunk)
        await emit_streaming_result(websocket, state, result.text)
    final_result = await worker.finalize_segment(state.session_id)
    await emit_sentence_result(websocket, state, final_result.text, is_final=is_final)
    state.pending_final_ack = not is_final
    # When the server has already emitted the sentence for an auto-finalized
    # segment, the later client-side segment end should only acknowledge it.
    state.pending_final_text = ""
    state.segment_active = False
    state.total_segment_ms = 0
    state.last_partial_text = ""
    state.vad_buffer.clear()
    state.silence_state = SilenceState()
    state.segments_completed += 1
    app.state.completed_segments += 1
    return True


async def send_error(
    websocket: WebSocket,
    code: str,
    message: str,
    close_code: int,
    state: ConnectionState | None = None,
    level: int = logging.WARNING,
) -> None:
    payload = {"event": "error", "code": code, "message": message}
    log_outbound_payload("ws_error_sent", payload, state=state, level=level)
    await websocket.send_json(payload)
    await websocket.close(code=close_code)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Qwen3-ASR WebSocket server.")
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    args = parser.parse_args()

    settings = AppSettings()
    if args.host:
        settings.host = args.host
    if args.port:
        settings.port = args.port

    import uvicorn

    uvicorn.run(create_app(settings=settings), host=settings.host, port=settings.port)


app = create_app()


if __name__ == "__main__":
    main()
