from __future__ import annotations

import argparse
import json
import sys

from server.runtime import (
    prepare_runtime_environment,
    validate_installed_package_versions,
    validate_runtime_configuration,
    RuntimeValidationError,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate the configured ASR runtime.")
    parser.add_argument(
        "--allow-no-gpu",
        action="store_true",
        help="Skip the CUDA GPU availability check. Intended for image build-time validation.",
    )
    args = parser.parse_args()

    try:
        validate_installed_package_versions()
        info = prepare_runtime_environment()
        validate_runtime_configuration(info, allow_no_gpu=args.allow_no_gpu)
    except RuntimeValidationError as exc:
        print(f"runtime_check_failed: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    print(json.dumps(info.as_log_fields(), ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
