from __future__ import annotations

import logging
from pathlib import Path

from server.logging_utils import configure_logging, log_event
from server.settings import AppSettings


def flush_handlers(logger: logging.Logger) -> None:
    for handler in logger.handlers:
        handler.flush()


def test_configure_logging_writes_warnings_to_error_log(tmp_path: Path) -> None:
    root = logging.getLogger()
    original_root_handlers = list(root.handlers)
    original_root_level = root.level
    access_logger = logging.getLogger("access")
    original_access_handlers = list(access_logger.handlers)
    original_access_level = access_logger.level
    original_access_propagate = access_logger.propagate

    try:
        settings = AppSettings(
            logs_dir=tmp_path,
            frontend_path=AppSettings().frontend_path,
            warmup_enabled=False,
        )
        configure_logging(settings)

        logger = logging.getLogger("tests.logging")
        log_event(logger, "service_info", session_id="sess-1", text="你好，世界")
        logger.warning("service_warning", extra={"extra_data": {"session_id": "sess-1"}})

        flush_handlers(root)
        flush_handlers(access_logger)

        service_log = next(tmp_path.glob("service_*.log")).read_text(encoding="utf-8")
        error_log = next(tmp_path.glob("error_*.log")).read_text(encoding="utf-8")

        assert "service_info" in service_log
        assert "service_warning" in service_log
        assert "service_warning" in error_log
        assert "service_info" not in error_log
        assert "你好，世界" in service_log
        assert "\\u4f60\\u597d" not in service_log
    finally:
        for handler in root.handlers:
            handler.close()
        for handler in access_logger.handlers:
            handler.close()
        root.handlers = original_root_handlers
        root.setLevel(original_root_level)
        access_logger.handlers = original_access_handlers
        access_logger.setLevel(original_access_level)
        access_logger.propagate = original_access_propagate
