from __future__ import annotations

import types

import pytest

from server import runtime


class FakeCuda:
    def __init__(
        self,
        *,
        available: bool = True,
        name: str = "Tesla V100-SXM2-32GB",
        capability: tuple[int, int] = (7, 0),
    ) -> None:
        self._available = available
        self._name = name
        self._capability = capability

    def is_available(self) -> bool:
        return self._available

    def device_count(self) -> int:
        return 1 if self._available else 0

    def get_device_name(self, index: int) -> str:  # noqa: ARG002
        return self._name

    def get_device_capability(self, index: int) -> tuple[int, int]:  # noqa: ARG002
        return self._capability


def fake_torch(
    *,
    available: bool = True,
    name: str = "Tesla V100-SXM2-32GB",
    capability: tuple[int, int] = (7, 0),
    cuda_version: str = "12.8",
):
    return types.SimpleNamespace(
        cuda=FakeCuda(available=available, name=name, capability=capability),
        version=types.SimpleNamespace(cuda=cuda_version),
    )


def fake_completed_process(stdout: str, returncode: int = 0):
    return types.SimpleNamespace(stdout=stdout, returncode=returncode)


def test_validate_installed_package_versions_accepts_supported_baseline(monkeypatch) -> None:
    monkeypatch.setattr(runtime, "version", lambda package: runtime.VLLM_RUNTIME_PACKAGES[package])

    resolved = runtime.validate_installed_package_versions("vllm")

    assert resolved == runtime.VLLM_RUNTIME_PACKAGES


def test_validate_installed_package_versions_accepts_transformers_without_vllm(
    monkeypatch,
) -> None:
    monkeypatch.setattr(
        runtime,
        "version",
        lambda package: runtime.TRANSFORMERS_RUNTIME_PACKAGES[package],
    )

    resolved = runtime.validate_installed_package_versions("transformers")

    assert resolved == runtime.TRANSFORMERS_RUNTIME_PACKAGES


def test_validate_installed_package_versions_rejects_mismatch(monkeypatch) -> None:
    def fake_version(package: str) -> str:
        if package == "torch":
            return "2.8.0"
        return runtime.VLLM_RUNTIME_PACKAGES[package]

    monkeypatch.setattr(runtime, "version", fake_version)

    with pytest.raises(runtime.RuntimeValidationError, match="supported vllm baseline: torch=2.8.0"):
        runtime.validate_installed_package_versions("vllm")


def test_prepare_runtime_environment_defaults_to_sdpa_for_v100(monkeypatch) -> None:
    monkeypatch.setattr(runtime.importlib, "import_module", lambda name: fake_torch() if name == "torch" else None)
    monkeypatch.setattr(
        runtime.subprocess,
        "run",
        lambda *args, **kwargs: fake_completed_process(
            "| NVIDIA-SMI 535.129.03 Driver Version: 535.129.03 CUDA Version: 12.2 |"
        ),
    )
    monkeypatch.delenv("VLLM_ATTENTION_BACKEND", raising=False)
    monkeypatch.delenv("VLLM_USE_FLASHINFER_SAMPLER", raising=False)

    info = runtime.prepare_runtime_environment("vllm")

    assert info.asr_backend == "vllm"
    assert info.host_driver_version == "535.129.03"
    assert info.host_cuda_version == "12.2"
    assert info.gpu_name == "Tesla V100-SXM2-32GB"
    assert info.capability == "7.0"
    assert info.attention_backend == "TORCH_SDPA"
    assert info.attention_backend_source == "auto_v100_compat"
    assert info.flashinfer_sampler == "0"
    assert info.flashinfer_sampler_source == "auto_v100_compat"


def test_prepare_runtime_environment_preserves_explicit_backend(monkeypatch) -> None:
    monkeypatch.setattr(runtime.importlib, "import_module", lambda name: fake_torch() if name == "torch" else None)
    monkeypatch.setattr(runtime.subprocess, "run", lambda *args, **kwargs: fake_completed_process(""))
    monkeypatch.setenv("VLLM_ATTENTION_BACKEND", "FLASH_ATTN")
    monkeypatch.setenv("VLLM_USE_FLASHINFER_SAMPLER", "1")

    info = runtime.prepare_runtime_environment("vllm")

    assert info.attention_backend == "FLASH_ATTN"
    assert info.attention_backend_source == "env"
    assert info.flashinfer_sampler == "1"
    assert info.flashinfer_sampler_source == "env"


def test_prepare_runtime_environment_skips_vllm_tuning_for_transformers(monkeypatch) -> None:
    monkeypatch.setattr(runtime.importlib, "import_module", lambda name: fake_torch() if name == "torch" else None)
    monkeypatch.setattr(runtime.subprocess, "run", lambda *args, **kwargs: fake_completed_process(""))
    monkeypatch.delenv("VLLM_ATTENTION_BACKEND", raising=False)
    monkeypatch.delenv("VLLM_USE_FLASHINFER_SAMPLER", raising=False)

    info = runtime.prepare_runtime_environment("transformers")

    assert info.asr_backend == "transformers"
    assert info.attention_backend is None
    assert info.flashinfer_sampler is None


def test_validate_runtime_configuration_rejects_unsafe_v100_backend() -> None:
    info = runtime.RuntimeInfo(
        python_version="3.12.0",
        asr_backend="vllm",
        torch_available=True,
        gpu_available=True,
        gpu_name="Tesla V100-SXM2-32GB",
        capability_major=7,
        capability_minor=0,
        attention_backend="FLASH_ATTN",
        flashinfer_sampler="1",
    )

    with pytest.raises(runtime.RuntimeValidationError, match="VLLM_ATTENTION_BACKEND=TORCH_SDPA"):
        runtime.validate_runtime_configuration(info)


def test_query_host_nvidia_smi_returns_none_when_unavailable(monkeypatch) -> None:
    monkeypatch.setattr(runtime.subprocess, "run", lambda *args, **kwargs: (_ for _ in ()).throw(FileNotFoundError()))

    info = runtime.query_host_nvidia_smi()

    assert info == {"host_driver_version": None, "host_cuda_version": None}


def test_validate_runtime_configuration_allows_no_gpu_when_requested() -> None:
    info = runtime.RuntimeInfo(
        python_version="3.12.0",
        asr_backend="transformers",
        torch_available=True,
        gpu_available=False,
    )

    runtime.validate_runtime_configuration(info, allow_no_gpu=True)
