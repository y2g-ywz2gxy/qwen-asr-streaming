from __future__ import annotations

import asyncio
import sys
import time
import types

import numpy as np

from server.engine import (
    EngineSession,
    EngineTask,
    InferenceWorker,
    QwenBackend,
    StreamResult,
    TransformersQwenBackend,
    build_backend,
)
from server.hotwords import build_hotword_context
from server.settings import AppSettings, SessionConfig


class DummyModelResult:
    def __init__(self, text: str, language: str):
        self.text = text
        self.language = language


class DummyOfflineModel:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def transcribe(
        self,
        *,
        audio: object,
        context: str,
        return_time_stamps: bool = False,
    ):
        self.calls.append(
            {
                "audio": audio,
                "context": context,
                "return_time_stamps": return_time_stamps,
            }
        )
        if isinstance(audio, list):
            return [DummyModelResult("offline text", "zh") for _ in audio]
        return [DummyModelResult("offline text", "zh")]


class DummyStreamingModel:
    def __init__(self) -> None:
        self.init_calls: list[dict[str, object]] = []

    def init_streaming_state(self, **kwargs: object):
        self.init_calls.append(kwargs)
        return types.SimpleNamespace(
            unfixed_chunk_num=kwargs["unfixed_chunk_num"],
            unfixed_token_num=kwargs["unfixed_token_num"],
            chunk_size_sec=kwargs["chunk_size_sec"],
            chunk_size_samples=32000,
            chunk_id=0,
            buffer=np.array([], dtype=np.float32),
            audio_accum=np.array([], dtype=np.float32),
            prompt_raw=f"prompt::{kwargs.get('context', '')}",
            context=kwargs.get("context", ""),
            force_language=None,
            language="",
            text="",
            _raw_decoded="",
        )


class FakeLLM:
    init_calls: list[dict[str, object]] = []

    def __init__(self, **kwargs: object):
        self.kwargs = kwargs
        self.__class__.init_calls.append(kwargs)


class FakeQwen3ASRModel:
    LLM = FakeLLM
    from_pretrained_calls: list[dict[str, object]] = []

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path: str, **kwargs: object):
        cls.from_pretrained_calls.append(
            {
                "pretrained_model_name_or_path": pretrained_model_name_or_path,
                **kwargs,
            }
        )
        return DummyOfflineModel()


class DummyBatchingBackend:
    backend_name = "transformers"
    supports_streaming = False
    supports_segment_batching = True

    def __init__(self, settings: AppSettings):
        self.settings = settings
        self.max_segment_batch_size = settings.transformers_max_batch_size
        self.segment_batches: list[list[tuple[int, str]]] = []

    def warmup(self) -> None:
        return None

    def create_stream_state(self, config: SessionConfig) -> dict[str, object]:  # noqa: ARG002
        raise AssertionError("streaming is not supported")

    def refresh_stream_context(
        self,
        state: dict[str, object],
        config: SessionConfig,  # noqa: ARG002
    ) -> dict[str, object]:
        return state

    def streaming_transcribe(self, pcm_bytes: bytes, state: dict[str, object]) -> StreamResult:  # noqa: ARG002
        raise AssertionError("streaming is not supported")

    def finish_stream(self, state: dict[str, object]) -> StreamResult:  # noqa: ARG002
        raise AssertionError("streaming is not supported")

    def transcribe_segment(self, pcm_bytes: bytes, config: SessionConfig) -> StreamResult:  # noqa: ARG002
        raise AssertionError("expected batched transcribe_segments path")

    def transcribe_segments(
        self,
        segments: list[tuple[bytes, SessionConfig]],
    ) -> list[StreamResult]:
        self.segment_batches.append(
            [(len(pcm_bytes), config.wav_name) for pcm_bytes, config in segments]
        )
        return [
            StreamResult(text=f"batch-{config.wav_name}", language="zh")
            for _, config in segments
        ]


class DummyBatchingVllmBackend(DummyBatchingBackend):
    backend_name = "vllm"
    supports_streaming = True


def build_config(mode: str = "offline", **overrides: object) -> SessionConfig:
    values: dict[str, object] = {
        "mode": mode,
        "wav_name": "demo",
        "wav_format": "pcm",
        "audio_fs": 16000,
        "chunk_size": [5, 10, 5],
        "hotwords": None,
        "hotword_terms": (),
        "hotword_context": "",
    }
    values.update(overrides)
    return SessionConfig(**values)


def build_settings(**overrides: object) -> AppSettings:
    values = {
        "frontend_path": AppSettings().frontend_path,
        "warmup_enabled": False,
    }
    values.update(overrides)
    return AppSettings(**values)


def test_qwen_backend_transcribe_segment_uses_numpy_audio_tuple_and_context() -> None:
    backend = object.__new__(QwenBackend)
    backend._model = DummyOfflineModel()

    pcm = np.array([0, 32767, -32768], dtype=np.int16)
    config = build_config(
        hotwords='{"Alibaba":20}',
        hotword_terms=("Alibaba",),
        hotword_context=build_hotword_context(("Alibaba",)),
    )
    result = backend.transcribe_segment(pcm.tobytes(), config)

    assert result.text == "offline text"
    assert result.language == "zh"

    call = backend._model.calls[0]
    assert call["return_time_stamps"] is False
    assert call["context"] == config.hotword_context
    assert isinstance(call["audio"], tuple)

    samples, sample_rate = call["audio"]
    assert sample_rate == 16000
    assert isinstance(samples, np.ndarray)
    assert samples.dtype == np.float32
    np.testing.assert_allclose(
        samples,
        np.array([0.0, 32767 / 32768.0, -1.0], dtype=np.float32),
    )


def test_qwen_backend_create_stream_state_passes_context() -> None:
    backend = object.__new__(QwenBackend)
    backend._model = DummyStreamingModel()
    config = build_config(
        mode="online",
        hotwords='{"Alibaba":20}',
        hotword_terms=("Alibaba",),
        hotword_context="ctx",
    )

    state = backend.create_stream_state(config)

    assert state.context == "ctx"
    assert backend._model.init_calls[0]["context"] == "ctx"


def test_qwen_backend_refresh_stream_context_preserves_progress() -> None:
    backend = object.__new__(QwenBackend)
    backend._model = DummyStreamingModel()
    state = backend.create_stream_state(build_config(mode="online"))
    state.chunk_id = 3
    state.buffer = np.array([0.1, 0.2], dtype=np.float32)
    state.audio_accum = np.array([0.3, 0.4], dtype=np.float32)
    state.language = "en"
    state.text = "old text"
    state._raw_decoded = "old raw"

    refreshed = backend.refresh_stream_context(
        state,
        build_config(
            mode="online",
            hotwords='{"Alibaba":20}',
            hotword_terms=("Alibaba",),
            hotword_context="ctx",
        ),
    )

    assert refreshed is not state
    assert refreshed.context == "ctx"
    assert refreshed.prompt_raw == "prompt::ctx"
    assert refreshed.chunk_id == 3
    np.testing.assert_allclose(refreshed.buffer, np.array([0.1, 0.2], dtype=np.float32))
    np.testing.assert_allclose(refreshed.audio_accum, np.array([0.3, 0.4], dtype=np.float32))
    assert refreshed.language == "en"
    assert refreshed.text == "old text"
    assert refreshed._raw_decoded == "old raw"


def test_qwen_backend_uses_qwen_default_max_new_tokens(monkeypatch) -> None:
    FakeLLM.init_calls.clear()
    monkeypatch.setitem(
        sys.modules,
        "qwen_asr",
        types.SimpleNamespace(Qwen3ASRModel=FakeQwen3ASRModel),
    )

    QwenBackend(build_settings())

    kwargs = FakeLLM.init_calls[-1]
    assert kwargs["model"] == build_settings().model_path
    assert kwargs["gpu_memory_utilization"] == build_settings().gpu_memory_utilization
    assert "max_new_tokens" not in kwargs
    assert "max_model_len" not in kwargs


def test_qwen_backend_passes_max_model_len_when_configured(monkeypatch) -> None:
    FakeLLM.init_calls.clear()
    monkeypatch.setitem(
        sys.modules,
        "qwen_asr",
        types.SimpleNamespace(Qwen3ASRModel=FakeQwen3ASRModel),
    )

    QwenBackend(build_settings(max_model_len=4096))

    kwargs = FakeLLM.init_calls[-1]
    assert kwargs["max_model_len"] == 4096
    assert "max_new_tokens" not in kwargs


def test_qwen_backend_passes_max_inference_batch_size(monkeypatch) -> None:
    FakeLLM.init_calls.clear()
    monkeypatch.setitem(
        sys.modules,
        "qwen_asr",
        types.SimpleNamespace(Qwen3ASRModel=FakeQwen3ASRModel),
    )

    QwenBackend(build_settings(vllm_max_batch_size=12))

    kwargs = FakeLLM.init_calls[-1]
    assert kwargs["max_inference_batch_size"] == 12


def test_transformers_backend_transcribe_segment_uses_numpy_audio_tuple_and_context() -> None:
    backend = object.__new__(TransformersQwenBackend)
    backend._model = DummyOfflineModel()

    pcm = np.array([0, 32767, -32768], dtype=np.int16)
    config = build_config(
        hotwords='{"Alibaba":20}',
        hotword_terms=("Alibaba",),
        hotword_context=build_hotword_context(("Alibaba",)),
    )
    result = backend.transcribe_segment(pcm.tobytes(), config)

    assert result.text == "offline text"
    assert result.language == "zh"

    call = backend._model.calls[0]
    assert call["return_time_stamps"] is False
    assert call["context"] == config.hotword_context
    assert isinstance(call["audio"], tuple)

    samples, sample_rate = call["audio"]
    assert sample_rate == 16000
    assert isinstance(samples, np.ndarray)
    assert samples.dtype == np.float32


def test_qwen_backend_transcribe_segments_batches_contexts_and_audio_list() -> None:
    backend = object.__new__(QwenBackend)
    backend._model = DummyOfflineModel()

    pcm = np.array([0, 32767, -32768], dtype=np.int16).tobytes()
    first = build_config(
        wav_name="first",
        hotword_terms=("Alibaba",),
        hotword_context=build_hotword_context(("Alibaba",)),
    )
    second = build_config(
        wav_name="second",
        hotword_terms=("TongyiLab",),
        hotword_context=build_hotword_context(("TongyiLab",)),
    )

    results = backend.transcribe_segments([(pcm, first), (pcm, second)])

    assert len(results) == 2
    assert [item.text for item in results] == ["offline text", "offline text"]

    call = backend._model.calls[0]
    assert isinstance(call["audio"], list)
    assert len(call["audio"]) == 2
    assert call["context"] == [first.hotword_context, second.hotword_context]
    for samples, sample_rate in call["audio"]:
        assert sample_rate == 16000
        assert isinstance(samples, np.ndarray)
        assert samples.dtype == np.float32


def test_transformers_backend_transcribe_segments_batches_contexts_and_audio_list() -> None:
    backend = object.__new__(TransformersQwenBackend)
    backend._model = DummyOfflineModel()

    pcm = np.array([0, 32767, -32768], dtype=np.int16).tobytes()
    first = build_config(
        wav_name="first",
        hotword_terms=("Alibaba",),
        hotword_context=build_hotword_context(("Alibaba",)),
    )
    second = build_config(
        wav_name="second",
        hotword_terms=("TongyiLab",),
        hotword_context=build_hotword_context(("TongyiLab",)),
    )

    results = backend.transcribe_segments([(pcm, first), (pcm, second)])

    assert len(results) == 2
    assert [item.text for item in results] == ["offline text", "offline text"]

    call = backend._model.calls[0]
    assert isinstance(call["audio"], list)
    assert len(call["audio"]) == 2
    assert call["context"] == [first.hotword_context, second.hotword_context]
    for samples, sample_rate in call["audio"]:
        assert sample_rate == 16000
        assert isinstance(samples, np.ndarray)
        assert samples.dtype == np.float32


def test_transformers_backend_passes_runtime_kwargs(monkeypatch) -> None:
    FakeQwen3ASRModel.from_pretrained_calls.clear()
    monkeypatch.setitem(
        sys.modules,
        "qwen_asr",
        types.SimpleNamespace(Qwen3ASRModel=FakeQwen3ASRModel),
    )
    monkeypatch.setattr(
        "server.engine.prepare_runtime_environment",
        lambda backend=None: types.SimpleNamespace(gpu_available=True),
    )

    TransformersQwenBackend(build_settings(transformers_max_new_tokens=2048))

    kwargs = FakeQwen3ASRModel.from_pretrained_calls[-1]
    assert kwargs["pretrained_model_name_or_path"] == build_settings().model_path
    assert kwargs["device_map"] == "cuda:0"
    assert kwargs["max_new_tokens"] == 2048
    assert kwargs["max_inference_batch_size"] == build_settings(
        transformers_max_new_tokens=2048
    ).transformers_max_batch_size


def test_build_backend_uses_selected_backend(monkeypatch) -> None:
    FakeQwen3ASRModel.from_pretrained_calls.clear()
    monkeypatch.setitem(
        sys.modules,
        "qwen_asr",
        types.SimpleNamespace(Qwen3ASRModel=FakeQwen3ASRModel),
    )
    monkeypatch.setattr(
        "server.engine.prepare_runtime_environment",
        lambda backend=None: types.SimpleNamespace(gpu_available=False),
    )

    backend = build_backend(build_settings(asr_backend="transformers"))

    assert isinstance(backend, TransformersQwenBackend)


def test_inference_worker_finalize_batch_uses_backend_batching_for_transformers() -> None:
    async def run() -> None:
        settings = build_settings(
            asr_backend="transformers",
            transformers_max_batch_size=4,
        )
        worker = InferenceWorker(settings, backend_factory=DummyBatchingBackend)
        backend = DummyBatchingBackend(settings)
        worker._backend = backend
        loop = asyncio.get_running_loop()
        worker._sessions = {
            "s1": EngineSession(
                config=build_config(mode="offline", wav_name="first"),
                segment_bytes=bytearray(b"\x00\x01" * 960),
                chunk_count=1,
            ),
            "s2": EngineSession(
                config=build_config(mode="offline", wav_name="second"),
                segment_bytes=bytearray(b"\x00\x02" * 960),
                chunk_count=1,
            ),
        }
        tasks = [
            EngineTask(
                kind="finalize",
                session_id="s1",
                payload=None,
                future=loop.create_future(),
                queued_at=time.perf_counter(),
            ),
            EngineTask(
                kind="finalize",
                session_id="s2",
                payload=None,
                future=loop.create_future(),
                queued_at=time.perf_counter(),
            ),
        ]

        try:
            results = await worker._execute_task_batch(tasks)
        finally:
            worker._executor.shutdown(wait=True, cancel_futures=True)

        assert [item.text for item in results] == ["batch-first", "batch-second"]
        assert backend.segment_batches == [[(1920, "first"), (1920, "second")]]
        assert worker._sessions["s1"].segment_bytes == bytearray()
        assert worker._sessions["s2"].segment_bytes == bytearray()
        assert worker._sessions["s1"].segment_index == 1
        assert worker._sessions["s2"].segment_index == 1

    asyncio.run(run())


def test_inference_worker_finalize_batch_uses_backend_batching_for_vllm_offline() -> None:
    async def run() -> None:
        settings = build_settings(
            asr_backend="vllm",
            vllm_max_batch_size=4,
        )
        worker = InferenceWorker(settings, backend_factory=DummyBatchingVllmBackend)
        backend = DummyBatchingVllmBackend(settings)
        worker._backend = backend
        loop = asyncio.get_running_loop()
        worker._sessions = {
            "s1": EngineSession(
                config=build_config(mode="offline", wav_name="first"),
                segment_bytes=bytearray(b"\x00\x01" * 960),
                chunk_count=1,
            ),
            "s2": EngineSession(
                config=build_config(mode="offline", wav_name="second"),
                segment_bytes=bytearray(b"\x00\x02" * 960),
                chunk_count=1,
            ),
        }
        tasks = [
            EngineTask(
                kind="finalize",
                session_id="s1",
                payload=None,
                future=loop.create_future(),
                queued_at=time.perf_counter(),
            ),
            EngineTask(
                kind="finalize",
                session_id="s2",
                payload=None,
                future=loop.create_future(),
                queued_at=time.perf_counter(),
            ),
        ]

        try:
            results = await worker._execute_task_batch(tasks)
        finally:
            worker._executor.shutdown(wait=True, cancel_futures=True)

        assert [item.text for item in results] == ["batch-first", "batch-second"]
        assert backend.segment_batches == [[(1920, "first"), (1920, "second")]]
        assert worker._sessions["s1"].segment_bytes == bytearray()
        assert worker._sessions["s2"].segment_bytes == bytearray()
        assert worker._sessions["s1"].segment_index == 1
        assert worker._sessions["s2"].segment_index == 1

    asyncio.run(run())


def test_build_hotword_context_uses_chinese_prompt() -> None:
    context = build_hotword_context(("阿里巴巴", "通义实验室"))

    assert context.startswith("以下是需要重点关注的热词和上下文短语：")
    assert "阿里巴巴" in context
    assert context.endswith("如果音频中出现这些词，请优先输出与这里一致的写法。")
