#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence
from urllib.error import URLError
from urllib.parse import urlparse, urlunparse
from urllib.request import urlopen

import loadtest_ws as base


DEFAULT_OUTPUT_DIR = Path("bench_results_transformers_offline")
DEFAULT_FINAL_TIMEOUT_SEC = 30.0
DEFAULT_BACKEND_CHECK_TIMEOUT_SEC = 5.0
DEFAULT_MIN_SUCCESS_RATE = 1.0
# DEFAULT_CONCURRENCY = "1"
DEFAULT_CONCURRENCY = "2,4,6,8,10,12,16"


@dataclass(slots=True)
class OfflineCapacityObservation:
    concurrency: int
    stable: bool
    verdict: str
    wall_time_sec: float
    audio_duration_sec: float
    total_audio_duration_sec: float
    successful_requests_per_sec: float
    audio_throughput_x: float
    aggregate_rtf: float
    client_successes: int
    client_failures: int
    success_rate: float
    error_rate: float
    final_p95_ms: float
    final_p99_ms: float
    mean_final_ms: float
    error_summary: str


@dataclass(slots=True)
class OfflineCapacitySummary:
    recommended_concurrency: int
    stable_levels: str
    first_unstable_concurrency: int | None
    threshold_summary: str
    note: str


def format_seconds(value: float) -> str:
    return "-" if value <= 0 else f"{value:.2f}"


def format_ratio(value: float) -> str:
    return "-" if value <= 0 else f"{value:.2f}x"


def compute_audio_duration_sec(frames: Sequence[bytes], audio_fs: int) -> float:
    if audio_fs <= 0:
        raise ValueError("audio_fs must be positive")
    total_samples = sum(len(frame) for frame in frames) // 2
    return round(total_samples / float(audio_fs), 4)


def normalize_latency_threshold(value: float | None) -> float | None:
    if value is None or value <= 0:
        return None
    return float(value)


def build_threshold_summary(
    min_success_rate: float,
    max_final_p95_ms: float | None,
    max_final_p99_ms: float | None,
) -> str:
    parts = [f"success>={base.format_rate(min_success_rate)}"]
    if max_final_p95_ms is not None:
        parts.append(f"final_p95<={max_final_p95_ms:.2f}ms")
    if max_final_p99_ms is not None:
        parts.append(f"final_p99<={max_final_p99_ms:.2f}ms")
    return ", ".join(parts)


def evaluate_capacity_verdict(
    result: base.RunResult,
    min_success_rate: float,
    max_final_p95_ms: float | None,
    max_final_p99_ms: float | None,
) -> tuple[bool, str]:
    reasons: list[str] = []
    if result.success_rate < min_success_rate:
        reasons.append(
            f"success<{base.format_rate(min_success_rate)}"
        )
    if max_final_p95_ms is not None and result.final_p95_ms > max_final_p95_ms:
        reasons.append(f"final_p95>{max_final_p95_ms:.2f}ms")
    if max_final_p99_ms is not None and result.final_p99_ms > max_final_p99_ms:
        reasons.append(f"final_p99>{max_final_p99_ms:.2f}ms")
    if not reasons:
        return True, "pass"
    return False, "; ".join(reasons)


def build_capacity_observation(
    result: base.RunResult,
    wall_time_sec: float,
    audio_duration_sec: float,
    min_success_rate: float,
    max_final_p95_ms: float | None,
    max_final_p99_ms: float | None,
) -> OfflineCapacityObservation:
    stable, verdict = evaluate_capacity_verdict(
        result=result,
        min_success_rate=min_success_rate,
        max_final_p95_ms=max_final_p95_ms,
        max_final_p99_ms=max_final_p99_ms,
    )
    total_audio_duration_sec = round(audio_duration_sec * result.concurrency, 4)
    successful_requests_per_sec = (
        round(result.client_successes / wall_time_sec, 4) if wall_time_sec > 0 else 0.0
    )
    audio_throughput_x = (
        round(total_audio_duration_sec / wall_time_sec, 4) if wall_time_sec > 0 else 0.0
    )
    aggregate_rtf = (
        round(wall_time_sec / total_audio_duration_sec, 4)
        if total_audio_duration_sec > 0
        else 0.0
    )
    return OfflineCapacityObservation(
        concurrency=result.concurrency,
        stable=stable,
        verdict=verdict,
        wall_time_sec=round(wall_time_sec, 4),
        audio_duration_sec=audio_duration_sec,
        total_audio_duration_sec=total_audio_duration_sec,
        successful_requests_per_sec=successful_requests_per_sec,
        audio_throughput_x=audio_throughput_x,
        aggregate_rtf=aggregate_rtf,
        client_successes=result.client_successes,
        client_failures=result.client_failures,
        success_rate=result.success_rate,
        error_rate=result.error_rate,
        final_p95_ms=result.final_p95_ms,
        final_p99_ms=result.final_p99_ms,
        mean_final_ms=result.mean_final_ms,
        error_summary=result.error_summary,
    )


def summarize_capacity(
    observations: Sequence[OfflineCapacityObservation],
    min_success_rate: float,
    max_final_p95_ms: float | None,
    max_final_p99_ms: float | None,
) -> OfflineCapacitySummary:
    threshold_summary = build_threshold_summary(
        min_success_rate=min_success_rate,
        max_final_p95_ms=max_final_p95_ms,
        max_final_p99_ms=max_final_p99_ms,
    )
    stable_levels = [item.concurrency for item in observations if item.stable]
    recommended = max(stable_levels, default=0)
    first_unstable = next((item.concurrency for item in observations if not item.stable), None)
    stable_levels_text = ",".join(str(level) for level in stable_levels) or "none"
    if recommended > 0:
        note = (
            f"recommended_concurrency={recommended}; stable_levels={stable_levels_text}; "
            f"thresholds={threshold_summary}"
        )
    else:
        note = f"no stable concurrency under thresholds={threshold_summary}"
    if first_unstable is not None:
        note = f"{note}; first_unstable={first_unstable}"
    return OfflineCapacitySummary(
        recommended_concurrency=recommended,
        stable_levels=stable_levels_text,
        first_unstable_concurrency=first_unstable,
        threshold_summary=threshold_summary,
        note=note,
    )


def build_mode_summary(
    results: Sequence[base.RunResult],
    capacity_summary: OfflineCapacitySummary,
) -> base.ModeSummary:
    tested_levels = [result.concurrency for result in results]
    highest_tested = max((result.concurrency for result in results), default=0)
    return base.ModeSummary(
        mode="offline",
        highest_tested_concurrency=highest_tested,
        tested_levels=",".join(str(level) for level in tested_levels) or "none",
        note=capacity_summary.note,
    )


def render_capacity_console_table(
    observations: Sequence[OfflineCapacityObservation],
) -> str:
    headers = [
        "conc",
        "stable",
        "success",
        "final_p95",
        "final_p99",
        "wall_s",
        "req_s",
        "audio_x",
        "rtf",
        "verdict",
    ]
    rows = [
        [
            str(item.concurrency),
            "yes" if item.stable else "no",
            base.format_rate(item.success_rate),
            base.format_ms(item.final_p95_ms),
            base.format_ms(item.final_p99_ms),
            format_seconds(item.wall_time_sec),
            format_seconds(item.successful_requests_per_sec),
            format_ratio(item.audio_throughput_x),
            format_ratio(item.aggregate_rtf),
            item.verdict,
        ]
        for item in observations
    ]
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in rows))
        for index in range(len(headers))
    ]

    def join_row(columns: Sequence[str]) -> str:
        return "  ".join(
            column.ljust(widths[index]) for index, column in enumerate(columns)
        )

    lines = [join_row(headers), join_row(["-" * width for width in widths])]
    lines.extend(join_row(row) for row in rows)
    return "\n".join(lines)


def derive_metrics_url(endpoint: str) -> str:
    parsed = urlparse(endpoint)
    if parsed.scheme not in {"ws", "wss"}:
        raise ValueError("endpoint must start with ws:// or wss://")
    http_scheme = "https" if parsed.scheme == "wss" else "http"
    return urlunparse((http_scheme, parsed.netloc, "/metrics", "", "", ""))


def fetch_metrics_payload(metrics_url: str, timeout_sec: float) -> dict[str, Any]:
    try:
        with urlopen(metrics_url, timeout=timeout_sec) as response:
            charset = response.headers.get_content_charset() or "utf-8"
            payload = json.loads(response.read().decode(charset))
    except URLError as exc:
        raise RuntimeError(f"failed to fetch metrics from {metrics_url}: {exc}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError("metrics response is not a JSON object")
    return payload


def validate_transformers_backend(metrics_payload: dict[str, Any]) -> dict[str, Any]:
    engine = metrics_payload.get("engine")
    if not isinstance(engine, dict):
        raise RuntimeError("metrics response is missing engine metrics")
    backend = engine.get("backend")
    if not isinstance(backend, dict):
        raise RuntimeError("metrics response is missing engine.backend details")
    backend_name = str(backend.get("name") or "")
    supports_streaming = bool(backend.get("supports_streaming"))
    if backend_name != "transformers":
        raise RuntimeError(
            f"expected transformers backend for this load test, got: {backend_name or 'unknown'}"
        )
    return {
        "name": backend_name,
        "supports_streaming": supports_streaming,
    }


def write_overview_outputs(
    run_dir: Path,
    summaries: list[base.ModeSummary],
    capacity_summary: OfflineCapacitySummary,
    observations: Sequence[OfflineCapacityObservation],
    endpoint: str,
    wav_path: Path,
    audio_duration_sec: float,
) -> tuple[Path, Path, Path]:
    overview_json = run_dir / "overview.json"
    overview_csv = run_dir / "overview.csv"
    overview_md = run_dir / "overview.md"
    overview_json.write_text(
        json.dumps(
            {
                "summaries": [asdict(item) for item in summaries],
                "capacity": asdict(capacity_summary),
                "observations": [asdict(item) for item in observations],
                "audio_duration_sec": audio_duration_sec,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    with overview_csv.open("w", newline="", encoding="utf-8") as handle:
        rows = [asdict(item) for item in observations]
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    overview_md.write_text(
        build_overview_report(
            summaries=summaries,
            capacity_summary=capacity_summary,
            observations=observations,
            endpoint=endpoint,
            wav_path=wav_path,
            run_dir=run_dir,
            audio_duration_sec=audio_duration_sec,
        ),
        encoding="utf-8",
    )
    return overview_json, overview_csv, overview_md


def build_overview_report(
    summaries: Sequence[base.ModeSummary],
    capacity_summary: OfflineCapacitySummary,
    observations: Sequence[OfflineCapacityObservation],
    endpoint: str,
    wav_path: Path,
    run_dir: Path,
    audio_duration_sec: float,
) -> str:
    rows = [
        [
            str(item.concurrency),
            "yes" if item.stable else "no",
            base.format_rate(item.success_rate),
            base.format_rate(item.error_rate),
            format_seconds(item.wall_time_sec),
            format_seconds(item.successful_requests_per_sec),
            format_ratio(item.audio_throughput_x),
            format_ratio(item.aggregate_rtf),
            base.format_ms(item.final_p95_ms),
            base.format_ms(item.final_p99_ms),
            item.verdict,
            item.error_summary,
        ]
        for item in observations
    ]
    summary = summaries[0] if summaries else None
    return "\n".join(
        [
            "# Transformers Offline Load Test Overview",
            "",
            f"- Generated at: `{datetime.now().isoformat(timespec='seconds')}`",
            f"- Endpoint: `{endpoint}`",
            f"- WAV: `{wav_path}`",
            f"- Single-request audio duration: `{audio_duration_sec:.2f}s`",
            f"- Output directory: `{run_dir}`",
            "",
            "## Capacity Verdict",
            f"- Highest tested concurrency: `{summary.highest_tested_concurrency if summary else 0}`",
            f"- Tested levels: `{summary.tested_levels if summary else 'none'}`",
            f"- Recommended stable concurrency: `{capacity_summary.recommended_concurrency}`",
            f"- Stable levels: `{capacity_summary.stable_levels}`",
            f"- First unstable concurrency: `{capacity_summary.first_unstable_concurrency or 'none'}`",
            f"- Thresholds: `{capacity_summary.threshold_summary}`",
            "",
            "## Observations",
            base.markdown_table(
                [
                    "Concurrency",
                    "Stable",
                    "Success Rate",
                    "Error Rate",
                    "Wall s",
                    "Req/s",
                    "Audio x",
                    "RTF",
                    "Final p95 ms",
                    "Final p99 ms",
                    "Verdict",
                    "Errors",
                ],
                rows,
            ),
            "",
        ]
    )


async def main() -> None:
    parser = argparse.ArgumentParser(
        description="Load test for transformers backend offline mode."
    )
    parser.add_argument("--endpoint", required=True)
    parser.add_argument("--wav", required=True, type=Path)
    parser.add_argument("--concurrency", default=DEFAULT_CONCURRENCY)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR, type=Path)
    parser.add_argument(
        "--final-timeout-sec",
        type=float,
        default=DEFAULT_FINAL_TIMEOUT_SEC,
        help=f"Timeout for the final offline result. Default: {DEFAULT_FINAL_TIMEOUT_SEC}",
    )
    parser.add_argument(
        "--backend-check-timeout-sec",
        type=float,
        default=DEFAULT_BACKEND_CHECK_TIMEOUT_SEC,
        help=(
            "Timeout for the preflight GET /metrics backend check. "
            f"Default: {DEFAULT_BACKEND_CHECK_TIMEOUT_SEC}"
        ),
    )
    parser.add_argument(
        "--skip-backend-check",
        action="store_true",
        help="Skip the preflight GET /metrics check for backend=transformers.",
    )
    parser.add_argument(
        "--min-success-rate",
        type=float,
        default=DEFAULT_MIN_SUCCESS_RATE,
        help=(
            "Minimum success rate required for a concurrency level to be considered stable. "
            f"Default: {DEFAULT_MIN_SUCCESS_RATE}"
        ),
    )
    parser.add_argument(
        "--max-final-p95-ms",
        type=float,
        default=None,
        help="Optional latency threshold. If set, final_p95_ms must stay below this value.",
    )
    parser.add_argument(
        "--max-final-p99-ms",
        type=float,
        default=None,
        help="Optional latency threshold. If set, final_p99_ms must stay below this value.",
    )
    parser.add_argument(
        "--stop-after-first-unstable",
        action="store_true",
        help="Stop testing higher concurrency levels after the first unstable result.",
    )
    parser.add_argument(
        "--server-vad",
        action="store_true",
        dest="server_vad_enabled",
        help="Backward-compatible alias. server_vad is enabled by default.",
    )
    parser.add_argument(
        "--disable-server-vad",
        action="store_false",
        dest="server_vad_enabled",
        help="Disable server_vad and require the explicit end-of-audio control message.",
    )
    parser.add_argument(
        "--server-vad-silence-ms",
        "--offline-vad-silence-ms",
        dest="server_vad_silence_ms",
        type=int,
        default=base.DEFAULT_SERVER_VAD_SILENCE_MS,
        help=(
            "Silence threshold in ms used when server_vad is enabled. "
            f"Default: {base.DEFAULT_SERVER_VAD_SILENCE_MS}"
        ),
    )
    parser.add_argument(
        "--server-vad-idle-timeout-sec",
        "--offline-idle-timeout-sec",
        dest="server_vad_idle_timeout_sec",
        type=float,
        default=base.DEFAULT_SERVER_VAD_IDLE_TIMEOUT_SEC,
        help=(
            "After sending end-of-audio with server_vad enabled, keep listening until the "
            "connection is quiet for this many seconds to collect all segment finals. "
            f"Default: {base.DEFAULT_SERVER_VAD_IDLE_TIMEOUT_SEC}"
        ),
    )
    parser.set_defaults(server_vad_enabled=True)
    args = parser.parse_args()

    if args.final_timeout_sec <= 0:
        raise ValueError("final_timeout_sec must be positive")
    if args.backend_check_timeout_sec <= 0:
        raise ValueError("backend_check_timeout_sec must be positive")
    if not 0 < args.min_success_rate <= 1:
        raise ValueError("min_success_rate must be between 0 and 1")
    if args.server_vad_silence_ms <= 0:
        raise ValueError("server_vad_silence_ms must be positive")
    if args.server_vad_idle_timeout_sec <= 0:
        raise ValueError("server_vad_idle_timeout_sec must be positive")
    max_final_p95_ms = normalize_latency_threshold(args.max_final_p95_ms)
    max_final_p99_ms = normalize_latency_threshold(args.max_final_p99_ms)

    if not args.skip_backend_check:
        metrics_url = derive_metrics_url(args.endpoint)
        backend_info = validate_transformers_backend(
            fetch_metrics_payload(metrics_url, args.backend_check_timeout_sec)
        )
        print(
            "backend preflight passed: "
            f"name={backend_info['name']} "
            f"supports_streaming={backend_info['supports_streaming']}"
        )

    frames, audio_fs = base.read_pcm_frames(args.wav)
    audio_duration_sec = compute_audio_duration_sec(frames, audio_fs)
    concurrency_levels = base.parse_concurrency_levels(args.concurrency)

    run_dir = args.output_dir / datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    print("\n=== mode=offline backend=transformers ===")
    print(
        "capacity thresholds: "
        f"{build_threshold_summary(args.min_success_rate, max_final_p95_ms, max_final_p99_ms)} "
        f"(audio={audio_duration_sec:.2f}s)"
    )
    results: list[base.RunResult] = []
    observations: list[OfflineCapacityObservation] = []
    for concurrency in concurrency_levels:
        print(f"running mode=offline concurrency={concurrency}")
        started_at = time.perf_counter()
        result = await base.run_step(
            endpoint=args.endpoint,
            mode="offline",
            frames=frames,
            audio_fs=audio_fs,
            concurrency=concurrency,
            final_timeout_sec=args.final_timeout_sec,
            server_vad_enabled=args.server_vad_enabled,
            server_vad_silence_ms=args.server_vad_silence_ms,
            server_vad_idle_timeout_sec=args.server_vad_idle_timeout_sec,
        )
        wall_time_sec = time.perf_counter() - started_at
        observation = build_capacity_observation(
            result=result,
            wall_time_sec=wall_time_sec,
            audio_duration_sec=audio_duration_sec,
            min_success_rate=args.min_success_rate,
            max_final_p95_ms=max_final_p95_ms,
            max_final_p99_ms=max_final_p99_ms,
        )
        print(
            f"mode=offline concurrency={concurrency} "
            f"success={base.format_rate(result.success_rate)} "
            f"error_rate={base.format_rate(result.error_rate)} "
            f"final_p95={base.format_ms(result.final_p95_ms)}ms "
            f"final_p99={base.format_ms(result.final_p99_ms)}ms "
            f"wall={format_seconds(observation.wall_time_sec)}s "
            f"req_s={format_seconds(observation.successful_requests_per_sec)} "
            f"audio_x={format_ratio(observation.audio_throughput_x)} "
            f"stable={'yes' if observation.stable else 'no'} "
            f"verdict={observation.verdict} "
            f"errors={result.error_summary}"
        )
        results.append(result)
        observations.append(observation)
        if args.stop_after_first_unstable and not observation.stable:
            print(f"stopping after first unstable concurrency={concurrency}")
            break

    capacity_summary = summarize_capacity(
        observations=observations,
        min_success_rate=args.min_success_rate,
        max_final_p95_ms=max_final_p95_ms,
        max_final_p99_ms=max_final_p99_ms,
    )
    summary = build_mode_summary(results, capacity_summary)
    json_path, csv_path, report_path = base.write_mode_outputs(
        mode_dir=run_dir / "offline",
        mode="offline",
        results=results,
        summary=summary,
        endpoint=args.endpoint,
        wav_path=args.wav,
    )
    overview_json, overview_csv, overview_md = write_overview_outputs(
        run_dir=run_dir,
        summaries=[summary],
        capacity_summary=capacity_summary,
        observations=observations,
        endpoint=args.endpoint,
        wav_path=args.wav,
        audio_duration_sec=audio_duration_sec,
    )

    print(base.render_console_table(results))
    print("\ncapacity summary")
    print(render_capacity_console_table(observations))
    print(
        f"mode=offline highest_tested={summary.highest_tested_concurrency} "
        f"recommended={capacity_summary.recommended_concurrency} "
        f"first_unstable={capacity_summary.first_unstable_concurrency or 'none'} "
        f"report={report_path}"
    )
    print(f"mode=offline outputs: {json_path}, {csv_path}, {report_path}")
    print("\n=== overview ===")
    print(base.render_overview_console_table([summary]))
    print(f"overview outputs: {overview_json}, {overview_csv}, {overview_md}")


if __name__ == "__main__":
    asyncio.run(main())
