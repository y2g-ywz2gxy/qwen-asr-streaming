from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest


MODULE_PATH = Path(__file__).resolve().parent / "loadtest_transformers_offline.py"
SPEC = importlib.util.spec_from_file_location("loadtest_transformers_offline_module", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
loadtest_transformers_offline = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = loadtest_transformers_offline
SPEC.loader.exec_module(loadtest_transformers_offline)


def test_derive_metrics_url_from_ws_endpoint() -> None:
    url = loadtest_transformers_offline.derive_metrics_url("ws://127.0.0.1:8001/ws/asr")

    assert url == "http://127.0.0.1:8001/metrics"


def test_derive_metrics_url_rejects_non_ws_endpoint() -> None:
    with pytest.raises(ValueError, match="ws:// or wss://"):
        loadtest_transformers_offline.derive_metrics_url("http://127.0.0.1:8001/ws/asr")


def test_validate_transformers_backend_accepts_transformers_payload() -> None:
    info = loadtest_transformers_offline.validate_transformers_backend(
        {
            "engine": {
                "backend": {
                    "name": "transformers",
                    "supports_streaming": False,
                }
            }
        }
    )

    assert info == {"name": "transformers", "supports_streaming": False}


def test_validate_transformers_backend_rejects_non_transformers_payload() -> None:
    with pytest.raises(RuntimeError, match="expected transformers backend"):
        loadtest_transformers_offline.validate_transformers_backend(
            {
                "engine": {
                    "backend": {
                        "name": "vllm",
                        "supports_streaming": True,
                    }
                }
            }
        )


def test_compute_audio_duration_sec_uses_pcm_bytes_and_sample_rate() -> None:
    duration_sec = loadtest_transformers_offline.compute_audio_duration_sec(
        [b"\x00\x00" * 1600, b"\x00\x00" * 800],
        16000,
    )

    assert duration_sec == 0.15


def test_build_capacity_observation_derives_throughput_metrics() -> None:
    result = loadtest_transformers_offline.base.RunResult(
        mode="offline",
        concurrency=4,
        client_successes=4,
        client_failures=0,
        success_rate=1.0,
        error_rate=0.0,
        interim_messages=0,
        final_messages=4,
        interim_p95_ms=0.0,
        interim_p99_ms=0.0,
        final_p95_ms=1200.0,
        final_p99_ms=1400.0,
        mean_interim_ms=0.0,
        mean_final_ms=1000.0,
        error_summary="none",
    )

    observation = loadtest_transformers_offline.build_capacity_observation(
        result=result,
        wall_time_sec=2.0,
        audio_duration_sec=5.0,
        min_success_rate=1.0,
        max_final_p95_ms=1500.0,
        max_final_p99_ms=None,
    )

    assert observation.stable is True
    assert observation.verdict == "pass"
    assert observation.total_audio_duration_sec == 20.0
    assert observation.successful_requests_per_sec == 2.0
    assert observation.audio_throughput_x == 10.0
    assert observation.aggregate_rtf == 0.1


def test_summarize_capacity_reports_recommended_and_first_unstable() -> None:
    observations = [
        loadtest_transformers_offline.OfflineCapacityObservation(
            concurrency=2,
            stable=True,
            verdict="pass",
            wall_time_sec=5.0,
            audio_duration_sec=4.0,
            total_audio_duration_sec=8.0,
            successful_requests_per_sec=0.4,
            audio_throughput_x=1.6,
            aggregate_rtf=0.62,
            client_successes=2,
            client_failures=0,
            success_rate=1.0,
            error_rate=0.0,
            final_p95_ms=900.0,
            final_p99_ms=950.0,
            mean_final_ms=800.0,
            error_summary="none",
        ),
        loadtest_transformers_offline.OfflineCapacityObservation(
            concurrency=4,
            stable=True,
            verdict="pass",
            wall_time_sec=8.0,
            audio_duration_sec=4.0,
            total_audio_duration_sec=16.0,
            successful_requests_per_sec=0.5,
            audio_throughput_x=2.0,
            aggregate_rtf=0.5,
            client_successes=4,
            client_failures=0,
            success_rate=1.0,
            error_rate=0.0,
            final_p95_ms=1500.0,
            final_p99_ms=1800.0,
            mean_final_ms=1200.0,
            error_summary="none",
        ),
        loadtest_transformers_offline.OfflineCapacityObservation(
            concurrency=6,
            stable=False,
            verdict="success<100.00%",
            wall_time_sec=12.0,
            audio_duration_sec=4.0,
            total_audio_duration_sec=24.0,
            successful_requests_per_sec=0.42,
            audio_throughput_x=2.0,
            aggregate_rtf=0.5,
            client_successes=5,
            client_failures=1,
            success_rate=0.8333,
            error_rate=0.1667,
            final_p95_ms=2200.0,
            final_p99_ms=2600.0,
            mean_final_ms=2000.0,
            error_summary="final_timeout=1",
        ),
    ]

    summary = loadtest_transformers_offline.summarize_capacity(
        observations=observations,
        min_success_rate=1.0,
        max_final_p95_ms=2000.0,
        max_final_p99_ms=None,
    )

    assert summary.recommended_concurrency == 4
    assert summary.stable_levels == "2,4"
    assert summary.first_unstable_concurrency == 6
    assert "recommended_concurrency=4" in summary.note
    assert "first_unstable=6" in summary.note


def test_render_capacity_console_table_contains_capacity_columns() -> None:
    table = loadtest_transformers_offline.render_capacity_console_table(
        [
            loadtest_transformers_offline.OfflineCapacityObservation(
                concurrency=2,
                stable=True,
                verdict="pass",
                wall_time_sec=4.0,
                audio_duration_sec=3.0,
                total_audio_duration_sec=6.0,
                successful_requests_per_sec=0.5,
                audio_throughput_x=1.5,
                aggregate_rtf=0.67,
                client_successes=2,
                client_failures=0,
                success_rate=1.0,
                error_rate=0.0,
                final_p95_ms=800.0,
                final_p99_ms=900.0,
                mean_final_ms=700.0,
                error_summary="none",
            )
        ]
    )

    assert "audio_x" in table
    assert "rtf" in table
    assert "verdict" in table
