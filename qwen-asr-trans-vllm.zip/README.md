# Qwen3-ASR WebSocket 服务

基于 `Qwen3-ASR-1.7B` 的 WebSocket 语音识别服务，默认使用 `transformers` backend 提供稳定的 `offline` 识别；如需 `online` / `2pass` 流式能力，可切换到 `vllm` backend。服务同时提供热词、中文最终结果 `itn`、浏览器调试页、健康检查和压测脚本。

## 主要能力

- 默认支持 `offline`
- 在 `ASR_BACKEND=vllm` 时，`offline`、`online`、`2pass` 三种模式全部可用
- 默认开启服务端 VAD，支持按句返回
- 支持中文最终结果 `itn`
- 提供 `GET /healthz`、`GET /ready`、`GET /metrics`、浏览器调试页
- 提供测试与压测脚本

`2pass` 在 `ASR_BACKEND=vllm` 时的行为是：

- 流式阶段返回中间结果，回包 `mode=2pass-online`
- 句末阶段对整段音频再做一次离线识别，回包 `mode=2pass-offline`

## 项目结构

- `server/app.py`：FastAPI 与 WebSocket 入口
- `server/engine.py`：推理调度与会话管理
- `server/protocol.py`：协议解析与回包格式
- `server/audio.py`：PCM 处理与音频工具
- `server/vad.py`：服务端 VAD 与静音切分
- `frontend/index.html`：浏览器调试页面
- `tests/`：测试与压测脚本

## 运行原理

- WebSocket 连接建立后，首包 JSON 决定 `mode`、热词、`itn` 和 `turn_detection`；后续只允许发送 PCM `bytes`、热词更新和 `{"is_speaking": false}`。
- 服务内部统一按 `16kHz / 16-bit / 单声道` 处理音频；如果客户端发送 `8kHz PCM`，会先重采样到 `16kHz`。
- `server_vad` 默认开启。检测到静音阈值后，服务端会先返回当前句子的句级结果，通常是 `mode=2pass-offline, is_final=false`；客户端后续显式发送 `{"is_speaking": false}` 时，服务端一定会再返回 `is_final=true` 的最终确认包。
- `offline` 模式下，自动切段后的显式结束会重复返回该句文本并置 `is_final=true`；`online` / `2pass` 模式下，如果 `server_vad` 已经提前给过该句的句级结果，显式结束可能返回 `text=""` 的最终确认包。
- 服务端回包 `mode` 只有两种：`2pass-online` 表示流式中间结果，`2pass-offline` 表示句级结果。即使请求是 `offline` 或 `online`，句级结果仍统一走 `2pass-offline`。
- `transformers` backend 只支持 `offline`。`vllm` backend 支持 `offline`、`online`、`2pass`；其中 `2pass` 会先返回 `2pass-online` 流式中间结果，再在句末返回 `2pass-offline` 的整句修正结果。
- `offline finalize` 微批处理目前同时支持 `transformers` 和 `vllm`。单请求路径仍按单条 `transcribe()` 执行；只有当多个 `offline finalize` 任务同时排队时，`server/engine.py` 才会把这些 finalize 合并成一个微批处理。`transformers` 的批大小由 `TRANSFORMERS_MAX_BATCH_SIZE` 控制，`vllm` 的批大小由 `VLLM_MAX_BATCH_SIZE` 控制。这是为了提升真实并发场景下的 GPU 利用率，不会改变日常单请求路径。
- `hotwords` 会被映射到 Qwen `context` 提示词；`itn` 只作用于最终中文结果，流式中间结果保持原样。

## 快速开始

环境要求：

- Python 3.10+
- NVIDIA 驱动与 CUDA 环境
- 本地可用的 `Qwen3-ASR-1.7B` 模型目录，或按下文步骤下载
- 已验证基线：`Tesla V100-SXM2-32GB / Driver 535.129.03 / CUDA 12.2`
- 默认运行时版本：`qwen-asr 0.0.6`、`torch 2.9.1`、`torchaudio 2.9.1`、`torchvision 0.24.1`
- 可选 `vllm` 运行时版本：`vllm 0.14.0`

运行时兼容说明：

- `V100` 属于 `SM 7.0`，项目默认改走 `ASR_BACKEND=transformers`，规避当前 `vllm` backend 启动失败
- 如需恢复流式能力，先执行 `make install-vllm`，再切换 `ASR_BACKEND=vllm`
- `ASR_BACKEND=vllm` 时，V100 仍需 `VLLM_ATTENTION_BACKEND=TORCH_SDPA`
- `ASR_BACKEND=vllm` 时，默认关闭 `FlashInfer sampler`，即 `VLLM_USE_FLASHINFER_SAMPLER=0`
- `make run` 和 Docker 容器启动前都会先执行 `python -m server.runtime_check`
- 默认 Docker 基线使用 `nvidia/cuda:12.2.2-devel-ubuntu22.04`
- 官方 `qwenllm/qwen3-asr` 运行镜像仍可通过 `QWEN_ASR_BASE_IMAGE` 手动覆盖，但不再作为默认值

推荐使用 Makefile：

```bash
make venv
make install
cp config/example.env .env
make download-model
make run
```

`make download-model` 会先执行 `make install`，因为模型下载命令依赖已安装的 `modelscope`。

`make run` 会根据当前 `.env` 中的 `ASR_BACKEND` 自动选择 `install` 或 `install-vllm`，因此切到 `vllm` 后不需要手动再改 Makefile。

如果要恢复三种模式，再额外执行：

```bash
make install-vllm
```

然后将 `.env` 中的 `ASR_BACKEND` 改为：

```bash
ASR_BACKEND=vllm
```

手动启动：

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip setuptools wheel
pip install -r requirements.runtime-gpu.txt
cp config/example.env .env
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
python -m server.runtime_check
python -m server.app --host 0.0.0.0 --port 8001
```

如果手动安装后要开启三种模式，补充执行：

```bash
pip install -r requirements.runtime-vllm.txt
```

并在启动前设置：

```bash
ASR_BACKEND=vllm
```

推荐先执行一次运行时自检：

```bash
.venv/bin/python -m server.runtime_check
```

通过时会输出当前 Python 包版本、`torch.version.cuda`、GPU 名称、compute capability，以及当前生效的 `ASR_BACKEND`。当 backend 为 `vllm` 时，还会附带最终生效的 `VLLM_ATTENTION_BACKEND`。

默认模型目录：

```text
./models/Qwen3-ASR-1.7B
```

如果不使用 `make download-model`，请在完成依赖安装后手动下载模型：

```bash
mkdir -p models
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
```

如果 `modelscope download` 报错 `No module named 'pkg_resources'`，执行：

```bash
.venv/bin/pip install -U setuptools wheel
```

## Docker 启动

Docker 方式不会在容器内下载模型。执行 `docker compose up` 前，请先在宿主机准备好完整模型目录，并让 `MODEL_PATH_HOST` 指向该目录。

默认 Docker 基线使用 `nvidia/cuda:12.2.2-devel-ubuntu22.04`，并在镜像内安装锁定的 `qwen-asr / torch` 运行时。
这样在“联网环境打包，再把镜像带到离线环境运行”的流程里更稳妥：即使个别依赖在构建阶段回退到源码安装，也仍然有完整的 CUDA 开发工具链可用。
这样也可以在宿主机 `Driver 535.129.03 / nvidia-smi 显示 CUDA 12.2` 的条件下启动，不再依赖 `cuda>=12.8` 的官方 qwen 运行镜像。
如果部署机驱动更高，仍可通过 `QWEN_ASR_BASE_IMAGE` 手动覆盖为官方 `qwenllm/qwen3-asr` 镜像。

```bash
cp config/docker.env.example .env
mkdir -p logs
docker compose build
docker compose up -d
```

容器启动时会自动执行一次运行时自检；如果版本不匹配、GPU 不可见，或 `ASR_BACKEND=vllm` 时 V100 上误配了不安全 backend，容器会直接退出。

默认 `docker compose build` 构建的是离线稳定档位。如果要让 Docker 镜像支持三种模式，先在 `.env` 中设置：

```bash
INSTALL_VLLM=1
ASR_BACKEND=vllm
```

然后重新执行：

```bash
docker compose build --no-cache
docker compose up -d
```

推荐的 V100 `.env` 基线：

```bash
ASR_BACKEND=transformers
GPU_MEMORY_UTILIZATION=0.8
TRANSFORMERS_MAX_NEW_TOKENS=256
TRANSFORMERS_MAX_BATCH_SIZE=16
MAX_SESSIONS=16
```

如果切回 `vllm`，再补充：

```bash
ASR_BACKEND=vllm
VLLM_ATTENTION_BACKEND=TORCH_SDPA
VLLM_USE_FLASHINFER_SAMPLER=0
VLLM_MAX_BATCH_SIZE=16
MAX_MODEL_LEN=4096
```

说明：

- `INSTALL_VLLM=1` 影响 Docker 构建阶段，必须在 `docker compose build` 前设置
- `ASR_BACKEND=vllm` 影响容器运行阶段，决定服务实际启用三种模式
- 如果希望 `transformers` 离线并发真正吃到 `TRANSFORMERS_MAX_BATCH_SIZE=16` 的微批收益，`MAX_SESSIONS` 不应低于 `16`
- 如果希望 `vllm` 的 `offline` 并发也吃到微批收益，`MAX_SESSIONS` 同样不应低于 `VLLM_MAX_BATCH_SIZE`

默认 Docker Python 版本为 `3.10`；本地 `uv` / `.venv` 路径仍可继续使用 `Python 3.12`。

如果模型还没下载，请先在宿主机按上文方式完成下载；如果模型在仓库外，再修改 `.env` 中的：

```bash
MODEL_PATH_HOST=/absolute/path/to/Qwen3-ASR-1.7B
MODEL_PATH_CONTAINER=/models/Qwen3-ASR-1.7B
LOGS_DIR_CONTAINER=/app/logs
FRONTEND_PATH_CONTAINER=/app/frontend/index.html
```

常用命令：

```bash
docker compose ps
docker compose logs -f
docker compose down
```

## 服务入口

- `GET /`：浏览器调试页面
- `GET /healthz`：健康检查
- `GET /ready`：就绪检查，返回内容与 `GET /healthz` 相同
- `GET /metrics`：运行指标
- `WS /ws/asr`：识别入口

## 协议摘要

发送顺序：

1. 发送首包 JSON 配置
2. 发送 PCM `bytes`
3. 如需手动结束当前 segment 或冲刷尾部音频，发送 `{"is_speaking": false}`

协议语义变化：

- 请求 `mode` 用来决定服务端内部运行策略，不直接决定回包里的 `mode` 字面值
- 回包 `mode` 只使用 `2pass-online` 和 `2pass-offline`
- `is_speaking=false` 只结束当前 segment，不关闭 WebSocket 连接
- `is_final=true` 表示当前 segment 的最终结果
- 当 `ASR_BACKEND=transformers` 时，仅支持 `offline`；请求 `online` / `2pass` 会在初始化阶段返回 `UNSUPPORTED_MODE`
- 当 `ASR_BACKEND=vllm` 时，三种模式都可用，且 `offline` 也走 `vllm`

首包示例：

```json
{
  "mode": "offline",
  "wav_name": "demo-session",
  "is_speaking": true,
  "wav_format": "pcm",
  "audio_fs": 16000,
  "chunk_size": [5, 10, 5],
  "hotwords": "{\"阿里巴巴\":20,\"通义实验室\":30}",
  "itn": true,
  "turn_detection": {"type": "server_vad", "silence_duration_ms": 600}
}
```

约束：

- `wav_format` 只支持 `pcm`
- `audio_fs` 只支持 `8000` 或 `16000`
- 推荐输入 `16kHz / 16-bit / 单声道`
- 推荐按约 `60ms` 的节奏发送音频帧
- `hotwords` 只兼容字符串对象格式，例如 `"{\"阿里巴巴\":20,\"通义实验室\":30}"`
- `itn=true` 时，仅对最终中文结果做归一化，流式中间结果保持原样
- 默认开启 `server_vad`；如果要关闭，首包显式传 `{"turn_detection":{"type":"none"}}`

连接建立后可以动态更新热词：

```json
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}"}
```

也可以与断句结束一起发送：

```json
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}","is_speaking":false}
```

说明：

- 热词会映射到 Qwen `context` 做增强
- 热词权重仅做格式兼容，不等价于 FunASR/FST 热词权重语义
- 当前 `qwen-asr` Python API 没有原生 `itn` 参数，`itn` 由服务端在最终文本阶段处理
- 开启 `server_vad` 时，连续静音达到 `silence_duration_ms` 会自动结束当前 segment；`max_segment_ms` 只作为兜底上限

请求与回包关系：

| 请求 `mode` | 流式中间结果 | 自动切段时的句级结果 | 手动 `{"is_speaking": false}` 的最终回包 |
| --- | --- | --- | --- |
| `offline` | 无 | `mode=2pass-offline, is_final=false` | `mode=2pass-offline, is_final=true` |
| `online` | `mode=2pass-online, is_final=false` | `mode=2pass-offline, is_final=false` | `mode=2pass-offline, is_final=true` |
| `2pass` | `mode=2pass-online, is_final=false` | `mode=2pass-offline, is_final=false` | `mode=2pass-offline, is_final=true` |

回包策略：

- `2pass-online` 表示流式中间结果
- `2pass-offline` 表示句级离线修正结果；`offline` 和 `2pass` 都会按句返回这一类消息
- 开启 `server_vad` 时，服务端会在检测到静音阈值后自动返回当前 segment 的句级结果；这类自动切段结果通常 `is_final=false`
- 客户端显式发送 `{"is_speaking": false}` 时，服务端会返回当前 segment 的完整最终结果，并置 `is_final=true`
- 在 `online` / `2pass` 模式下，如果 `server_vad` 已经提前返回过该句的 `2pass-offline` 文本结果，后续显式结束可能只返回 `text=""` 的最终确认包
- 需要结束整个 WebSocket 会话时，由客户端主动关闭连接

典型回包序列：

```text
{"mode":"2pass-online","wav_name":"demo","text":"今天天气","is_final":false}
{"mode":"2pass-offline","wav_name":"demo","text":"今天天气不错","is_final":false}
{"mode":"2pass-offline","wav_name":"demo","text":"","is_final":true}
```

理解方式：

- `mode=2pass-online` 且 `is_final=false` 时，更新流式中间文本
- 收到 `mode=2pass-offline` 时，将该条消息作为句级结果处理；其中自动切段通常 `is_final=false`
- 收到 `is_final=true` 时，将该条消息视为“当前 segment 已结束”；如果 `text=""`，表示这是对上一条句级结果的最终确认，而不是新的空句子
- 收到 `is_final=true` 后不要自动断开连接；如果还要继续识别，客户端可以在同一 WebSocket 上继续发送下一段音频

## 测试与压测

```bash
make test
make loadtest LOADTEST_WAV=./sample.wav
make loadtest LOADTEST_WAV=./sample.wav LOADTEST_SERVER_VAD=0
make loadtest-transformers-offline LOADTEST_WAV=./sample.wav
```

说明：

- `make loadtest` 默认开启服务端 VAD
- 如果要验证“仅依赖客户端发送 `{"is_speaking": false}` 才结束”的行为，使用 `LOADTEST_SERVER_VAD=0`
- `make loadtest-transformers-offline` 会先检查 `GET /metrics` 中的 backend 是否为 `transformers`，然后只压 `offline` 模式
- `loadtest_transformers_offline.py` 会输出每个并发档位的 `final p95/p99`、总耗时、`req/s`、聚合实时倍率 `audio_x`、`RTF`，并给出当前测试集下的推荐稳定并发
- `offline` 压测里 `audio_x` 在较高并发下继续上升通常是正常现象，因为更多 `offline finalize` 会形成更完整的微批；评估是否“更好”时，优先看 `success_rate`、`final p95/p99` 和是否出现 OOM / timeout，而不是只看吞吐

## 更多说明

- 部署、配置、排障、压测：`docs/deploy.md`
- 协议示例：`example/websocket_protocol_zh.md`
