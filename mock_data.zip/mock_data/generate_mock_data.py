#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
河南农商银行经营数据Mock生成脚本
生成6个Excel文件，包含机构信息、贷款、存款、资产质量、利润、客户数据
数据时间范围：2024-01 至 2026-03（共27个月）
"""

import os
import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

# 设置随机种子以保证可重复性
random.seed(42)
np.random.seed(42)

# 输出目录
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

# ============ 基础数据定义 ============

# 河南省地市列表及其经济权重（影响规模大小）
CITIES = {
    "郑州": 1.0,   # 省会，最大
    "洛阳": 0.7,
    "南阳": 0.6,
    "开封": 0.45,
    "新乡": 0.5,
    "安阳": 0.45,
    "许昌": 0.48,
    "信阳": 0.42,
    "周口": 0.55,
    "驻马店": 0.48,
    "商丘": 0.52,
    "平顶山": 0.45,
    "焦作": 0.42,
    "濮阳": 0.38,
    "漯河": 0.35,
    "三门峡": 0.32,
    "鹤壁": 0.28,
    "济源": 0.25,
}

# 各地市下辖县区（使用真实县区名）
COUNTY_MAP = {
    "郑州": ["巩义", "新密", "荥阳", "新郑"],
    "洛阳": ["偃师", "孟津", "新安", "伊川"],
    "南阳": ["邓州", "镇平", "内乡", "西峡"],
    "开封": ["兰考", "尉氏", "杞县"],
    "新乡": ["卫辉", "辉县", "长垣"],
    "安阳": ["林州", "汤阴", "滑县"],
    "许昌": ["禹州", "长葛", "鄢陵"],
    "信阳": ["固始", "淮滨", "光山"],
    "周口": ["项城", "沈丘", "太康", "鹿邑"],
    "驻马店": ["遂平", "西平", "泌阳"],
    "商丘": ["永城", "夏邑", "虞城", "柘城"],
    "平顶山": ["舞钢", "汝州", "宝丰"],
    "焦作": ["沁阳", "孟州", "博爱"],
    "濮阳": ["清丰", "南乐", "台前"],
    "漯河": ["舞阳", "临颍"],
    "三门峡": ["灵宝", "义马"],
    "鹤壁": ["浚县", "淇县"],
    "济源": ["济源城区"],  # 济源是省直辖，下设1个区
}

# 统计月份列表
MONTHS = [f"2024-{str(m).zfill(2)}" for m in range(1, 13)] + \
         [f"2025-{str(m).zfill(2)}" for m in range(1, 13)] + \
         [f"2026-{str(m).zfill(2)}" for m in range(1, 4)]

# ============ 机构信息生成 ============

def generate_org_info() -> pd.DataFrame:
    """生成机构信息表"""
    orgs = []
    org_code_counter = 1000
    
    # 省级机构
    province_code = f"410000{org_code_counter:04d}"
    org_code_counter += 1
    orgs.append({
        "机构代码": province_code,
        "机构名称": "河南省农村信用社联合社",
        "机构层级": "省级",
        "上级机构代码": "",
        "上级机构名称": "",
        "所在地市": "郑州",
        "成立日期": "2005-08-18",
        "员工人数": random.randint(800, 1200),
    })
    
    city_codes = {}
    county_orgs = []
    
    # 地市级机构
    for city, weight in CITIES.items():
        city_code = f"41{str(list(CITIES.keys()).index(city)+1).zfill(2)}00{org_code_counter:04d}"
        org_code_counter += 1
        city_codes[city] = city_code
        
        orgs.append({
            "机构代码": city_code,
            "机构名称": f"{city}农商银行",
            "机构层级": "地市级",
            "上级机构代码": province_code,
            "上级机构名称": "河南省农村信用社联合社",
            "所在地市": city,
            "成立日期": f"{random.randint(2008, 2015)}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}",
            "员工人数": int(random.randint(1500, 4000) * weight),
        })
        
        # 县区级机构
        for county in COUNTY_MAP.get(city, []):
            county_code = f"41{str(list(CITIES.keys()).index(city)+1).zfill(2)}{org_code_counter:04d}"
            org_code_counter += 1
            county_orgs.append({
                "机构代码": county_code,
                "机构名称": f"{county}农商银行",
                "机构层级": "县区级",
                "上级机构代码": city_code,
                "上级机构名称": f"{city}农商银行",
                "所在地市": city,
                "成立日期": f"{random.randint(2010, 2018)}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}",
                "员工人数": int(random.randint(200, 800) * weight),
            })
    
    orgs.extend(county_orgs)
    return pd.DataFrame(orgs)


def get_org_dict(org_df: pd.DataFrame) -> Dict:
    """获取机构字典，方便后续使用"""
    return {
        row["机构代码"]: {
            "机构名称": row["机构名称"],
            "机构层级": row["机构层级"],
            "所在地市": row["所在地市"],
        }
        for _, row in org_df.iterrows()
    }


# ============ 贷款数据生成 ============

def get_seasonal_factor(month: str) -> float:
    """获取季节性因子"""
    m = int(month.split("-")[1])
    # 一季度和四季度（年末）较高
    if m in [1, 2, 3, 12]:
        return random.uniform(1.05, 1.15)
    elif m in [6, 7, 8]:  # 夏季略低
        return random.uniform(0.90, 0.98)
    else:
        return random.uniform(0.98, 1.05)


def generate_loan_data(org_df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """生成贷款业务数据（3个sheet）"""
    org_dict = get_org_dict(org_df)
    
    # 基础贷款规模（亿元）
    BASE_LOAN = {
        "省级": 10000,  # 全行汇总
        "地市级": 450,  # 平均
        "县区级": 80,   # 平均
    }
    
    # Sheet1: 贷款目标完成情况
    loan_target_data = []
    # Sheet2: 贷款结构明细
    loan_structure_data = []
    # Sheet3: 贷款期限分布
    loan_term_data = []
    
    # 贷款类别及其占比范围
    LOAN_CATEGORIES = {
        "涉农贷款": (0.35, 0.45),
        "个人贷款": (0.18, 0.25),
        "企业贷款": (0.15, 0.22),
        "小微企业贷款": (0.12, 0.18),
        "消费贷款": (0.05, 0.10),
        "房贷": (0.03, 0.08),
    }
    
    # 期限类型
    TERM_TYPES = {"短期": (0.30, 0.40), "中期": (0.25, 0.35), "长期": (0.30, 0.40)}
    
    # 为每个机构生成基础数据
    org_base_loan = {}
    for code, info in org_dict.items():
        level = info["机构层级"]
        city = info["所在地市"]
        city_weight = CITIES.get(city, 0.3)
        
        if level == "省级":
            base = 0  # 省级汇总，后面计算
        elif level == "地市级":
            base = BASE_LOAN["地市级"] * city_weight * random.uniform(0.85, 1.15)
        else:
            base = BASE_LOAN["县区级"] * city_weight * random.uniform(0.7, 1.3)
        
        org_base_loan[code] = base
    
    # 计算省级汇总（所有地市级之和）
    province_code = [c for c, i in org_dict.items() if i["机构层级"] == "省级"][0]
    city_level_total = sum(v for c, v in org_base_loan.items() if org_dict[c]["机构层级"] == "地市级")
    org_base_loan[province_code] = city_level_total
    
    # 按月生成数据
    for month_idx, month in enumerate(MONTHS):
        seasonal = get_seasonal_factor(month)
        year = month.split("-")[0]
        is_new_year = month.endswith("-01")
        
        for code, info in org_dict.items():
            level = info["机构层级"]
            city = info["所在地市"]
            name = info["机构名称"]
            
            # 计算当月贷款余额（带增长和波动）
            growth_factor = 1 + (month_idx * 0.005) + random.uniform(-0.02, 0.03)
            base = org_base_loan[code] * growth_factor * seasonal
            
            if level == "省级":
                # 省级数据需要重新汇总
                current_balance = sum(
                    org_base_loan[c] * growth_factor * seasonal
                    for c, i in org_dict.items()
                    if i["机构层级"] == "地市级"
                )
            else:
                current_balance = base
            
            # 年度目标（年初设定）
            annual_target = current_balance * random.uniform(1.08, 1.15)
            
            # 当月新增
            monthly_new = current_balance * random.uniform(0.02, 0.05) * seasonal
            
            # 年累计新增
            if is_new_year:
                ytd_new = monthly_new
            else:
                # 简化：假设每月新增累加
                month_num = int(month.split("-")[1])
                ytd_new = monthly_new * month_num * random.uniform(0.8, 1.2)
            
            # 目标完成率
            target_rate = (ytd_new / (annual_target * 0.1 * int(month.split("-")[1]))) * 100
            target_rate = min(max(target_rate, 60), 115) + random.uniform(-5, 5)
            
            # 同比、环比
            yoy = random.uniform(5, 15) if random.random() > 0.2 else random.uniform(-2, 5)
            mom = random.uniform(-2, 5)
            
            loan_target_data.append({
                "统计月份": month,
                "机构代码": code,
                "机构名称": name,
                "机构层级": level,
                "所在地市": city,
                "年度贷款目标(亿元)": round(annual_target, 2),
                "当月贷款余额(亿元)": round(current_balance, 2),
                "当月新增贷款(亿元)": round(monthly_new, 2),
                "年累计新增贷款(亿元)": round(ytd_new, 2),
                "目标完成率(%)": round(target_rate, 2),
                "同比增长率(%)": round(yoy, 2),
                "环比增长率(%)": round(mom, 2),
            })
            
            # Sheet2: 贷款结构明细
            remaining = current_balance
            categories_data = []
            for i, (cat, (low, high)) in enumerate(LOAN_CATEGORIES.items()):
                if i == len(LOAN_CATEGORIES) - 1:
                    # 最后一个类别取剩余部分
                    cat_balance = remaining
                else:
                    ratio = random.uniform(low, high)
                    cat_balance = current_balance * ratio
                    remaining -= cat_balance
                
                # 不良率（涉农和小微略高）
                if cat in ["涉农贷款", "小微企业贷款"]:
                    npl_rate = random.uniform(1.8, 3.2)
                elif cat == "房贷":
                    npl_rate = random.uniform(0.8, 1.5)
                else:
                    npl_rate = random.uniform(1.2, 2.5)
                
                cat_pct = (cat_balance / current_balance) * 100 if current_balance > 0 else 0
                cat_new = cat_balance * random.uniform(0.02, 0.05)
                
                categories_data.append({
                    "统计月份": month,
                    "机构代码": code,
                    "机构名称": name,
                    "所在地市": city,
                    "贷款类别": cat,
                    "贷款余额(亿元)": round(cat_balance, 2),
                    "占比(%)": round(cat_pct, 2),
                    "当月新增(亿元)": round(cat_new, 2),
                    "不良率(%)": round(npl_rate, 2),
                })
            
            # 调整占比使总和为100%
            total_pct = sum(d["占比(%)"] for d in categories_data)
            for d in categories_data:
                d["占比(%)"] = round(d["占比(%)"] / total_pct * 100, 2)
            loan_structure_data.extend(categories_data)
            
            # Sheet3: 期限分布
            remaining = current_balance
            term_list = list(TERM_TYPES.items())
            for i, (term, (low, high)) in enumerate(term_list):
                if i == len(term_list) - 1:
                    term_balance = remaining
                else:
                    ratio = random.uniform(low, high)
                    term_balance = current_balance * ratio
                    remaining -= term_balance
                
                term_pct = (term_balance / current_balance) * 100 if current_balance > 0 else 0
                
                loan_term_data.append({
                    "统计月份": month,
                    "机构代码": code,
                    "机构名称": name,
                    "所在地市": city,
                    "期限类型": term,
                    "贷款余额(亿元)": round(term_balance, 2),
                    "占比(%)": round(term_pct, 2),
                })
    
    return {
        "贷款目标完成情况": pd.DataFrame(loan_target_data),
        "贷款结构明细": pd.DataFrame(loan_structure_data),
        "贷款期限分布": pd.DataFrame(loan_term_data),
    }


# ============ 存款数据生成 ============

def generate_deposit_data(org_df: pd.DataFrame, loan_data: Dict) -> Dict[str, pd.DataFrame]:
    """生成存款业务数据（2个sheet）"""
    org_dict = get_org_dict(org_df)
    
    # 从贷款数据获取贷款余额，计算存款（存贷比60%-75%）
    loan_target_df = loan_data["贷款目标完成情况"]
    
    deposit_target_data = []
    deposit_structure_data = []
    
    # 存款类别
    DEPOSIT_CATEGORIES = {
        "定期存款": (0.55, 0.65),
        "活期存款": (0.20, 0.28),
        "协议存款": (0.05, 0.10),
        "通知存款": (0.03, 0.06),
        "结构性存款": (0.02, 0.05),
    }
    
    # 各类存款平均利率
    DEPOSIT_RATES = {
        "定期存款": (2.5, 3.2),
        "活期存款": (0.2, 0.35),
        "协议存款": (1.8, 2.5),
        "通知存款": (0.8, 1.2),
        "结构性存款": (2.8, 3.5),
    }
    
    for _, row in loan_target_df.iterrows():
        month = row["统计月份"]
        code = row["机构代码"]
        name = row["机构名称"]
        level = row["机构层级"]
        city = row["所在地市"]
        loan_balance = row["当月贷款余额(亿元)"]
        
        # 存贷比
        ldr = random.uniform(0.60, 0.75)
        deposit_balance = loan_balance / ldr
        
        # 年度目标
        annual_target = deposit_balance * random.uniform(1.06, 1.12)
        
        # 当月新增
        monthly_new = deposit_balance * random.uniform(0.015, 0.04)
        
        # 年累计新增
        month_num = int(month.split("-")[1])
        ytd_new = monthly_new * month_num * random.uniform(0.8, 1.2)
        
        # 目标完成率
        target_rate = (ytd_new / (annual_target * 0.1 * month_num)) * 100
        target_rate = min(max(target_rate, 65), 115) + random.uniform(-5, 5)
        
        yoy = random.uniform(4, 12) if random.random() > 0.15 else random.uniform(-1, 4)
        mom = random.uniform(-1.5, 4)
        
        deposit_target_data.append({
            "统计月份": month,
            "机构代码": code,
            "机构名称": name,
            "机构层级": level,
            "所在地市": city,
            "年度存款目标(亿元)": round(annual_target, 2),
            "当月存款余额(亿元)": round(deposit_balance, 2),
            "当月新增存款(亿元)": round(monthly_new, 2),
            "年累计新增存款(亿元)": round(ytd_new, 2),
            "目标完成率(%)": round(target_rate, 2),
            "同比增长率(%)": round(yoy, 2),
            "环比增长率(%)": round(mom, 2),
        })
        
        # 存款结构明细
        remaining = deposit_balance
        cat_list = list(DEPOSIT_CATEGORIES.items())
        for i, (cat, (low, high)) in enumerate(cat_list):
            if i == len(cat_list) - 1:
                cat_balance = remaining
            else:
                ratio = random.uniform(low, high)
                cat_balance = deposit_balance * ratio
                remaining -= cat_balance
            
            cat_pct = (cat_balance / deposit_balance) * 100 if deposit_balance > 0 else 0
            cat_new = cat_balance * random.uniform(0.015, 0.04)
            rate_low, rate_high = DEPOSIT_RATES[cat]
            avg_rate = random.uniform(rate_low, rate_high)
            
            deposit_structure_data.append({
                "统计月份": month,
                "机构代码": code,
                "机构名称": name,
                "所在地市": city,
                "存款类别": cat,
                "存款余额(亿元)": round(cat_balance, 2),
                "占比(%)": round(cat_pct, 2),
                "当月新增(亿元)": round(cat_new, 2),
                "平均利率(%)": round(avg_rate, 2),
            })
    
    return {
        "存款目标完成情况": pd.DataFrame(deposit_target_data),
        "存款结构明细": pd.DataFrame(deposit_structure_data),
    }


# ============ 资产质量数据生成 ============

def generate_asset_quality_data(org_df: pd.DataFrame, loan_data: Dict) -> pd.DataFrame:
    """生成资产质量数据表"""
    org_dict = get_org_dict(org_df)
    loan_target_df = loan_data["贷款目标完成情况"]
    
    quality_data = []
    
    for _, row in loan_target_df.iterrows():
        month = row["统计月份"]
        code = row["机构代码"]
        name = row["机构名称"]
        level = row["机构层级"]
        city = row["所在地市"]
        loan_balance = row["当月贷款余额(亿元)"]
        
        # 不良率（县区级波动更大，经济发达地区更低）
        city_weight = CITIES.get(city, 0.3)
        base_npl = 2.0 - (city_weight * 0.5)  # 郑州等发达地区不良率低
        
        if level == "县区级":
            npl_rate = base_npl + random.uniform(-0.3, 1.2)
        elif level == "地市级":
            npl_rate = base_npl + random.uniform(-0.2, 0.5)
        else:
            npl_rate = 1.8 + random.uniform(-0.2, 0.3)
        
        npl_rate = max(1.0, min(4.0, npl_rate))
        npl_balance = loan_balance * npl_rate / 100
        
        # 关注类贷款
        watch_rate = npl_rate * random.uniform(1.2, 2.5)
        watch_rate = min(6.0, watch_rate)
        watch_balance = loan_balance * watch_rate / 100
        
        # 逾期贷款
        overdue_balance = npl_balance * random.uniform(1.1, 1.5)
        overdue_90_balance = npl_balance * random.uniform(0.7, 0.95)
        
        # 拨备覆盖率（150%-300%）
        provision_rate = random.uniform(150, 300)
        if npl_rate > 3.0:
            provision_rate = random.uniform(150, 200)
        
        # 拨贷比（2%-4%）
        provision_loan_rate = npl_rate * provision_rate / 100
        provision_loan_rate = min(4.5, max(2.0, provision_loan_rate))
        
        # 核销金额
        writeoff = npl_balance * random.uniform(0.1, 0.3)
        
        quality_data.append({
            "统计月份": month,
            "机构代码": code,
            "机构名称": name,
            "机构层级": level,
            "所在地市": city,
            "贷款余额(亿元)": round(loan_balance, 2),
            "不良贷款余额(亿元)": round(npl_balance, 2),
            "不良贷款率(%)": round(npl_rate, 2),
            "关注类贷款余额(亿元)": round(watch_balance, 2),
            "关注类贷款占比(%)": round(watch_rate, 2),
            "逾期贷款余额(亿元)": round(overdue_balance, 2),
            "逾期90天以上贷款余额(亿元)": round(overdue_90_balance, 2),
            "拨备覆盖率(%)": round(provision_rate, 2),
            "拨贷比(%)": round(provision_loan_rate, 2),
            "核销金额(亿元)": round(writeoff, 2),
        })
    
    return pd.DataFrame(quality_data)


# ============ 经营利润数据生成 ============

def generate_profit_data(org_df: pd.DataFrame, loan_data: Dict, deposit_data: Dict) -> pd.DataFrame:
    """生成经营利润数据表"""
    loan_df = loan_data["贷款目标完成情况"]
    deposit_df = deposit_data["存款目标完成情况"]
    
    profit_data = []
    
    # 合并贷款和存款数据
    merged = loan_df.merge(
        deposit_df[["统计月份", "机构代码", "当月存款余额(亿元)"]],
        on=["统计月份", "机构代码"],
        how="left"
    )
    
    for _, row in merged.iterrows():
        month = row["统计月份"]
        code = row["机构代码"]
        name = row["机构名称"]
        level = row["机构层级"]
        city = row["所在地市"]
        loan_balance = row["当月贷款余额(亿元)"]
        deposit_balance = row["当月存款余额(亿元)"]
        
        # 净息差（1.8%-2.5%）
        nim = random.uniform(1.8, 2.5)
        
        # 利息净收入 = (贷款余额 * 贷款利率 - 存款余额 * 存款利率) / 12
        avg_loan_rate = random.uniform(5.0, 6.5)
        avg_deposit_rate = random.uniform(2.0, 2.8)
        interest_income = (loan_balance * avg_loan_rate / 100 - deposit_balance * avg_deposit_rate / 100) / 12
        interest_income = max(0.1, interest_income)
        
        # 营业收入（利息净收入占80%-90%）
        interest_ratio = random.uniform(0.80, 0.90)
        revenue = interest_income / interest_ratio
        
        # 手续费及佣金净收入
        fee_income = revenue * random.uniform(0.03, 0.08)
        
        # 投资收益
        investment_income = revenue * random.uniform(0.02, 0.06)
        
        # 营业支出（成本收入比30%-45%）
        cost_ratio = random.uniform(0.30, 0.45)
        expense = revenue * cost_ratio
        
        # 资产减值损失
        impairment = revenue * random.uniform(0.08, 0.20)
        
        # 营业利润
        operating_profit = revenue - expense - impairment
        
        # 净利润（考虑税费）
        net_profit = operating_profit * random.uniform(0.72, 0.82)
        
        # ROA、ROE
        total_assets = deposit_balance * 1.1  # 简化：总资产约等于存款*1.1
        equity = total_assets * random.uniform(0.08, 0.12)
        
        roa = (net_profit * 12 / total_assets) * 100  # 年化
        roe = (net_profit * 12 / equity) * 100
        
        roa = max(0.6, min(1.2, roa))
        roe = max(8, min(15, roe))
        
        profit_data.append({
            "统计月份": month,
            "机构代码": code,
            "机构名称": name,
            "机构层级": level,
            "所在地市": city,
            "营业收入(亿元)": round(revenue, 2),
            "利息净收入(亿元)": round(interest_income, 2),
            "手续费及佣金净收入(亿元)": round(fee_income, 2),
            "投资收益(亿元)": round(investment_income, 2),
            "营业支出(亿元)": round(expense, 2),
            "资产减值损失(亿元)": round(impairment, 2),
            "营业利润(亿元)": round(operating_profit, 2),
            "净利润(亿元)": round(net_profit, 2),
            "成本收入比(%)": round(cost_ratio * 100, 2),
            "净息差(%)": round(nim, 2),
            "ROA(%)": round(roa, 2),
            "ROE(%)": round(roe, 2),
        })
    
    return pd.DataFrame(profit_data)


# ============ 客户数据生成 ============

def generate_customer_data(org_df: pd.DataFrame) -> pd.DataFrame:
    """生成客户数据统计表"""
    org_dict = get_org_dict(org_df)
    
    # 基础客户数
    BASE_CUSTOMERS = {
        "省级": {"个人": 6000, "企业": 35},  # 万户
        "地市级": {"个人": 300, "企业": 2},
        "县区级": {"个人": 50, "企业": 0.3},
    }
    
    customer_data = []
    
    for month_idx, month in enumerate(MONTHS):
        growth = 1 + month_idx * 0.003  # 客户数缓慢增长
        
        for code, info in org_dict.items():
            level = info["机构层级"]
            city = info["所在地市"]
            name = info["机构名称"]
            city_weight = CITIES.get(city, 0.3)
            
            base = BASE_CUSTOMERS[level]
            
            if level == "省级":
                # 省级汇总
                personal_total = sum(
                    BASE_CUSTOMERS["地市级"]["个人"] * CITIES.get(i["所在地市"], 0.3) * growth
                    for c, i in org_dict.items() if i["机构层级"] == "地市级"
                )
                corp_total = sum(
                    BASE_CUSTOMERS["地市级"]["企业"] * CITIES.get(i["所在地市"], 0.3) * growth
                    for c, i in org_dict.items() if i["机构层级"] == "地市级"
                )
            else:
                personal_total = base["个人"] * city_weight * growth * random.uniform(0.9, 1.1)
                corp_total = base["企业"] * city_weight * growth * random.uniform(0.85, 1.15)
            
            # 贷款客户和存款客户
            loan_customers = personal_total * random.uniform(0.15, 0.25)
            deposit_customers = personal_total * random.uniform(0.70, 0.85)
            
            # 新增客户
            new_personal = personal_total * random.uniform(0.005, 0.015)
            new_corp = corp_total * random.uniform(0.01, 0.03) * 10000  # 转为户
            
            # 电子银行和手机银行
            e_bank_ratio = random.uniform(0.50, 0.70)
            mobile_active_ratio = random.uniform(0.30, 0.50)
            e_bank = personal_total * e_bank_ratio
            mobile_active = personal_total * mobile_active_ratio
            
            customer_data.append({
                "统计月份": month,
                "机构代码": code,
                "机构名称": name,
                "机构层级": level,
                "所在地市": city,
                "个人客户总数(万户)": round(personal_total, 2),
                "企业客户总数(户)": int(corp_total * 10000),
                "贷款客户数(万户)": round(loan_customers, 2),
                "存款客户数(万户)": round(deposit_customers, 2),
                "新增个人客户(户)": int(new_personal * 10000),
                "新增企业客户(户)": int(new_corp),
                "电子银行客户数(万户)": round(e_bank, 2),
                "手机银行活跃客户数(万户)": round(mobile_active, 2),
            })
    
    return pd.DataFrame(customer_data)


# ============ 主函数 ============

def main():
    print("=" * 60)
    print("河南农商银行经营数据Mock生成器")
    print("=" * 60)
    
    # 1. 生成机构信息表
    print("\n[1/6] 生成机构信息表...")
    org_df = generate_org_info()
    org_path = os.path.join(OUTPUT_DIR, "机构信息表.xlsx")
    org_df.to_excel(org_path, index=False, engine='openpyxl')
    print(f"  - 共{len(org_df)}个机构")
    print(f"  - 保存至: {org_path}")
    
    # 2. 生成贷款业务数据表
    print("\n[2/6] 生成贷款业务数据表...")
    loan_data = generate_loan_data(org_df)
    loan_path = os.path.join(OUTPUT_DIR, "贷款业务数据表.xlsx")
    with pd.ExcelWriter(loan_path, engine='openpyxl') as writer:
        for sheet_name, df in loan_data.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    print(f"  - 贷款目标完成情况: {len(loan_data['贷款目标完成情况'])}条")
    print(f"  - 贷款结构明细: {len(loan_data['贷款结构明细'])}条")
    print(f"  - 贷款期限分布: {len(loan_data['贷款期限分布'])}条")
    print(f"  - 保存至: {loan_path}")
    
    # 3. 生成存款业务数据表
    print("\n[3/6] 生成存款业务数据表...")
    deposit_data = generate_deposit_data(org_df, loan_data)
    deposit_path = os.path.join(OUTPUT_DIR, "存款业务数据表.xlsx")
    with pd.ExcelWriter(deposit_path, engine='openpyxl') as writer:
        for sheet_name, df in deposit_data.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    print(f"  - 存款目标完成情况: {len(deposit_data['存款目标完成情况'])}条")
    print(f"  - 存款结构明细: {len(deposit_data['存款结构明细'])}条")
    print(f"  - 保存至: {deposit_path}")
    
    # 4. 生成资产质量数据表
    print("\n[4/6] 生成资产质量数据表...")
    quality_df = generate_asset_quality_data(org_df, loan_data)
    quality_path = os.path.join(OUTPUT_DIR, "资产质量数据表.xlsx")
    quality_df.to_excel(quality_path, index=False, engine='openpyxl')
    print(f"  - 共{len(quality_df)}条记录")
    print(f"  - 保存至: {quality_path}")
    
    # 5. 生成经营利润数据表
    print("\n[5/6] 生成经营利润数据表...")
    profit_df = generate_profit_data(org_df, loan_data, deposit_data)
    profit_path = os.path.join(OUTPUT_DIR, "经营利润数据表.xlsx")
    profit_df.to_excel(profit_path, index=False, engine='openpyxl')
    print(f"  - 共{len(profit_df)}条记录")
    print(f"  - 保存至: {profit_path}")
    
    # 6. 生成客户数据统计表
    print("\n[6/6] 生成客户数据统计表...")
    customer_df = generate_customer_data(org_df)
    customer_path = os.path.join(OUTPUT_DIR, "客户数据统计表.xlsx")
    customer_df.to_excel(customer_path, index=False, engine='openpyxl')
    print(f"  - 共{len(customer_df)}条记录")
    print(f"  - 保存至: {customer_path}")
    
    print("\n" + "=" * 60)
    print("所有文件生成完成！")
    print("=" * 60)
    
    # 打印数据汇总
    print("\n数据汇总:")
    print(f"  - 机构数: {len(org_df)} (省级1, 地市级{len([x for x in org_df['机构层级'] if x=='地市级'])}, 县区级{len([x for x in org_df['机构层级'] if x=='县区级'])})")
    print(f"  - 时间范围: {MONTHS[0]} 至 {MONTHS[-1]} ({len(MONTHS)}个月)")
    
    # 验证数据一致性
    print("\n数据一致性验证:")
    sample_month = "2024-12"
    loan_sample = loan_data["贷款目标完成情况"]
    province_loan = loan_sample[(loan_sample["统计月份"]==sample_month) & (loan_sample["机构层级"]=="省级")]["当月贷款余额(亿元)"].values[0]
    city_loan_sum = loan_sample[(loan_sample["统计月份"]==sample_month) & (loan_sample["机构层级"]=="地市级")]["当月贷款余额(亿元)"].sum()
    print(f"  - {sample_month}省级贷款余额: {province_loan:.2f}亿元")
    print(f"  - {sample_month}地市级贷款合计: {city_loan_sum:.2f}亿元")
    print(f"  - 差异率: {abs(province_loan-city_loan_sum)/province_loan*100:.2f}%")


if __name__ == "__main__":
    main()
