# Load Test Overview

- Generated at: `2026-03-19T18:49:58`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`
- Output directory: `bench_results/20260319-184941`

| Mode | Highest Tested | Tested Levels | Note |
| --- | --- | --- | --- |
| offline | 1 | 1 | raw metrics only; no threshold verdict |
