# Load Test Report: offline

## Scenario
- Generated at: `2026-03-19T17:29:46`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`

## Overview
- Highest tested concurrency: `1`
- Tested levels: `1`
- Note: raw metrics only; no threshold verdict

## Observations
| Concurrency | Successes | Failures | Success Rate | Error Rate | Interim Msgs | Final Msgs | Interim p95 ms | Interim p99 ms | Final p95 ms | Final p99 ms | Error Summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 0 | 1 | 0.00% | 100.00% | 0 | 4 | - | - | 14204.20 | 14204.20 | final_timeout=1 |
