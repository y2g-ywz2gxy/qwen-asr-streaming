# Load Test Report: 2pass

## Scenario
- Generated at: `2026-03-19T15:47:15`
- Endpoint: `ws://0.0.0.0:10095/ws/asr`
- WAV: `../test.wav`

## Overview
- Highest tested concurrency: `16`
- Tested levels: `2,4,6,8,10,12,16`
- Note: raw metrics only; no threshold verdict

## Observations
| Concurrency | Successes | Failures | Success Rate | Error Rate | Interim Msgs | Final Msgs | Interim p95 ms | Interim p99 ms | Final p95 ms | Final p99 ms | Error Summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | 0 | 2 | 0.00% | 100.00% | 0 | 0 | - | - | - | - | ConnectionRefusedError=2 |
| 4 | 0 | 4 | 0.00% | 100.00% | 0 | 0 | - | - | - | - | ConnectionRefusedError=4 |
| 6 | 0 | 6 | 0.00% | 100.00% | 0 | 0 | - | - | - | - | ConnectionRefusedError=6 |
| 8 | 0 | 8 | 0.00% | 100.00% | 0 | 0 | - | - | - | - | ConnectionRefusedError=8 |
| 10 | 0 | 10 | 0.00% | 100.00% | 0 | 0 | - | - | - | - | ConnectionRefusedError=10 |
| 12 | 0 | 12 | 0.00% | 100.00% | 0 | 0 | - | - | - | - | ConnectionRefusedError=12 |
| 16 | 0 | 16 | 0.00% | 100.00% | 0 | 0 | - | - | - | - | ConnectionRefusedError=16 |
