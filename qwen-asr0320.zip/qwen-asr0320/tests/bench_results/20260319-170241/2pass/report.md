# Load Test Report: 2pass

## Scenario
- Generated at: `2026-03-19T17:03:40`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`

## Overview
- Highest tested concurrency: `1`
- Tested levels: `1`
- Note: raw metrics only; no threshold verdict

## Observations
| Concurrency | Successes | Failures | Success Rate | Error Rate | Interim Msgs | Final Msgs | Interim p95 ms | Interim p99 ms | Final p95 ms | Final p99 ms | Error Summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 0 | 1 | 0.00% | 100.00% | 3 | 4 | 10510.59 | 10510.59 | 14263.32 | 14263.32 | final_timeout=1 |
