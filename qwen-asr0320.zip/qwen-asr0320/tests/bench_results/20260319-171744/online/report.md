# Load Test Report: online

## Scenario
- Generated at: `2026-03-19T17:17:59`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`

## Overview
- Highest tested concurrency: `1`
- Tested levels: `1`
- Note: raw metrics only; no threshold verdict

## Observations
| Concurrency | Successes | Failures | Success Rate | Error Rate | Interim Msgs | Final Msgs | Interim p95 ms | Interim p99 ms | Final p95 ms | Final p99 ms | Error Summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 0 | 100.00% | 0.00% | 3 | 4 | 10539.10 | 10539.10 | 14216.85 | 14216.85 | none |
