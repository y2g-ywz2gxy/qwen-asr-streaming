# Load Test Overview

- Generated at: `2026-03-19T17:17:59`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`
- Output directory: `bench_results/20260319-171744`

| Mode | Highest Tested | Tested Levels | Note |
| --- | --- | --- | --- |
| online | 1 | 1 | raw metrics only; no threshold verdict |
