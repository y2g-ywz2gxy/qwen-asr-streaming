# Load Test Overview

- Generated at: `2026-03-19T15:58:14`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`
- Output directory: `bench_results/20260319-155117`

| Mode | Highest Tested | Tested Levels | Note |
| --- | --- | --- | --- |
| offline | 16 | 2,4,6,8,10,12,16 | raw metrics only; no threshold verdict |
| online | 16 | 2,4,6,8,10,12,16 | raw metrics only; no threshold verdict |
| 2pass | 16 | 2,4,6,8,10,12,16 | raw metrics only; no threshold verdict |
