# Load Test Report: online

## Scenario
- Generated at: `2026-03-19T15:55:37`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`

## Overview
- Highest tested concurrency: `16`
- Tested levels: `2,4,6,8,10,12,16`
- Note: raw metrics only; no threshold verdict

## Observations
| Concurrency | Successes | Failures | Success Rate | Error Rate | Interim Msgs | Final Msgs | Interim p95 ms | Interim p99 ms | Final p95 ms | Final p99 ms | Error Summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | 2 | 0 | 100.00% | 0.00% | 6 | 8 | 10749.91 | 10749.91 | 14388.70 | 14388.70 | none |
| 4 | 4 | 0 | 100.00% | 0.00% | 12 | 16 | 10818.36 | 10916.25 | 14525.26 | 14604.81 | none |
| 6 | 6 | 0 | 100.00% | 0.00% | 18 | 24 | 10998.70 | 11097.83 | 14620.99 | 14696.42 | none |
| 8 | 8 | 0 | 100.00% | 0.00% | 24 | 32 | 11223.97 | 11321.36 | 14721.48 | 14874.48 | none |
| 10 | 8 | 2 | 80.00% | 20.00% | 24 | 32 | 11215.60 | 11314.14 | 14743.66 | 14900.70 | ConnectionClosedError=2 |
| 12 | 8 | 4 | 66.67% | 33.33% | 24 | 32 | 11258.72 | 11359.37 | 14753.89 | 14913.23 | ConnectionClosedError=4 |
| 16 | 8 | 8 | 50.00% | 50.00% | 24 | 32 | 11276.52 | 11378.43 | 14758.59 | 14923.96 | ConnectionClosedError=8 |
