# Load Test Report: offline

## Scenario
- Generated at: `2026-03-19T15:53:54`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`

## Overview
- Highest tested concurrency: `16`
- Tested levels: `2,4,6,8,10,12,16`
- Note: raw metrics only; no threshold verdict

## Observations
| Concurrency | Successes | Failures | Success Rate | Error Rate | Interim Msgs | Final Msgs | Interim p95 ms | Interim p99 ms | Final p95 ms | Final p99 ms | Error Summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | 0 | 2 | 0.00% | 100.00% | 0 | 8 | - | - | 14440.36 | 14440.36 | final_timeout=2 |
| 4 | 0 | 4 | 0.00% | 100.00% | 0 | 16 | - | - | 14606.83 | 14685.52 | final_timeout=4 |
| 6 | 0 | 6 | 0.00% | 100.00% | 0 | 24 | - | - | 14617.22 | 14696.41 | final_timeout=6 |
| 8 | 0 | 8 | 0.00% | 100.00% | 0 | 32 | - | - | 14727.76 | 14880.16 | final_timeout=8 |
| 10 | 0 | 10 | 0.00% | 100.00% | 0 | 32 | - | - | 14716.47 | 14871.77 | ConnectionClosedError=2; final_timeout=8 |
| 12 | 0 | 12 | 0.00% | 100.00% | 0 | 32 | - | - | 14708.17 | 14859.42 | ConnectionClosedError=4; final_timeout=8 |
| 16 | 0 | 16 | 0.00% | 100.00% | 0 | 32 | - | - | 14718.91 | 14874.47 | ConnectionClosedError=8; final_timeout=8 |
