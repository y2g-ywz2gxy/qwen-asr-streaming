# Load Test Report: 2pass

## Scenario
- Generated at: `2026-03-19T15:58:14`
- Endpoint: `ws://0.0.0.0:8001/ws/asr`
- WAV: `../test.wav`

## Overview
- Highest tested concurrency: `16`
- Tested levels: `2,4,6,8,10,12,16`
- Note: raw metrics only; no threshold verdict

## Observations
| Concurrency | Successes | Failures | Success Rate | Error Rate | Interim Msgs | Final Msgs | Interim p95 ms | Interim p99 ms | Final p95 ms | Final p99 ms | Error Summary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2 | 0 | 2 | 0.00% | 100.00% | 6 | 8 | 10706.84 | 10706.84 | 14538.32 | 14538.32 | final_timeout=2 |
| 4 | 0 | 4 | 0.00% | 100.00% | 12 | 16 | 10838.51 | 10940.18 | 14761.35 | 14916.69 | final_timeout=4 |
| 6 | 0 | 6 | 0.00% | 100.00% | 18 | 24 | 11013.56 | 11114.57 | 15002.91 | 15153.86 | final_timeout=6 |
| 8 | 0 | 8 | 0.00% | 100.00% | 24 | 32 | 11230.46 | 11329.57 | 15172.12 | 15472.60 | final_timeout=8 |
| 10 | 0 | 10 | 0.00% | 100.00% | 24 | 32 | 11217.06 | 11316.32 | 15160.17 | 15457.96 | ConnectionClosedError=2; final_timeout=8 |
| 12 | 0 | 12 | 0.00% | 100.00% | 24 | 32 | 11199.80 | 11296.46 | 15135.82 | 15427.51 | ConnectionClosedError=4; final_timeout=8 |
| 16 | 0 | 16 | 0.00% | 100.00% | 24 | 32 | 11207.36 | 11305.75 | 15148.27 | 15447.52 | ConnectionClosedError=8; final_timeout=8 |
