from __future__ import annotations

from fastapi.testclient import TestClient

from server.app import create_app
from server.engine import BackendProtocol, StreamResult
from server.settings import AppSettings, SessionConfig

VAD_FRAME_BYTES = 640


class FakeBackend(BackendProtocol):
    def __init__(self, settings: AppSettings):
        self.settings = settings

    def warmup(self) -> None:
        return None

    def create_stream_state(self, config: SessionConfig) -> dict[str, object]:
        return {
            "chunks": 0,
            "label": self._label(config),
        }

    def refresh_stream_context(
        self,
        state: dict[str, object],
        config: SessionConfig,
    ) -> dict[str, object]:
        return {
            **state,
            "label": self._label(config),
        }

    def streaming_transcribe(self, pcm_bytes: bytes, state: dict[str, object]) -> StreamResult:
        state["chunks"] = int(state["chunks"]) + 1
        return StreamResult(text=f"partial-{state['chunks']}-{state['label']}", language="zh")

    def finish_stream(self, state: dict[str, object]) -> StreamResult:
        return StreamResult(text=f"online-final-{state['chunks']}-{state['label']}", language="zh")

    def transcribe_segment(self, pcm_bytes: bytes, config: SessionConfig) -> StreamResult:
        return StreamResult(
            text=f"{config.mode}-final-{len(pcm_bytes)}-{self._label(config)}",
            language="zh",
        )

    def _label(self, config: SessionConfig) -> str:
        return ",".join(config.hotword_terms) or "none"


def build_client() -> TestClient:
    return build_client_with_backend(FakeBackend)


def build_client_with_backend(backend_factory: type[BackendProtocol]) -> TestClient:
    settings = AppSettings(
        warmup_enabled=False,
        frontend_path=AppSettings().frontend_path,
    )
    return TestClient(create_app(settings=settings, backend_factory=backend_factory))


def finish_segment(ws) -> dict[str, object]:
    ws.send_text('{"is_speaking": false}')
    return ws.receive_json()


class SequenceVad:
    frame_bytes = VAD_FRAME_BYTES
    frame_duration_ms = 20

    def __init__(self, decisions: list[bool]):
        self._decisions = decisions
        self._index = 0

    def process(self, audio_bytes: bytes) -> bool:
        assert len(audio_bytes) == self.frame_bytes
        if self._index >= len(self._decisions):
            return False
        decision = self._decisions[self._index]
        self._index += 1
        return decision


class NumeralBackend(BackendProtocol):
    def __init__(self, settings: AppSettings):
        self.settings = settings

    def warmup(self) -> None:
        return None

    def create_stream_state(self, config: SessionConfig) -> dict[str, object]:
        return {"chunks": 0}

    def refresh_stream_context(
        self,
        state: dict[str, object],
        config: SessionConfig,
    ) -> dict[str, object]:
        return state

    def streaming_transcribe(self, pcm_bytes: bytes, state: dict[str, object]) -> StreamResult:
        state["chunks"] = int(state["chunks"]) + 1
        return StreamResult(text="一二三", language="zh")

    def finish_stream(self, state: dict[str, object]) -> StreamResult:
        return StreamResult(text="一二三", language="zh")

    def transcribe_segment(self, pcm_bytes: bytes, config: SessionConfig) -> StreamResult:
        return StreamResult(text="一百二十三", language="zh")


def test_ready_alias_matches_healthz() -> None:
    with build_client() as client:
        healthz_response = client.get("/healthz")
        ready_response = client.get("/ready")

    assert healthz_response.status_code == 200
    assert ready_response.status_code == 200
    assert ready_response.json() == healthz_response.json()


def test_favicon_route_is_served() -> None:
    with build_client() as client:
        response = client.get("/favicon.ico")

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("image/svg+xml")
    assert "<svg" in response.text


def test_two_pass_flow_returns_final_segment_result_and_keeps_connection_open() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"none"}}'
            )
            ws.send_bytes(audio_chunk)
            interim = ws.receive_json()
            assert interim["mode"] == "2pass-online"

            sentence_payload = finish_segment(ws)

            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"] == "2pass-final-19200-none"
            assert sentence_payload["is_final"] is True

            ws.send_bytes(audio_chunk)
            next_interim = ws.receive_json()
            assert next_interim["mode"] == "2pass-online"
            assert next_interim["text"] == "partial-1-none"
            assert next_interim["is_final"] is False


def test_offline_mode_returns_final_segment_result_and_keeps_connection_open() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"none"}}'
            )
            ws.send_bytes(audio_chunk)
            sentence_payload = finish_segment(ws)
            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"] == "offline-final-19200-none"
            assert sentence_payload["is_final"] is True

            ws.send_bytes(audio_chunk)
            next_sentence_payload = finish_segment(ws)
            assert next_sentence_payload["mode"] == "2pass-offline"
            assert next_sentence_payload["text"] == "offline-final-19200-none"
            assert next_sentence_payload["is_final"] is True


def test_online_mode_returns_final_segment_result_and_keeps_connection_open() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"online","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"none"}}'
            )
            ws.send_bytes(audio_chunk)
            interim = ws.receive_json()
            assert interim["mode"] == "2pass-online"
            assert interim["text"] == "partial-1-none"
            assert interim["is_final"] is False

            final_payload = finish_segment(ws)
            assert final_payload["mode"] == "2pass-offline"
            assert final_payload["text"] == "online-final-1-none"
            assert final_payload["is_final"] is True

            ws.send_bytes(audio_chunk)
            next_interim = ws.receive_json()
            assert next_interim["mode"] == "2pass-online"
            assert next_interim["text"] == "partial-1-none"
            assert next_interim["is_final"] is False


def test_default_vad_auto_finalizes_offline_segments(
    monkeypatch,
) -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    decisions = [True] * 10 + [False] * 10 + [False] * 10
    monkeypatch.setattr(
        "server.app.create_vad",
        lambda aggressiveness: SequenceVad(decisions),  # noqa: ARG005
    )

    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"server_vad","silence_duration_ms":200,"max_segment_ms":20000}}'
            )
            ws.send_bytes(audio_chunk)

            sentence_payload = ws.receive_json()
            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"] == "offline-final-12800-none"
            assert sentence_payload["is_final"] is False

            ws.send_text('{"is_speaking": false}')
            ws.send_text("HeartBeat")
            assert ws.receive_text() == "HeartBeat"


def test_default_vad_auto_finalizes_online_segments_and_explicit_end_returns_empty_final_ack(
    monkeypatch,
) -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    decisions = [True] * 10 + [False] * 10 + [False] * 10
    monkeypatch.setattr(
        "server.app.create_vad",
        lambda aggressiveness: SequenceVad(decisions),  # noqa: ARG005
    )

    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"online","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"server_vad","silence_duration_ms":200,"max_segment_ms":20000}}'
            )
            ws.send_bytes(audio_chunk)

            interim = ws.receive_json()
            assert interim["mode"] == "2pass-online"
            assert interim["text"] == "partial-1-none"
            assert interim["is_final"] is False

            sentence_payload = ws.receive_json()
            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"] == "online-final-1-none"
            assert sentence_payload["is_final"] is False

            ws.send_text('{"is_speaking": false}')
            final_ack = ws.receive_json()
            assert final_ack["mode"] == "2pass-offline"
            assert final_ack["text"] == ""
            assert final_ack["is_final"] is True

            ws.send_text('{"is_speaking": false}')
            ws.send_text("HeartBeat")
            assert ws.receive_text() == "HeartBeat"


def test_server_vad_falls_back_to_max_segment_ms_for_continuous_speech(
    monkeypatch,
) -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    monkeypatch.setattr(
        "server.app.create_vad",
        lambda aggressiveness: SequenceVad([True] * 30),  # noqa: ARG005
    )

    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"server_vad","silence_duration_ms":200,"max_segment_ms":600}}'
            )
            ws.send_bytes(audio_chunk)

            sentence_payload = ws.receive_json()
            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"] == "offline-final-19200-none"
            assert sentence_payload["is_final"] is False


def test_hotwords_update_is_applied_before_finalize() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"none"}}'
            )
            ws.send_bytes(audio_chunk)
            interim = ws.receive_json()
            assert interim["text"].endswith("-none")

            ws.send_text('{"hotwords":"{\\"Alibaba\\":20,\\"TongyiLab\\":30}"}')
            sentence_payload = finish_segment(ws)

            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"].endswith("-Alibaba,TongyiLab")
            assert sentence_payload["is_final"] is True


def test_offline_init_hotwords_are_applied_to_final_result() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"hotwords":"{\\"Alibaba\\":20}","turn_detection":{"type":"none"}}'
            )
            ws.send_bytes(audio_chunk)
            sentence_payload = finish_segment(ws)

            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"].endswith("-Alibaba")
            assert sentence_payload["is_final"] is True


def test_invalid_hotwords_update_returns_protocol_error() -> None:
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"none"}}'
            )
            ws.send_text('{"hotwords":"Alibaba"}')
            error_payload = ws.receive_json()

            assert error_payload["event"] == "error"
            assert error_payload["code"] == "INVALID_HOTWORDS"


def test_two_pass_final_applies_itn_without_mutating_partial() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client_with_backend(NumeralBackend) as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"itn":true,"turn_detection":{"type":"none"}}'
            )
            ws.send_bytes(audio_chunk)
            interim = ws.receive_json()
            assert interim["text"] == "一二三"

            sentence_payload = finish_segment(ws)

            assert sentence_payload["mode"] == "2pass-offline"
            assert sentence_payload["text"] == "123"
            assert sentence_payload["is_final"] is True


def test_explicit_segment_end_without_audio_is_ignored() -> None:
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"none"}}'
            )
            ws.send_text('{"is_speaking": false}')
            ws.send_text("HeartBeat")
            assert ws.receive_text() == "HeartBeat"


def test_redundant_explicit_segment_end_after_real_final_is_ignored() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"online","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"turn_detection":{"type":"none"}}'
            )
            ws.send_bytes(audio_chunk)
            ws.receive_json()

            final_payload = finish_segment(ws)
            assert final_payload["mode"] == "2pass-offline"
            assert final_payload["text"] == "online-final-1-none"
            assert final_payload["is_final"] is True

            ws.send_text('{"is_speaking": false}')
            ws.send_text("HeartBeat")
            assert ws.receive_text() == "HeartBeat"
