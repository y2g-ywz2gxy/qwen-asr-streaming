#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import csv
import json
import time
import wave
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from statistics import mean
from typing import Sequence

try:
    import numpy as np
except ImportError as exc:
    raise SystemExit(
        "Install project dependencies before running the load test: pip install -r requirements.txt"
    ) from exc


try:
    import websockets
except ImportError as exc:
    raise SystemExit(
        "Install the websockets package before running the load test: pip install websockets"
    ) from exc


FRAME_MS = 60
INTERNAL_SAMPLE_RATE = 16_000
SUPPORTED_MODES = ("offline", "online", "2pass")
AUTO_FINAL_SEGMENT_MODES = {"offline", "2pass"}
#DEFAULT_CONCURRENCY = "2,4,6,8,10,12,16"
DEFAULT_CONCURRENCY = "1"
SUPPORTED_PROTOCOL_SAMPLE_RATES = {8000, INTERNAL_SAMPLE_RATE}
DEFAULT_SERVER_VAD_SILENCE_MS = 450
DEFAULT_SERVER_VAD_IDLE_TIMEOUT_SEC = 3.0


@dataclass(slots=True)
class ClientRunResult:
    interim_latencies: list[float]
    final_latencies: list[float]
    sentence_latency_ms: float | None
    segment_final_latency_ms: float | None
    errors: list[str]

    @property
    def final_received(self) -> bool:
        return (
            self.sentence_latency_ms is not None
            or self.segment_final_latency_ms is not None
        )


@dataclass(slots=True)
class RunResult:
    mode: str
    concurrency: int
    client_successes: int
    client_failures: int
    success_rate: float
    error_rate: float
    interim_messages: int
    final_messages: int
    interim_p95_ms: float
    interim_p99_ms: float
    final_p95_ms: float
    final_p99_ms: float
    mean_interim_ms: float
    mean_final_ms: float
    error_summary: str


@dataclass(slots=True)
class ModeSummary:
    mode: str
    highest_tested_concurrency: int
    tested_levels: str
    note: str


@dataclass(slots=True)
class ListenerState:
    message_count: int = 0
    final_count: int = 0
    last_message_at: float = 0.0


def expects_auto_segment_result(mode: str, server_vad_enabled: bool) -> bool:
    return server_vad_enabled and mode in AUTO_FINAL_SEGMENT_MODES


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = int(round((len(ordered) - 1) * p))
    return round(ordered[index], 2)


def format_ms(value: float) -> str:
    return "-" if value <= 0 else f"{value:.2f}"


def format_rate(value: float) -> str:
    return f"{value * 100:.2f}%"


def parse_modes(raw_modes: str | None, legacy_modes: Sequence[str] | None) -> list[str]:
    if legacy_modes:
        return list(dict.fromkeys(legacy_modes))
    if not raw_modes:
        return list(SUPPORTED_MODES)
    modes = [item.strip() for item in raw_modes.split(",") if item.strip()]
    if not modes:
        raise ValueError("at least one mode must be provided")
    invalid = [item for item in modes if item not in SUPPORTED_MODES]
    if invalid:
        raise ValueError(f"unsupported modes: {', '.join(invalid)}")
    return list(dict.fromkeys(modes))


def parse_concurrency_levels(raw: str) -> list[int]:
    levels = [int(item.strip()) for item in raw.split(",") if item.strip()]
    if not levels or any(level <= 0 for level in levels):
        raise ValueError("concurrency levels must be positive integers")
    return levels


def build_init_payload(
    mode: str,
    wav_name: str,
    audio_fs: int,
    server_vad_enabled: bool,
    server_vad_silence_ms: int,
) -> dict[str, object]:
    payload: dict[str, object] = {
        "mode": mode,
        "wav_name": wav_name,
        "is_speaking": True,
        "wav_format": "pcm",
        "audio_fs": audio_fs,
        "chunk_size": [5, 10, 5],
        "itn": True,
    }
    if server_vad_enabled:
        payload["turn_detection"] = {
            "type": "server_vad",
            "silence_duration_ms": server_vad_silence_ms,
        }
    else:
        payload["turn_detection"] = {"type": "none"}
    return payload


def markdown_table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    header_row = "| " + " | ".join(headers) + " |"
    separator_row = "| " + " | ".join("---" for _ in headers) + " |"
    body_rows = ["| " + " | ".join(row) + " |" for row in rows]
    return "\n".join([header_row, separator_row, *body_rows])


def render_console_table(results: Sequence[RunResult]) -> str:
    headers = [
        "mode",
        "conc",
        "success",
        "error_rate",
        "interim_p95",
        "interim_p99",
        "final_p95",
        "final_p99",
        "errors",
    ]
    rows = [
        [
            result.mode,
            str(result.concurrency),
            format_rate(result.success_rate),
            format_rate(result.error_rate),
            format_ms(result.interim_p95_ms),
            format_ms(result.interim_p99_ms),
            format_ms(result.final_p95_ms),
            format_ms(result.final_p99_ms),
            result.error_summary,
        ]
        for result in results
    ]
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in rows))
        for index in range(len(headers))
    ]

    def join_row(columns: Sequence[str]) -> str:
        return "  ".join(
            column.ljust(widths[index]) for index, column in enumerate(columns)
        )

    lines = [join_row(headers), join_row(["-" * width for width in widths])]
    lines.extend(join_row(row) for row in rows)
    return "\n".join(lines)


def render_overview_console_table(summaries: Sequence[ModeSummary]) -> str:
    headers = [
        "mode",
        "highest_tested",
        "tested_levels",
        "note",
    ]
    rows = [
        [
            summary.mode,
            str(summary.highest_tested_concurrency),
            summary.tested_levels,
            summary.note,
        ]
        for summary in summaries
    ]
    widths = [
        max(len(headers[index]), *(len(row[index]) for row in rows))
        for index in range(len(headers))
    ]

    def join_row(columns: Sequence[str]) -> str:
        return "  ".join(
            column.ljust(widths[index]) for index, column in enumerate(columns)
        )

    lines = [join_row(headers), join_row(["-" * width for width in widths])]
    lines.extend(join_row(row) for row in rows)
    return "\n".join(lines)


def resample_int16(audio: np.ndarray, src_rate: int, dst_rate: int) -> np.ndarray:
    if src_rate == dst_rate or audio.size == 0:
        return np.asarray(audio, dtype=np.int16)
    duration = audio.shape[0] / float(src_rate)
    dst_len = max(1, int(round(duration * dst_rate)))
    src_x = np.linspace(0.0, duration, num=audio.shape[0], endpoint=False)
    dst_x = np.linspace(0.0, duration, num=dst_len, endpoint=False)
    resampled = np.interp(dst_x, src_x, audio.astype(np.float32))
    clipped = np.clip(np.round(resampled), -32768, 32767)
    return clipped.astype(np.int16)


def decode_wav_samples(audio_bytes: bytes, sample_width: int) -> np.ndarray:
    if sample_width == 1:
        audio = np.frombuffer(audio_bytes, dtype=np.uint8).astype(np.int16)
        return ((audio - 128) << 8).astype(np.int16)
    if sample_width == 2:
        return np.frombuffer(audio_bytes, dtype="<i2").astype(np.int16)
    if sample_width == 3:
        raw = np.frombuffer(audio_bytes, dtype=np.uint8)
        if raw.size % 3 != 0:
            raise ValueError("24-bit PCM payload is misaligned")
        packed = raw.reshape(-1, 3).astype(np.int32)
        audio = packed[:, 0] | (packed[:, 1] << 8) | (packed[:, 2] << 16)
        sign_bit = 1 << 23
        audio = (audio ^ sign_bit) - sign_bit
        return np.clip(np.round(audio / 256.0), -32768, 32767).astype(np.int16)
    if sample_width == 4:
        audio = np.frombuffer(audio_bytes, dtype="<i4").astype(np.int32)
        return np.clip(np.round(audio / 65536.0), -32768, 32767).astype(np.int16)
    raise ValueError(f"unsupported PCM sample width: {sample_width * 8}-bit")


def downmix_to_mono(audio: np.ndarray, channels: int) -> np.ndarray:
    if channels <= 0:
        raise ValueError("channel count must be positive")
    if channels == 1:
        return np.asarray(audio, dtype=np.int16)
    if audio.size % channels != 0:
        raise ValueError("PCM payload does not align to channel count")
    mono = audio.reshape(-1, channels).astype(np.int32).mean(axis=1)
    return np.clip(np.round(mono), -32768, 32767).astype(np.int16)


def read_pcm_frames(path: Path) -> tuple[list[bytes], int]:
    with wave.open(str(path), "rb") as wav:
        if wav.getcomptype() != "NONE":
            raise ValueError(f"{path} must be an uncompressed PCM wav")
        sample_width = wav.getsampwidth()
        channels = wav.getnchannels()
        sample_rate = wav.getframerate()
        payload = wav.readframes(wav.getnframes())

    audio = decode_wav_samples(payload, sample_width)
    audio = downmix_to_mono(audio, channels)

    if sample_rate not in SUPPORTED_PROTOCOL_SAMPLE_RATES:
        audio = resample_int16(audio, sample_rate, INTERNAL_SAMPLE_RATE)
        sample_rate = INTERNAL_SAMPLE_RATE

    frame_samples = sample_rate * FRAME_MS // 1000
    if frame_samples <= 0:
        raise ValueError(f"{path} has invalid sample rate: {sample_rate}")
    frames = [
        audio[start : start + frame_samples].tobytes()
        for start in range(0, audio.size, frame_samples)
        if audio[start : start + frame_samples].size
    ]
    return frames, sample_rate


async def collect_messages(
    ws: websockets.WebSocketClientProtocol,
    interim_latencies: list[float],
    final_latencies: list[float],
    sentence_latencies: list[float],
    segment_final_latencies: list[float],
    timing: dict[str, float],
    final_event: asyncio.Event,
    listener_state: ListenerState,
    errors: list[str],
    success_on_sentence_result: bool,
) -> None:
    try:
        while True:
            message = await ws.recv()
            now = time.perf_counter()
            payload = json.loads(message)
            print(f"payload={payload}")
            listener_state.message_count += 1
            listener_state.last_message_at = now
            if payload.get("event") == "error":
                code = payload.get("code", "UNKNOWN")
                details = payload.get("message", "")
                errors.append(f"server_error:{code}:{details}")
                final_event.set()
                return
            elapsed_ms = (now - timing["segment_start"]) * 1000.0
            if payload.get("is_final"):
                listener_state.final_count += 1
                final_latencies.append(round(elapsed_ms, 2))
                segment_final_latencies.append(round(elapsed_ms, 2))
                final_event.set()
            elif payload.get("mode") == "2pass-offline":
                sentence_latencies.append(round(elapsed_ms, 2))
                final_latencies.append(round(elapsed_ms, 2))
                if success_on_sentence_result:
                    final_event.set()
            else:
                interim_latencies.append(round(elapsed_ms, 2))
    except asyncio.CancelledError:
        raise
    except websockets.ConnectionClosed as exc:
        listener_state.last_message_at = time.perf_counter()
        errors.append(f"connection_closed:{exc.code}")
        final_event.set()
    except json.JSONDecodeError:
        listener_state.last_message_at = time.perf_counter()
        errors.append("invalid_json_response")
        final_event.set()


async def wait_for_listener_quiet(
    listener_state: ListenerState,
    quiet_period_sec: float,
    deadline: float,
) -> None:
    while True:
        now = time.perf_counter()
        remaining_sec = deadline - now
        if remaining_sec <= 0:
            return
        quiet_for_sec = now - listener_state.last_message_at
        quiet_remaining_sec = quiet_period_sec - quiet_for_sec
        if quiet_remaining_sec <= 0:
            return
        await asyncio.sleep(min(0.05, quiet_remaining_sec, remaining_sec))


async def run_client(
    endpoint: str,
    mode: str,
    wav_name: str,
    frames: list[bytes],
    audio_fs: int,
    final_timeout_sec: float,
    server_vad_enabled: bool,
    server_vad_silence_ms: int,
    server_vad_idle_timeout_sec: float,
) -> ClientRunResult:
    interim_latencies: list[float] = []
    final_latencies: list[float] = []
    sentence_latencies: list[float] = []
    segment_final_latencies: list[float] = []
    errors: list[str] = []
    timing = {"segment_start": time.perf_counter()}
    final_event = asyncio.Event()
    listener_state = ListenerState(last_message_at=timing["segment_start"])
    success_on_sentence_result = expects_auto_segment_result(mode, server_vad_enabled)
    async with websockets.connect(endpoint, max_size=8 * 1024 * 1024) as ws:
        await ws.send(
            json.dumps(
                build_init_payload(
                    mode=mode,
                    wav_name=wav_name,
                    audio_fs=audio_fs,
                    server_vad_enabled=server_vad_enabled,
                    server_vad_silence_ms=server_vad_silence_ms,
                )
            )
        )
        listener = asyncio.create_task(
            collect_messages(
                ws,
                interim_latencies,
                final_latencies,
                sentence_latencies,
                segment_final_latencies,
                timing,
                final_event,
                listener_state,
                errors,
                success_on_sentence_result,
            )
        )
        try:
            for frame in frames:
                await ws.send(frame)
                await asyncio.sleep(FRAME_MS / 1000.0)
            await ws.send(json.dumps({"is_speaking": False}))
            wait_deadline = time.perf_counter() + final_timeout_sec
            try:
                await asyncio.wait_for(
                    final_event.wait(),
                    timeout=max(0.0, wait_deadline - time.perf_counter()),
                )
                if (
                    success_on_sentence_result
                    and sentence_latencies
                    and not errors
                ):
                    await wait_for_listener_quiet(
                        listener_state=listener_state,
                        quiet_period_sec=server_vad_idle_timeout_sec,
                        deadline=wait_deadline,
                    )
            except asyncio.TimeoutError:
                errors.append("final_timeout")
        finally:
            listener.cancel()
            try:
                await listener
            except asyncio.CancelledError:
                pass
    if not (sentence_latencies or segment_final_latencies) and not errors:
        errors.append("missing_segment_result")
    return ClientRunResult(
        interim_latencies=interim_latencies,
        final_latencies=final_latencies,
        sentence_latency_ms=sentence_latencies[0] if sentence_latencies else None,
        segment_final_latency_ms=segment_final_latencies[0] if segment_final_latencies else None,
        errors=errors,
    )


def evaluate_run_result(
    mode: str,
    concurrency: int,
    client_results: Sequence[ClientRunResult | Exception],
) -> RunResult:
    interim_latencies: list[float] = []
    final_latencies: list[float] = []
    error_counter: Counter[str] = Counter()
    client_successes = 0
    client_failures = 0

    for result in client_results:
        if isinstance(result, Exception):
            client_failures += 1
            error_counter[type(result).__name__] += 1
            continue
        interim_latencies.extend(result.interim_latencies)
        final_latencies.extend(result.final_latencies)
        if result.errors:
            client_failures += 1
            error_counter.update(result.errors)
            continue
        if result.final_received:
            client_successes += 1
        else:
            client_failures += 1
            error_counter["missing_segment_result"] += 1

    success_rate = round(client_successes / float(concurrency), 4)
    error_rate = round(client_failures / float(concurrency), 4)
    interim_p95_ms = percentile(interim_latencies, 0.95)
    interim_p99_ms = percentile(interim_latencies, 0.99)
    final_p95_ms = percentile(final_latencies, 0.95)
    final_p99_ms = percentile(final_latencies, 0.99)

    return RunResult(
        mode=mode,
        concurrency=concurrency,
        client_successes=client_successes,
        client_failures=client_failures,
        success_rate=success_rate,
        error_rate=error_rate,
        interim_messages=len(interim_latencies),
        final_messages=len(final_latencies),
        interim_p95_ms=interim_p95_ms,
        interim_p99_ms=interim_p99_ms,
        final_p95_ms=final_p95_ms,
        final_p99_ms=final_p99_ms,
        mean_interim_ms=round(mean(interim_latencies), 2) if interim_latencies else 0.0,
        mean_final_ms=round(mean(final_latencies), 2) if final_latencies else 0.0,
        error_summary="; ".join(
            f"{key}={value}" for key, value in sorted(error_counter.items())
        )
        or "none",
    )


def summarize_mode_results(mode: str, results: Sequence[RunResult]) -> ModeSummary:
    tested_levels = [result.concurrency for result in results]
    highest_tested = max((result.concurrency for result in results), default=0)
    return ModeSummary(
        mode=mode,
        highest_tested_concurrency=highest_tested,
        tested_levels=",".join(str(level) for level in tested_levels) or "none",
        note="raw metrics only; no threshold verdict",
    )


def build_mode_report(
    mode: str,
    endpoint: str,
    wav_path: Path,
    results: Sequence[RunResult],
    summary: ModeSummary,
) -> str:
    rows = [
        [
            str(result.concurrency),
            str(result.client_successes),
            str(result.client_failures),
            format_rate(result.success_rate),
            format_rate(result.error_rate),
            str(result.interim_messages),
            str(result.final_messages),
            format_ms(result.interim_p95_ms),
            format_ms(result.interim_p99_ms),
            format_ms(result.final_p95_ms),
            format_ms(result.final_p99_ms),
            result.error_summary,
        ]
        for result in results
    ]
    return "\n".join(
        [
            f"# Load Test Report: {mode}",
            "",
            "## Scenario",
            f"- Generated at: `{datetime.now().isoformat(timespec='seconds')}`",
            f"- Endpoint: `{endpoint}`",
            f"- WAV: `{wav_path}`",
            "",
            "## Overview",
            f"- Highest tested concurrency: `{summary.highest_tested_concurrency}`",
            f"- Tested levels: `{summary.tested_levels}`",
            f"- Note: {summary.note}",
            "",
            "## Observations",
            markdown_table(
                [
                    "Concurrency",
                    "Successes",
                    "Failures",
                    "Success Rate",
                    "Error Rate",
                    "Interim Msgs",
                    "Final Msgs",
                    "Interim p95 ms",
                    "Interim p99 ms",
                    "Final p95 ms",
                    "Final p99 ms",
                    "Error Summary",
                ],
                rows,
            ),
            "",
        ]
    )


def build_overview_report(
    summaries: Sequence[ModeSummary],
    endpoint: str,
    wav_path: Path,
    run_dir: Path,
) -> str:
    rows = [
        [
            summary.mode,
            str(summary.highest_tested_concurrency),
            summary.tested_levels,
            summary.note,
        ]
        for summary in summaries
    ]
    return "\n".join(
        [
            "# Load Test Overview",
            "",
            f"- Generated at: `{datetime.now().isoformat(timespec='seconds')}`",
            f"- Endpoint: `{endpoint}`",
            f"- WAV: `{wav_path}`",
            f"- Output directory: `{run_dir}`",
            "",
            markdown_table(
                [
                    "Mode",
                    "Highest Tested",
                    "Tested Levels",
                    "Note",
                ],
                rows,
            ),
            "",
        ]
    )


def write_mode_outputs(
    mode_dir: Path,
    mode: str,
    results: Sequence[RunResult],
    summary: ModeSummary,
    endpoint: str,
    wav_path: Path,
) -> tuple[Path, Path, Path]:
    mode_dir.mkdir(parents=True, exist_ok=True)
    json_path = mode_dir / "summary.json"
    csv_path = mode_dir / "summary.csv"
    report_path = mode_dir / "report.md"

    json_path.write_text(
        json.dumps(
            {
                "mode": mode,
                "summary": asdict(summary),
                "results": [asdict(item) for item in results],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(asdict(results[0]).keys()))
        writer.writeheader()
        for item in results:
            writer.writerow(asdict(item))
    report_path.write_text(
        build_mode_report(
            mode=mode,
            endpoint=endpoint,
            wav_path=wav_path,
            results=results,
            summary=summary,
        ),
        encoding="utf-8",
    )
    return json_path, csv_path, report_path


async def run_step(
    endpoint: str,
    mode: str,
    frames: list[bytes],
    audio_fs: int,
    concurrency: int,
    final_timeout_sec: float,
    server_vad_enabled: bool,
    server_vad_silence_ms: int,
    server_vad_idle_timeout_sec: float,
) -> RunResult:
    tasks = [
        run_client(
            endpoint=endpoint,
            mode=mode,
            wav_name=f"bench-{mode}-{concurrency}-{index}",
            frames=frames,
            audio_fs=audio_fs,
            final_timeout_sec=final_timeout_sec,
            server_vad_enabled=server_vad_enabled,
            server_vad_silence_ms=server_vad_silence_ms,
            server_vad_idle_timeout_sec=server_vad_idle_timeout_sec,
        )
        for index in range(concurrency)
    ]
    client_results = await asyncio.gather(*tasks, return_exceptions=True)
    return evaluate_run_result(
        mode=mode,
        concurrency=concurrency,
        client_results=client_results,
    )


async def main() -> None:
    parser = argparse.ArgumentParser(description="Protocol-compliant WebSocket load test.")
    parser.add_argument("--endpoint", required=True)
    parser.add_argument("--wav", required=True, type=Path)
    parser.add_argument(
        "--mode",
        action="append",
        choices=SUPPORTED_MODES,
        dest="legacy_modes",
        help="Backward-compatible single-mode option. May be repeated.",
    )
    parser.add_argument(
        "--modes",
        default="offline,online,2pass",
        help="Comma-separated modes to test. Default: offline,online,2pass",
    )
    parser.add_argument("--concurrency", default=DEFAULT_CONCURRENCY)
    parser.add_argument("--output-dir", default="bench_results", type=Path)
    parser.add_argument("--final-timeout-sec", type=float, default=8.0)
    parser.add_argument(
        "--server-vad",
        action="store_true",
        dest="server_vad_enabled",
        help="Backward-compatible alias. server_vad is enabled by default.",
    )
    parser.add_argument(
        "--disable-server-vad",
        action="store_false",
        dest="server_vad_enabled",
        help="Disable server_vad and require the explicit end-of-audio control message.",
    )
    parser.add_argument(
        "--server-vad-silence-ms",
        "--offline-vad-silence-ms",
        dest="server_vad_silence_ms",
        type=int,
        default=DEFAULT_SERVER_VAD_SILENCE_MS,
        help=(
            "Silence threshold in ms used when server_vad is enabled. "
            f"Default: {DEFAULT_SERVER_VAD_SILENCE_MS}"
        ),
    )
    parser.add_argument(
        "--server-vad-idle-timeout-sec",
        "--offline-idle-timeout-sec",
        dest="server_vad_idle_timeout_sec",
        type=float,
        default=DEFAULT_SERVER_VAD_IDLE_TIMEOUT_SEC,
        help=(
            "After sending end-of-audio with server_vad enabled, keep listening until the "
            "connection is quiet for this many seconds to collect all segment finals. "
            f"Default: {DEFAULT_SERVER_VAD_IDLE_TIMEOUT_SEC}"
        ),
    )
    parser.set_defaults(server_vad_enabled=True)
    args = parser.parse_args()

    modes = parse_modes(args.modes, args.legacy_modes)
    concurrency_levels = parse_concurrency_levels(args.concurrency)
    if args.server_vad_silence_ms <= 0:
        raise ValueError("server_vad_silence_ms must be positive")
    if args.server_vad_idle_timeout_sec <= 0:
        raise ValueError("server_vad_idle_timeout_sec must be positive")
    frames, audio_fs = read_pcm_frames(args.wav)

    run_dir = args.output_dir / datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)

    all_summaries: list[ModeSummary] = []
    all_summary_rows: list[dict[str, str | int]] = []

    for mode in modes:
        print(f"\n=== mode={mode} ===")
        mode_results: list[RunResult] = []
        for concurrency in concurrency_levels:
            print(f"running mode={mode} concurrency={concurrency}")
            result = await run_step(
                endpoint=args.endpoint,
                mode=mode,
                frames=frames,
                audio_fs=audio_fs,
                concurrency=concurrency,
                final_timeout_sec=args.final_timeout_sec,
                server_vad_enabled=args.server_vad_enabled,
                server_vad_silence_ms=args.server_vad_silence_ms,
                server_vad_idle_timeout_sec=args.server_vad_idle_timeout_sec,
            )
            print(
                f"mode={mode} concurrency={concurrency} "
                f"success={format_rate(result.success_rate)} "
                f"error_rate={format_rate(result.error_rate)} "
                f"final_p95={format_ms(result.final_p95_ms)}ms "
                f"final_p99={format_ms(result.final_p99_ms)}ms "
                f"interim_p95={format_ms(result.interim_p95_ms)}ms "
                f"interim_p99={format_ms(result.interim_p99_ms)}ms "
                f"errors={result.error_summary}"
            )
            mode_results.append(result)

        summary = summarize_mode_results(mode, mode_results)
        all_summaries.append(summary)
        all_summary_rows.append(asdict(summary))
        mode_dir = run_dir / mode
        json_path, csv_path, report_path = write_mode_outputs(
            mode_dir=mode_dir,
            mode=mode,
            results=mode_results,
            summary=summary,
            endpoint=args.endpoint,
            wav_path=args.wav,
        )
        print(render_console_table(mode_results))
        print(f"mode={mode} highest_tested={summary.highest_tested_concurrency} report={report_path}")
        print(f"mode={mode} outputs: {json_path}, {csv_path}, {report_path}")

    overview_json = run_dir / "overview.json"
    overview_csv = run_dir / "overview.csv"
    overview_md = run_dir / "overview.md"
    overview_json.write_text(
        json.dumps([asdict(item) for item in all_summaries], indent=2),
        encoding="utf-8",
    )
    with overview_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_summary_rows[0].keys()))
        writer.writeheader()
        for row in all_summary_rows:
            writer.writerow(row)
    overview_md.write_text(
        build_overview_report(
            summaries=all_summaries,
            endpoint=args.endpoint,
            wav_path=args.wav,
            run_dir=run_dir,
        ),
        encoding="utf-8",
    )

    print("\n=== overview ===")
    print(render_overview_console_table(all_summaries))
    print(f"overview outputs: {overview_json}, {overview_csv}, {overview_md}")


if __name__ == "__main__":
    asyncio.run(main())
