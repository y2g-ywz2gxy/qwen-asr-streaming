docker run -it --rm --gpus all -e MAX_MODEL_LEN=4096 -v ./models:/models --entrypoint /bin/bash  -p8001:10095 qwen-asr:cuda12.2
docker run -it --rm --gpus all -e MAX_MODEL_LEN=4096 --entrypoint /bin/bash -p8001:10095 qwen3-asr-ws:v20260319_001
