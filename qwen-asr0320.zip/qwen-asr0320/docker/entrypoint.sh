#!/usr/bin/env bash
set -euo pipefail

: "${WS_HOST:=0.0.0.0}"
: "${WS_PORT:=8001}"
: "${MODEL_PATH:=/models/Qwen3-ASR-1.7B}"
: "${LOGS_DIR:=/app/logs}"

mkdir -p "${LOGS_DIR}"

if [ ! -d "${MODEL_PATH}" ]; then
    echo "MODEL_PATH does not exist: ${MODEL_PATH}" >&2
    echo "Mount the downloaded Qwen3-ASR model directory into the container before startup." >&2
    exit 1
fi

if [ ! -f "${MODEL_PATH}/config.json" ]; then
    echo "MODEL_PATH is missing config.json: ${MODEL_PATH}" >&2
    echo "Expected a full Qwen3-ASR-1.7B model directory." >&2
    exit 1
fi

python -m server.runtime_check

exec python -m server.app --host "${WS_HOST}" --port "${WS_PORT}"
