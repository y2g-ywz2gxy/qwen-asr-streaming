# 部署与运行说明

本文档聚焦部署、配置、验证、日志与压测。项目概览和最短上手路径见仓库根目录 `README.md`。

## 环境要求

- Python 3.10+
- NVIDIA 驱动与 CUDA 环境
- 本地可用的 `Qwen3-ASR-1.7B` 模型目录，或按下文步骤下载
- 单卡参考配置：`Tesla V100-SXM2-32GB`
- 已验证部署基线：`Tesla V100-SXM2-32GB / Driver 535.129.03 / CUDA 12.2`
- 固定运行时版本：`qwen-asr 0.0.6`、`vllm 0.14.0`、`torch 2.9.1`、`torchaudio 2.9.1`、`torchvision 0.24.1`

兼容性说明：

- `qwen-asr 0.0.6` 的 `vllm` extra 固定依赖 `vllm 0.14.0`
- `vllm 0.14.0` 固定依赖 `torch 2.9.1`、`torchaudio 2.9.1`、`torchvision 0.24.1`
- 目标 GPU `V100` 为 `SM 7.0`，因此默认必须使用 `VLLM_ATTENTION_BACKEND=TORCH_SDPA`
- 默认关闭 `FlashInfer sampler`，即 `VLLM_USE_FLASHINFER_SAMPLER=0`
- `nvidia-smi` 显示的 `CUDA Version: 12.2` 不阻塞这组 `cu12` 用户态依赖；关键是驱动 `535.129.03` 满足 CUDA 12.x 兼容要求

推荐模型目录：

```text
./models/Qwen3-ASR-1.7B
```

模型下载依赖 `modelscope`，请先完成下面的 `make install` 或手动依赖安装，再执行下载命令。推荐直接使用 `make download-model`。

## 本地启动

推荐方式：

```bash
make venv
make install
cp config/example.env .env
make download-model
make run
```

`make download-model` 会先执行 `make install`，因为模型下载命令依赖已安装的 `modelscope`。

手动方式：

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip setuptools wheel
pip install -r requirements.runtime-gpu.txt
cp config/example.env .env
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
python -m server.runtime_check
python -m server.app --host 0.0.0.0 --port 8001
```

推荐在实际启动前先单独执行一次：

```bash
.venv/bin/python -m server.runtime_check
```

自检输出包含：

- 当前 Python 版本
- `qwen-asr / vllm / torch / torchaudio / torchvision` 实际版本
- `torch.version.cuda`
- GPU 名称与 compute capability
- 最终生效的 `VLLM_ATTENTION_BACKEND`
- 是否关闭 `FlashInfer sampler`

如果只需要手动下载模型，也请在完成依赖安装后执行：

```bash
mkdir -p models
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
```

如果 `modelscope download` 报错 `No module named 'pkg_resources'`，执行：

```bash
.venv/bin/pip install -U setuptools wheel
```

## Docker 启动

Docker 方式不会在容器内下载模型。执行 `docker compose up` 前，请先在宿主机准备好完整模型目录，并让 `MODEL_PATH_HOST` 指向该目录。

默认基础镜像已固定到经 V100 验证的 digest，而不是浮动 `latest`。

```bash
cp config/docker.env.example .env
mkdir -p logs
docker compose build
docker compose up -d
```

说明：

- Docker build 阶段会执行 `python3 -m server.runtime_check --allow-no-gpu`，只校验 Python 运行时版本
- 容器启动阶段会执行 `python3 -m server.runtime_check`，同时校验 GPU 可见性和 V100 backend 配置
- 如果版本漂移、GPU 不可见，或 V100 上错误启用了不安全 backend，容器会直接退出

如果模型还没下载，请先在宿主机按前文方式完成下载；如果模型目录不在仓库内，至少确认：

```bash
MODEL_PATH_HOST=/absolute/path/to/Qwen3-ASR-1.7B
MODEL_PATH=/models/Qwen3-ASR-1.7B
```

常用命令：

```bash
docker compose ps
docker compose logs -f
docker compose down
```

## 关键配置

复制模板：

```bash
cp config/example.env .env
```

常用配置项：

| 变量 | 说明 | 建议 |
| --- | --- | --- |
| `MODEL_PATH` | 模型目录 | 指向真实模型路径 |
| `WS_HOST` / `WS_PORT` | 监听地址和端口 | 默认 `0.0.0.0:8001` |
| `GPU_MEMORY_UTILIZATION` | vLLM 显存使用比例 | 默认 `0.8` |
| `VLLM_ATTENTION_BACKEND` | vLLM attention backend | V100 默认 `TORCH_SDPA` |
| `VLLM_USE_FLASHINFER_SAMPLER` | 是否启用 FlashInfer sampler | V100 默认 `0` |
| `MAX_MODEL_LEN` | 上下文长度限制 | 不确定时先不设置 |
| `MAX_SESSIONS` | 最大并发连接数 | 建议先从 `8` 开始 |
| `MAX_BUFFER_MS` | 单连接最大缓冲时长 | 默认 `3000` |
| `MAX_PENDING_TASKS_PER_SESSION` | 单连接待处理任务上限 | 默认 `8` |
| `CONNECTION_IDLE_TIMEOUT_SEC` | 空闲连接超时 | 默认 `60` |
| `LOGS_DIR` | 日志目录 | 默认 `./logs` |
| `WARMUP_ENABLED` | 是否预热模型 | `1` 开启，`0` 关闭 |

建议至少确认以下配置：

```bash
MODEL_PATH=./models/Qwen3-ASR-1.7B
HF_HUB_OFFLINE=1
TRANSFORMERS_OFFLINE=1
HF_HUB_DISABLE_TELEMETRY=1
GPU_MEMORY_UTILIZATION=0.8
VLLM_ATTENTION_BACKEND=TORCH_SDPA
VLLM_USE_FLASHINFER_SAMPLER=0
MAX_MODEL_LEN=4096
MAX_SESSIONS=8
```

说明：

- 先下载完整模型，再开启离线模式
- 服务会自动读取仓库根目录 `.env`
- Docker 中的 `MODEL_PATH_HOST` 是宿主机路径，`MODEL_PATH` 是容器内路径
- `make run` 会在真正启动服务前先执行 `python -m server.runtime_check`

## 启动后验证

至少检查以下入口：

- `GET /`：浏览器调试页面
- `GET /healthz`：健康检查
- `GET /ready`：就绪检查，返回内容与 `GET /healthz` 相同
- `GET /metrics`：运行指标
- `WS /ws/asr`：WebSocket 识别入口

本地验证示例：

```bash
curl http://127.0.0.1:8001/healthz
curl http://127.0.0.1:8001/ready
curl http://127.0.0.1:8001/metrics
```

## 协议要点

客户端发送要求：

- 首包必须是文本 JSON
- `wav_format` 必须为 `pcm`
- `audio_fs` 只支持 `8000` 或 `16000`
- 推荐输入 `16kHz / 16-bit / 单声道`
- 推荐按约 `60ms` 的节奏发送 PCM
- 如需手动结束当前 segment 或冲刷尾部音频，发送 `{"is_speaking": false}`

关键语义：

- 请求 `mode` 决定服务端内部识别路径
- 服务端回包 `mode` 只使用 `2pass-online` 和 `2pass-offline`
- `is_speaking=false` 只结束当前 segment，不关闭 WebSocket 连接
- `is_final=true` 表示当前 segment 的最终结果

首包示例：

```json
{
  "mode": "2pass",
  "wav_name": "demo-session",
  "is_speaking": true,
  "wav_format": "pcm",
  "audio_fs": 16000,
  "chunk_size": [5, 10, 5],
  "hotwords": "{\"阿里巴巴\":20,\"通义实验室\":30}",
  "itn": true,
  "turn_detection": {"type": "server_vad", "silence_duration_ms": 600}
}
```

补充说明：

- `hotwords` 只兼容字符串对象格式
- 热词会映射到 Qwen `context` 做增强
- `itn=true` 时，仅对最终中文结果做归一化
- 当前 `qwen-asr` Python API 没有原生 `itn` 参数，`itn` 由服务端处理
- 默认开启 `server_vad`；如需关闭，首包传 `{"turn_detection":{"type":"none"}}`
- 开启 `server_vad` 时，连续静音达到 `silence_duration_ms` 会自动结束当前 segment；`max_segment_ms` 只作为兜底上限
- `2pass-online` 表示流式中间结果，`2pass-offline` 表示句级离线结果
- 客户端显式发送 `{"is_speaking": false}` 时，服务端返回当前 segment 的完整最终结果，且 `is_final=true`
- 服务端不会再额外发送空的结束包；需要结束整条会话时由客户端主动关闭连接

请求与回包映射：

| 请求 `mode` | 服务端行为 | 手动结束当前 segment 的最终回包 |
| --- | --- | --- |
| `offline` | 仅离线识别 | `mode=2pass-offline, is_final=true` |
| `online` | 仅流式识别 | `mode=2pass-online, is_final=true` |
| `2pass` | 流式 + 离线修正 | `mode=2pass-offline, is_final=true` |

推荐客户端处理方式：

1. 收到 `mode=2pass-online` 且 `is_final=false` 时更新中间文本。
2. 收到 `mode=2pass-offline` 时，将该条结果作为一个完整 segment 追加到历史；其中自动 VAD 切段通常 `is_final=false`。
3. 收到 `is_final=true` 时，将该条消息视为“当前 segment 的手动 finalize 结果”。
4. 收到 `is_final=true` 后不要关闭连接；如果还要继续识别，客户端可以直接重新开始采集下一段音频。

典型交互：

```text
client -> {"mode":"offline","wav_name":"demo","is_speaking":true,...}
client -> <pcm bytes>
client -> {"is_speaking":false}
server -> {"mode":"2pass-offline","wav_name":"demo","text":"第一句","is_final":true}
client -> <next pcm bytes on same websocket>
```

错误回包示例：

```json
{"event":"error","code":"INVALID_MODE","message":"mode must be offline, online, or 2pass"}
```

## 日志与排障

`LOGS_DIR` 下默认生成：

- `service.log`：服务主日志
- `access.log`：连接建立和断开
- `error.log`：`WARNING` 及以上日志

排查时优先关注：

- `session_id`
- `wav_name`
- `mode`
- `queue_ms`
- `elapsed_ms`
- `payload.text`
- `payload.message`
- `/metrics` 中的 `pending_tasks`

常见问题：

- 延迟升高或任务积压：先看 `MAX_SESSIONS`、`MAX_BUFFER_MS`、`pending_tasks`、GPU 显存、`MAX_MODEL_LEN`
- 连接被拒绝：先看 `MAX_SESSIONS` 和首包是否合法
- 首包报错：优先检查 `wav_format`、`audio_fs`、`hotwords` 格式
- 长时间未收到 segment 最终结果：优先检查是否发送了 `{"is_speaking": false}`

## 测试与压测

运行测试：

```bash
make test
```

运行压测：

```bash
make loadtest LOADTEST_WAV=./sample.wav
make loadtest LOADTEST_WAV=./sample.wav LOADTEST_SERVER_VAD=0
```

等价命令：

```bash
python tests/loadtest_ws.py --endpoint ws://127.0.0.1:8001/ws/asr --wav ./sample.wav
python tests/loadtest_ws.py --endpoint ws://127.0.0.1:8001/ws/asr --wav ./sample.wav --disable-server-vad
```

压测说明：

- 默认压测会带上 `server_vad`
- 如果要模拟“完全由客户端手动结束”的协议路径，显式关闭 `server_vad`

默认压测模式：

- `offline`
- `online`
- `2pass`

默认并发阶梯：

- `2,4,6,8,10,12,16`

结果目录示例：

```text
<timestamp>/
  offline/
  online/
  2pass/
  overview.json
  overview.csv
  overview.md
```

重点关注：

- `success_rate`
- `error_rate`
- `interim_p95 / interim_p99`
- `final_p95 / final_p99`
- `errors`
