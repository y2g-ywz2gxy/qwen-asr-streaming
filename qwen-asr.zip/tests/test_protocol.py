from server.protocol import (
    OFFLINE_RESPONSE_MODE,
    ProtocolError,
    STREAMING_RESPONSE_MODE,
    format_response,
    parse_init_message,
    sentence_response_mode,
    streaming_response_mode,
)


def test_parse_init_message_accepts_valid_payload() -> None:
    config = parse_init_message(
        '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"itn":true}'
    )
    assert config.mode == "2pass"
    assert config.wav_name == "demo"
    assert config.step_ms == 600
    assert config.turn_detection.enabled is True


def test_parse_init_message_accepts_funasr_hotwords_string_object() -> None:
    config = parse_init_message(
        '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"hotwords":"{\\"Alibaba\\":20,\\"TongyiLab\\":30}"}'
    )

    assert config.hotwords == '{"Alibaba":20,"TongyiLab":30}'
    assert config.hotword_terms == ("Alibaba", "TongyiLab")
    assert "Alibaba" in config.hotword_context
    assert config.hotword_context.startswith("以下是需要重点关注的热词和上下文短语：")


def test_parse_init_message_accepts_empty_hotwords_string_for_clear() -> None:
    config = parse_init_message(
        '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"hotwords":""}'
    )

    assert config.hotwords == ""
    assert config.hotword_terms == ()
    assert config.hotword_context == ""


def test_parse_init_message_accepts_turn_detection_none_to_disable_default_vad() -> None:
    config = parse_init_message(
        '{"mode":"offline","wav_name":"demo","is_speaking":true,"turn_detection":{"type":"none"}}'
    )

    assert config.turn_detection.enabled is False


def test_parse_init_message_rejects_invalid_mode() -> None:
    try:
        parse_init_message('{"mode":"bad","wav_name":"demo","is_speaking":true}')
    except ProtocolError as exc:
        assert exc.code == "INVALID_MODE"
    else:
        raise AssertionError("expected ProtocolError")


def test_parse_init_message_rejects_non_string_hotwords() -> None:
    try:
        parse_init_message(
            '{"mode":"offline","wav_name":"demo","is_speaking":true,"hotwords":{"Alibaba":20}}'
        )
    except ProtocolError as exc:
        assert exc.code == "INVALID_HOTWORDS"
    else:
        raise AssertionError("expected ProtocolError")


def test_parse_init_message_rejects_non_numeric_hotword_weights() -> None:
    try:
        parse_init_message(
            '{"mode":"offline","wav_name":"demo","is_speaking":true,"hotwords":"{\\"Alibaba\\":\\"high\\"}"}'
        )
    except ProtocolError as exc:
        assert exc.code == "INVALID_HOTWORDS"
    else:
        raise AssertionError("expected ProtocolError")


def test_response_modes_follow_sentence_and_streaming_helpers() -> None:
    assert streaming_response_mode("online") == STREAMING_RESPONSE_MODE
    assert streaming_response_mode("2pass") == STREAMING_RESPONSE_MODE
    assert sentence_response_mode("online") == STREAMING_RESPONSE_MODE
    assert sentence_response_mode("offline") == OFFLINE_RESPONSE_MODE
    assert sentence_response_mode("2pass") == OFFLINE_RESPONSE_MODE


def test_format_response_keeps_explicit_mode_for_sentence_results() -> None:
    payload = format_response("demo", "hello", False, mode=OFFLINE_RESPONSE_MODE)

    assert payload["mode"] == OFFLINE_RESPONSE_MODE


def test_format_response_keeps_explicit_mode_for_final_segment_results() -> None:
    payload = format_response("demo", "hello", True, mode=OFFLINE_RESPONSE_MODE)

    assert payload == {
        "wav_name": "demo",
        "text": "hello",
        "is_final": True,
        "mode": OFFLINE_RESPONSE_MODE,
    }
