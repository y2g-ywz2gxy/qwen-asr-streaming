from server.protocol import ProtocolError, format_response, parse_init_message


def test_parse_init_message_accepts_valid_payload() -> None:
    config = parse_init_message(
        '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"itn":true}'
    )
    assert config.mode == "2pass"
    assert config.wav_name == "demo"
    assert config.step_ms == 600


def test_parse_init_message_accepts_funasr_hotwords_string_object() -> None:
    config = parse_init_message(
        '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"hotwords":"{\\"Alibaba\\":20,\\"TongyiLab\\":30}"}'
    )

    assert config.hotwords == '{"Alibaba":20,"TongyiLab":30}'
    assert config.hotword_terms == ("Alibaba", "TongyiLab")
    assert "Alibaba" in config.hotword_context
    assert config.hotword_context.startswith("以下是需要重点关注的热词和上下文短语：")


def test_parse_init_message_accepts_empty_hotwords_string_for_clear() -> None:
    config = parse_init_message(
        '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"hotwords":""}'
    )

    assert config.hotwords == ""
    assert config.hotword_terms == ()
    assert config.hotword_context == ""


def test_parse_init_message_rejects_invalid_mode() -> None:
    try:
        parse_init_message('{"mode":"bad","wav_name":"demo","is_speaking":true}')
    except ProtocolError as exc:
        assert exc.code == "INVALID_MODE"
    else:
        raise AssertionError("expected ProtocolError")


def test_parse_init_message_rejects_non_string_hotwords() -> None:
    try:
        parse_init_message(
            '{"mode":"offline","wav_name":"demo","is_speaking":true,"hotwords":{"Alibaba":20}}'
        )
    except ProtocolError as exc:
        assert exc.code == "INVALID_HOTWORDS"
    else:
        raise AssertionError("expected ProtocolError")


def test_parse_init_message_rejects_non_numeric_hotword_weights() -> None:
    try:
        parse_init_message(
            '{"mode":"offline","wav_name":"demo","is_speaking":true,"hotwords":"{\\"Alibaba\\":\\"high\\"}"}'
        )
    except ProtocolError as exc:
        assert exc.code == "INVALID_HOTWORDS"
    else:
        raise AssertionError("expected ProtocolError")


def test_format_response_modes() -> None:
    assert format_response("2pass", "demo", "hello", False)["mode"] == "2pass-online"
    assert format_response("2pass", "demo", "hello", True)["mode"] == "2pass-offline"
    assert format_response("offline", "demo", "hello", True)["mode"] == "offline"
