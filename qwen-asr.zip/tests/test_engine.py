from __future__ import annotations

import sys
import types

import numpy as np

from server.engine import QwenBackend
from server.hotwords import build_hotword_context
from server.settings import AppSettings, SessionConfig


class DummyModelResult:
    def __init__(self, text: str, language: str):
        self.text = text
        self.language = language


class DummyOfflineModel:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def transcribe(
        self,
        *,
        audio: object,
        context: str,
        return_time_stamps: bool = False,
    ):
        self.calls.append(
            {
                "audio": audio,
                "context": context,
                "return_time_stamps": return_time_stamps,
            }
        )
        return [DummyModelResult("offline text", "zh")]


class DummyStreamingModel:
    def __init__(self) -> None:
        self.init_calls: list[dict[str, object]] = []

    def init_streaming_state(self, **kwargs: object):
        self.init_calls.append(kwargs)
        return types.SimpleNamespace(
            unfixed_chunk_num=kwargs["unfixed_chunk_num"],
            unfixed_token_num=kwargs["unfixed_token_num"],
            chunk_size_sec=kwargs["chunk_size_sec"],
            chunk_size_samples=32000,
            chunk_id=0,
            buffer=np.array([], dtype=np.float32),
            audio_accum=np.array([], dtype=np.float32),
            prompt_raw=f"prompt::{kwargs.get('context', '')}",
            context=kwargs.get("context", ""),
            force_language=None,
            language="",
            text="",
            _raw_decoded="",
        )


class FakeLLM:
    init_calls: list[dict[str, object]] = []

    def __init__(self, **kwargs: object):
        self.kwargs = kwargs
        self.__class__.init_calls.append(kwargs)


class FakeQwen3ASRModel:
    LLM = FakeLLM


def build_config(mode: str = "offline", **overrides: object) -> SessionConfig:
    values: dict[str, object] = {
        "mode": mode,
        "wav_name": "demo",
        "wav_format": "pcm",
        "audio_fs": 16000,
        "chunk_size": [5, 10, 5],
        "hotwords": None,
        "hotword_terms": (),
        "hotword_context": "",
    }
    values.update(overrides)
    return SessionConfig(**values)


def build_settings(**overrides: object) -> AppSettings:
    values = {
        "frontend_path": AppSettings().frontend_path,
        "warmup_enabled": False,
    }
    values.update(overrides)
    return AppSettings(**values)


def test_qwen_backend_transcribe_segment_uses_numpy_audio_tuple_and_context() -> None:
    backend = object.__new__(QwenBackend)
    backend._model = DummyOfflineModel()

    pcm = np.array([0, 32767, -32768], dtype=np.int16)
    config = build_config(
        hotwords='{"Alibaba":20}',
        hotword_terms=("Alibaba",),
        hotword_context=build_hotword_context(("Alibaba",)),
    )
    result = backend.transcribe_segment(pcm.tobytes(), config)

    assert result.text == "offline text"
    assert result.language == "zh"

    call = backend._model.calls[0]
    assert call["return_time_stamps"] is False
    assert call["context"] == config.hotword_context
    assert isinstance(call["audio"], tuple)

    samples, sample_rate = call["audio"]
    assert sample_rate == 16000
    assert isinstance(samples, np.ndarray)
    assert samples.dtype == np.float32
    np.testing.assert_allclose(
        samples,
        np.array([0.0, 32767 / 32768.0, -1.0], dtype=np.float32),
    )


def test_qwen_backend_create_stream_state_passes_context() -> None:
    backend = object.__new__(QwenBackend)
    backend._model = DummyStreamingModel()
    config = build_config(
        mode="online",
        hotwords='{"Alibaba":20}',
        hotword_terms=("Alibaba",),
        hotword_context="ctx",
    )

    state = backend.create_stream_state(config)

    assert state.context == "ctx"
    assert backend._model.init_calls[0]["context"] == "ctx"


def test_qwen_backend_refresh_stream_context_preserves_progress() -> None:
    backend = object.__new__(QwenBackend)
    backend._model = DummyStreamingModel()
    state = backend.create_stream_state(build_config(mode="online"))
    state.chunk_id = 3
    state.buffer = np.array([0.1, 0.2], dtype=np.float32)
    state.audio_accum = np.array([0.3, 0.4], dtype=np.float32)
    state.language = "en"
    state.text = "old text"
    state._raw_decoded = "old raw"

    refreshed = backend.refresh_stream_context(
        state,
        build_config(
            mode="online",
            hotwords='{"Alibaba":20}',
            hotword_terms=("Alibaba",),
            hotword_context="ctx",
        ),
    )

    assert refreshed is not state
    assert refreshed.context == "ctx"
    assert refreshed.prompt_raw == "prompt::ctx"
    assert refreshed.chunk_id == 3
    np.testing.assert_allclose(refreshed.buffer, np.array([0.1, 0.2], dtype=np.float32))
    np.testing.assert_allclose(refreshed.audio_accum, np.array([0.3, 0.4], dtype=np.float32))
    assert refreshed.language == "en"
    assert refreshed.text == "old text"
    assert refreshed._raw_decoded == "old raw"


def test_qwen_backend_uses_qwen_default_max_new_tokens(monkeypatch) -> None:
    FakeLLM.init_calls.clear()
    monkeypatch.setitem(
        sys.modules,
        "qwen_asr",
        types.SimpleNamespace(Qwen3ASRModel=FakeQwen3ASRModel),
    )

    QwenBackend(build_settings())

    kwargs = FakeLLM.init_calls[-1]
    assert kwargs["model"] == build_settings().model_path
    assert kwargs["gpu_memory_utilization"] == build_settings().gpu_memory_utilization
    assert "max_new_tokens" not in kwargs
    assert "max_model_len" not in kwargs


def test_qwen_backend_passes_max_model_len_when_configured(monkeypatch) -> None:
    FakeLLM.init_calls.clear()
    monkeypatch.setitem(
        sys.modules,
        "qwen_asr",
        types.SimpleNamespace(Qwen3ASRModel=FakeQwen3ASRModel),
    )

    QwenBackend(build_settings(max_model_len=4096))

    kwargs = FakeLLM.init_calls[-1]
    assert kwargs["max_model_len"] == 4096
    assert "max_new_tokens" not in kwargs


def test_build_hotword_context_uses_chinese_prompt() -> None:
    context = build_hotword_context(("阿里巴巴", "通义实验室"))

    assert context.startswith("以下是需要重点关注的热词和上下文短语：")
    assert "阿里巴巴" in context
    assert context.endswith("如果音频中出现这些词，请优先输出与这里一致的写法。")
