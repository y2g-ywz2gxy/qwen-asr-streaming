from __future__ import annotations

from server.itn import normalize_final_text


def test_normalize_final_text_converts_chinese_numbers_when_enabled() -> None:
    assert normalize_final_text("今天是二零二六年三月十二日", enabled=True) == "今天是2026年3月12日"


def test_normalize_final_text_skips_when_disabled() -> None:
    assert normalize_final_text("一百二十三", enabled=False) == "一百二十三"


def test_normalize_final_text_skips_text_without_number_features() -> None:
    assert normalize_final_text("欢迎使用Qwen ASR", enabled=True) == "欢迎使用Qwen ASR"


def test_normalize_final_text_falls_back_on_transform_error(monkeypatch) -> None:
    def raise_error(text: str) -> str:
        raise RuntimeError("boom")

    monkeypatch.setattr("server.itn._transform_text", raise_error)

    assert normalize_final_text("一百二十三", enabled=True) == "一百二十三"
