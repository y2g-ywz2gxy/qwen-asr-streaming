from __future__ import annotations

from fastapi.testclient import TestClient

from server.app import create_app
from server.engine import BackendProtocol, StreamResult
from server.settings import AppSettings, SessionConfig


class FakeBackend(BackendProtocol):
    def __init__(self, settings: AppSettings):
        self.settings = settings

    def warmup(self) -> None:
        return None

    def create_stream_state(self, config: SessionConfig) -> dict[str, object]:
        return {
            "chunks": 0,
            "label": self._label(config),
        }

    def refresh_stream_context(
        self,
        state: dict[str, object],
        config: SessionConfig,
    ) -> dict[str, object]:
        return {
            **state,
            "label": self._label(config),
        }

    def streaming_transcribe(self, pcm_bytes: bytes, state: dict[str, object]) -> StreamResult:
        state["chunks"] = int(state["chunks"]) + 1
        return StreamResult(text=f"partial-{state['chunks']}-{state['label']}", language="zh")

    def finish_stream(self, state: dict[str, object]) -> StreamResult:
        return StreamResult(text=f"online-final-{state['chunks']}-{state['label']}", language="zh")

    def transcribe_segment(self, pcm_bytes: bytes, config: SessionConfig) -> StreamResult:
        return StreamResult(
            text=f"{config.mode}-final-{len(pcm_bytes)}-{self._label(config)}",
            language="zh",
        )

    def _label(self, config: SessionConfig) -> str:
        return ",".join(config.hotword_terms) or "none"


def build_client() -> TestClient:
    return build_client_with_backend(FakeBackend)


def build_client_with_backend(backend_factory: type[BackendProtocol]) -> TestClient:
    settings = AppSettings(
        warmup_enabled=False,
        frontend_path=AppSettings().frontend_path,
    )
    return TestClient(create_app(settings=settings, backend_factory=backend_factory))


class NumeralBackend(BackendProtocol):
    def __init__(self, settings: AppSettings):
        self.settings = settings

    def warmup(self) -> None:
        return None

    def create_stream_state(self, config: SessionConfig) -> dict[str, object]:
        return {"chunks": 0}

    def refresh_stream_context(
        self,
        state: dict[str, object],
        config: SessionConfig,
    ) -> dict[str, object]:
        return state

    def streaming_transcribe(self, pcm_bytes: bytes, state: dict[str, object]) -> StreamResult:
        state["chunks"] = int(state["chunks"]) + 1
        return StreamResult(text="一二三", language="zh")

    def finish_stream(self, state: dict[str, object]) -> StreamResult:
        return StreamResult(text="一二三", language="zh")

    def transcribe_segment(self, pcm_bytes: bytes, config: SessionConfig) -> StreamResult:
        return StreamResult(text="一百二十三", language="zh")


def test_two_pass_flow_supports_multiple_segments() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5]}'
            )
            ws.send_bytes(audio_chunk)
            interim = ws.receive_json()
            assert interim["mode"] == "2pass-online"
            ws.send_text('{"is_speaking": false}')
            final_one = ws.receive_json()
            assert final_one["mode"] == "2pass-offline"
            ws.send_bytes(audio_chunk)
            interim_two = ws.receive_json()
            assert interim_two["mode"] == "2pass-online"
            ws.send_text('{"is_speaking": false}')
            final_two = ws.receive_json()
            assert final_two["mode"] == "2pass-offline"


def test_offline_mode_only_returns_final() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5]}'
            )
            ws.send_bytes(audio_chunk)
            ws.send_text('{"is_speaking": false}')
            final_payload = ws.receive_json()
            assert final_payload["mode"] == "offline"
            assert final_payload["is_final"] is True


def test_hotwords_update_is_applied_before_finalize() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5]}'
            )
            ws.send_bytes(audio_chunk)
            interim = ws.receive_json()
            assert interim["text"].endswith("-none")

            ws.send_text(
                '{"hotwords":"{\\"Alibaba\\":20,\\"TongyiLab\\":30}","is_speaking":false}'
            )
            final_payload = ws.receive_json()

            assert final_payload["mode"] == "2pass-offline"
            assert final_payload["text"].endswith("-Alibaba,TongyiLab")


def test_offline_init_hotwords_are_applied_to_final_result() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"hotwords":"{\\"Alibaba\\":20}"}'
            )
            ws.send_bytes(audio_chunk)
            ws.send_text('{"is_speaking": false}')
            final_payload = ws.receive_json()

            assert final_payload["text"].endswith("-Alibaba")


def test_invalid_hotwords_update_returns_protocol_error() -> None:
    with build_client() as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"offline","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5]}'
            )
            ws.send_text('{"hotwords":"Alibaba"}')
            error_payload = ws.receive_json()

            assert error_payload["event"] == "error"
            assert error_payload["code"] == "INVALID_HOTWORDS"


def test_two_pass_final_applies_itn_without_mutating_partial() -> None:
    audio_chunk = (b"\x00\x01" * 960) * 10
    with build_client_with_backend(NumeralBackend) as client:
        with client.websocket_connect("/ws/asr") as ws:
            ws.send_text(
                '{"mode":"2pass","wav_name":"demo","is_speaking":true,"wav_format":"pcm","audio_fs":16000,"chunk_size":[5,10,5],"itn":true}'
            )
            ws.send_bytes(audio_chunk)
            interim = ws.receive_json()
            assert interim["text"] == "一二三"

            ws.send_text('{"is_speaking": false}')
            final_payload = ws.receive_json()

            assert final_payload["mode"] == "2pass-offline"
            assert final_payload["text"] == "123"
