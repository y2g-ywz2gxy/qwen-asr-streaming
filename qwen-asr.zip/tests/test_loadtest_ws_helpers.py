from __future__ import annotations

import asyncio
import importlib.util
import struct
import sys
import time
from pathlib import Path

import pytest


MODULE_PATH = Path(__file__).resolve().parent / "loadtest_ws.py"
SPEC = importlib.util.spec_from_file_location("loadtest_ws_module", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
loadtest_ws = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = loadtest_ws
SPEC.loader.exec_module(loadtest_ws)


class FakeWaveReader:
    def __init__(
        self,
        *,
        channels: int,
        sample_width: int,
        sample_rate: int,
        frames: bytes,
        compression: str = "NONE",
    ) -> None:
        self._channels = channels
        self._sample_width = sample_width
        self._sample_rate = sample_rate
        self._frames = frames
        self._compression = compression

    def __enter__(self) -> "FakeWaveReader":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def getcomptype(self) -> str:
        return self._compression

    def getsampwidth(self) -> int:
        return self._sample_width

    def getnchannels(self) -> int:
        return self._channels

    def getframerate(self) -> int:
        return self._sample_rate

    def getnframes(self) -> int:
        frame_width = self._channels * self._sample_width
        return len(self._frames) // frame_width

    def readframes(self, _frame_count: int) -> bytes:
        return self._frames


def test_summarize_mode_results_tracks_tested_levels() -> None:
    results = [
        loadtest_ws.RunResult(
            mode="offline",
            concurrency=2,
            client_successes=2,
            client_failures=0,
            success_rate=1.0,
            error_rate=0.0,
            interim_messages=0,
            final_messages=2,
            interim_p95_ms=0.0,
            interim_p99_ms=0.0,
            final_p95_ms=500.0,
            final_p99_ms=500.0,
            mean_interim_ms=0.0,
            mean_final_ms=420.0,
            error_summary="none",
        ),
        loadtest_ws.RunResult(
            mode="offline",
            concurrency=4,
            client_successes=4,
            client_failures=0,
            success_rate=1.0,
            error_rate=0.0,
            interim_messages=0,
            final_messages=4,
            interim_p95_ms=0.0,
            interim_p99_ms=0.0,
            final_p95_ms=800.0,
            final_p99_ms=800.0,
            mean_interim_ms=0.0,
            mean_final_ms=700.0,
            error_summary="none",
        ),
        loadtest_ws.RunResult(
            mode="offline",
            concurrency=6,
            client_successes=5,
            client_failures=1,
            success_rate=0.8333,
            error_rate=0.1667,
            interim_messages=0,
            final_messages=5,
            interim_p95_ms=0.0,
            interim_p99_ms=0.0,
            final_p95_ms=2400.0,
            final_p99_ms=2400.0,
            mean_interim_ms=0.0,
            mean_final_ms=2100.0,
            error_summary="final_timeout=1",
        ),
    ]

    summary = loadtest_ws.summarize_mode_results("offline", results)

    assert summary.highest_tested_concurrency == 6
    assert summary.tested_levels == "2,4,6"
    assert "no threshold verdict" in summary.note


def test_build_mode_report_contains_overview_and_observation_table() -> None:
    results = [
        loadtest_ws.RunResult(
            mode="2pass",
            concurrency=2,
            client_successes=2,
            client_failures=0,
            success_rate=1.0,
            error_rate=0.0,
            interim_messages=6,
            final_messages=2,
            interim_p95_ms=320.0,
            interim_p99_ms=320.0,
            final_p95_ms=980.0,
            final_p99_ms=980.0,
            mean_interim_ms=250.0,
            mean_final_ms=910.0,
            error_summary="none",
        )
    ]
    summary = loadtest_ws.summarize_mode_results("2pass", results)

    report = loadtest_ws.build_mode_report(
        mode="2pass",
        endpoint="ws://127.0.0.1:8001/ws/asr",
        wav_path=Path("sample.wav"),
        results=results,
        summary=summary,
    )

    assert "Highest tested concurrency" in report
    assert "| Concurrency | Successes |" in report
    assert "Interim p99 ms" in report
    assert "Final p99 ms" in report
    assert "2pass" in report


def test_read_pcm_frames_normalizes_stereo_8bit_pcm(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        loadtest_ws.wave,
        "open",
        lambda *_args, **_kwargs: FakeWaveReader(
            channels=2,
            sample_width=1,
            sample_rate=8000,
            frames=bytes([0, 0, 128, 128, 255, 255]),
        ),
    )

    frames, audio_fs = loadtest_ws.read_pcm_frames(Path("stereo-8bit.wav"))

    assert audio_fs == 8000
    assert len(frames) == 1
    assert struct.unpack("<3h", frames[0]) == (-32768, 0, 32512)


def test_read_pcm_frames_resamples_unsupported_sample_rate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    samples = struct.pack("<441h", *range(441))
    monkeypatch.setattr(
        loadtest_ws.wave,
        "open",
        lambda *_args, **_kwargs: FakeWaveReader(
            channels=1,
            sample_width=2,
            sample_rate=44100,
            frames=samples,
        ),
    )

    frames, audio_fs = loadtest_ws.read_pcm_frames(Path("mono-44k.wav"))

    assert audio_fs == 16000
    assert sum(len(frame) for frame in frames) == 320


def test_build_init_payload_enables_server_vad_for_all_modes() -> None:
    payload = loadtest_ws.build_init_payload(
        mode="online",
        wav_name="demo",
        audio_fs=16000,
        server_vad_enabled=True,
        server_vad_silence_ms=450,
    )

    assert payload["mode"] == "online"
    assert payload["wav_name"] == "demo"
    assert payload["turn_detection"] == {
        "type": "server_vad",
        "silence_duration_ms": 450,
    }


def test_build_init_payload_skips_server_vad_when_disabled() -> None:
    payload = loadtest_ws.build_init_payload(
        mode="online",
        wav_name="demo",
        audio_fs=16000,
        server_vad_enabled=False,
        server_vad_silence_ms=450,
    )

    assert payload["mode"] == "online"
    assert "turn_detection" not in payload


def test_wait_for_server_vad_settle_returns_after_quiet_window_when_final_exists() -> None:
    async def runner() -> tuple[list[float], list[str]]:
        final_latencies = [120.0]
        errors: list[str] = []
        listener_state = loadtest_ws.ListenerState(last_message_at=time.perf_counter())
        await loadtest_ws.wait_for_server_vad_settle(
            final_latencies=final_latencies,
            errors=errors,
            message_event=asyncio.Event(),
            listener_state=listener_state,
            final_timeout_sec=0.2,
            idle_timeout_sec=0.01,
            settle_started_at=time.perf_counter(),
        )
        return final_latencies, errors

    final_latencies, errors = asyncio.run(runner())

    assert final_latencies == [120.0]
    assert errors == []


def test_wait_for_server_vad_settle_times_out_when_no_final_arrives() -> None:
    async def runner() -> list[str]:
        errors: list[str] = []
        listener_state = loadtest_ws.ListenerState(last_message_at=time.perf_counter())
        await loadtest_ws.wait_for_server_vad_settle(
            final_latencies=[],
            errors=errors,
            message_event=asyncio.Event(),
            listener_state=listener_state,
            final_timeout_sec=0.01,
            idle_timeout_sec=0.01,
            settle_started_at=time.perf_counter(),
        )
        return errors

    errors = asyncio.run(runner())

    assert errors == ["final_timeout"]
