from __future__ import annotations

import numpy as np

from server.audio import int16_to_bytes
from server.vad import RmsVad, SilenceState, update_silence_state


class SequenceVad:
    frame_duration_ms = 20
    frame_bytes = 640

    def __init__(self, decisions: list[bool]):
        self._decisions = decisions
        self._index = 0

    def process(self, audio_bytes: bytes) -> bool:
        assert len(audio_bytes) == self.frame_bytes
        if self._index >= len(self._decisions):
            return False
        decision = self._decisions[self._index]
        self._index += 1
        return decision


def test_update_silence_state_preserves_trailing_silence_after_speech() -> None:
    vad = SequenceVad([True, False, False])
    state = SilenceState()

    update_silence_state(vad, state, b"\x00\x00" * 320 * 3)

    assert state.speech_detected is True
    assert state.consecutive_silence_ms == 40


def test_update_silence_state_resets_accumulated_silence_on_new_speech() -> None:
    vad = SequenceVad([True, False, True])
    state = SilenceState()

    update_silence_state(vad, state, b"\x00\x00" * 320 * 3)

    assert state.speech_detected is True
    assert state.consecutive_silence_ms == 0


def test_rms_vad_distinguishes_silence_from_speech_frames() -> None:
    vad = RmsVad(threshold=300.0)
    silence = np.zeros(320, dtype=np.int16)
    speech = np.full(320, 5000, dtype=np.int16)

    assert vad.process(int16_to_bytes(silence)) is False
    assert vad.process(int16_to_bytes(speech)) is True
