# websocket通信协议

## 实时语音识别

### 从客户端往服务端发送数据

#### 消息格式

配置参数与meta信息用json，音频数据采用bytes

#### 首次通信

message为（需要用json序列化）：

```text
{"mode": "2pass", "wav_name": "wav_name", "is_speaking": True, "wav_format":"pcm", "chunk_size":[5,10,5], "hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}","itn":True}
```

参数介绍：

```text
`mode`：`offline`，表示推理模式为一句话识别；`online`，表示推理模式为实时语音识别；`2pass`，目前只使用了offline，只需要兼容offline即可。
`wav_name`：表示需要推理音频文件名，可以作为日志中的请求唯一标识
`wav_format`：表示音视频文件后缀名，只支持pcm音频流
`is_speaking`：表示断句尾点，例如，vad切割点，或者一条wav结束
`chunk_size`：表示流式模型latency配置，`[5,10,5]`，表示当前音频为600ms，并且回看300ms，又看300ms。
`audio_fs`：当输入音频为pcm数据是，需要加上音频采样率参数。请采用16k采样率，2字节位深，单声道方式进行录音，否则系统内部还会有一次转换过程的消耗。录音发送的速度最好是60ms发送一次，因为模型是60ms作为一帧来进行处理的。
`hotwords`：如果使用热词，需要向服务端发送热词数据（字符串），格式必须为 "{\"阿里巴巴\":20,\"通义实验室\":30}"。其他格式（直接对象、数组、普通字符串）不兼容。
`itn`: 设置是否对最终中文识别结果启用服务端 itn，默认True。流式中间结果保持原样。


```

注：当前服务会把热词词条映射到 Qwen `context` 做增强，数值权重仅做格式兼容，不等价实现 FunASR/FST 热词权重语义。当前 `qwen-asr` Python API 没有原生 `itn` 参数，`itn` 由本服务在最终文本阶段补做中文归一化。

#### 连接建立后更新热词

message为（需要用json序列化）：

```text
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}"}
```

如果需要在更新热词后立即结束当前段，可以同包发送：

```text
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}","is_speaking":False}
```

#### 发送音频数据

直接将音频数据，移除头部信息后的bytes数据发送，支持音频采样率为8000（`message`中需要指定`audio_fs`为8000），16000

#### 发送结束标志

音频数据发送结束后，需要发送结束标志（需要用json序列化）：

```text
{"is_speaking": False}
```

### 从服务端往客户端发数据

#### 发送识别结果

message为（采用json序列化）

```text
{"mode": "2pass-online", "wav_name": "wav_name", "text": "asr ouputs", "is_final": True}
```

参数介绍：

```text
`mode`：表示推理模式，分为`2pass-online`，表示实时识别结果；`2pass-offline`，表示2遍修正识别结果。用offline时没有中间结果返回，只有一句一句的最终结果返回。  online时速度快，有中间结果，但是识别结果就是中间结果的拼接，没有offline好。 2pass就是online和offline的合体，online用来产生中间结果，offline用来产生最终结果。 如果希望字往外面蹦，并且识别效果好的话，就选2pass，2pass相对其他2种会慢一点。
需要注意的是如果text为""，mode字段不一定存在，也就是说mode字段不存在时，只需要关心is_final是不是true。
因为这个字段的复杂性，目前只是采用了offline的方式，没有关心返回的mode值，或是有没有mode这个key，目前是把所有返回消息的text进行了拼接。只需要在用户请求是offline时，兼容该结果即可。其他模型是可以对协议进行变更，不需要兼容。
`wav_name`：表示需要推理音频文件名
`text`：表示语音识别输出文本
`is_final`：表示识别结束
`timestamp`：如果AM为时间戳模型，会返回此字段，表示时间戳，格式为 "[[100,200], [200,500]]"(ms)
`stamp_sents`：如果AM为时间戳模型，会返回此字段，表示句子级别时间戳，格式为 [{"text_seg":"正 是 因 为","punc":",","start":430,"end":1130,"ts_list":[[430,670],[670,810],[810,1030],[1030,1130]]}]
```
