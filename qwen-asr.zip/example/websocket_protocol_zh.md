# websocket通信协议

## 实时语音识别

### 从客户端往服务端发送数据

#### 消息格式

配置参数与meta信息用json，音频数据采用bytes

#### 首次通信

message为（需要用json序列化）：

```text
{"mode": "2pass", "wav_name": "wav_name", "is_speaking": True, "wav_format":"pcm", "chunk_size":[5,10,5], "hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}","itn":True,"turn_detection":{"type":"server_vad","silence_duration_ms":600}}
```

参数介绍：

```text
`mode`：`offline` 表示离线句级识别；`online` 表示实时识别；`2pass` 表示同时返回流式结果和句级离线修正结果。
`wav_name`：表示需要推理音频文件名，可以作为日志中的请求唯一标识
`wav_format`：表示音视频文件后缀名，只支持pcm音频流
`is_speaking`：客户端显式结束当前 segment 时发送 `False`，连接保持打开，可继续发送下一段音频
`chunk_size`：表示流式模型latency配置，`[5,10,5]`，表示当前音频为600ms，并且回看300ms，又看300ms。
`audio_fs`：当输入音频为pcm数据是，需要加上音频采样率参数。请采用16k采样率，2字节位深，单声道方式进行录音，否则系统内部还会有一次转换过程的消耗。录音发送的速度最好是60ms发送一次，因为模型是60ms作为一帧来进行处理的。
`hotwords`：如果使用热词，需要向服务端发送热词数据（字符串），格式必须为 "{\"阿里巴巴\":20,\"通义实验室\":30}"。其他格式（直接对象、数组、普通字符串）不兼容。
`itn`: 设置是否对最终中文识别结果启用服务端 itn，默认True。流式中间结果保持原样。
`turn_detection`：默认开启 `server_vad`。如果要显式关闭，发送 `{"type":"none"}`。


```

注：当前服务会把热词词条映射到 Qwen `context` 做增强，数值权重仅做格式兼容，不等价实现 FunASR/FST 热词权重语义。当前 `qwen-asr` Python API 没有原生 `itn` 参数，`itn` 由本服务在最终文本阶段补做中文归一化。

#### 连接建立后更新热词

message为（需要用json序列化）：

```text
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}"}
```

如果需要在更新热词后立即结束当前 segment，可以同包发送：

```text
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}","is_speaking":False}
```

#### 发送音频数据

直接将音频数据，移除头部信息后的bytes数据发送，支持音频采样率为8000（`message`中需要指定`audio_fs`为8000），16000

#### 发送结束标志

当前 segment 音频发送结束后，需要发送结束标志（需要用json序列化）：

```text
{"is_speaking": False}
```

### 从服务端往客户端发数据

#### 发送识别结果

识别结果 message 为（采用json序列化）

```text
{"mode": "2pass-online", "wav_name": "wav_name", "text": "asr outputs", "is_final": False}
{"mode": "2pass-offline", "wav_name": "wav_name", "text": "完整句子", "is_final": True}
```

参数介绍：

```text
`mode`：服务端回包只使用 `2pass-online` 和 `2pass-offline`。`2pass-online` 表示流式中间结果；`2pass-offline` 表示句级离线修正结果。`offline` 请求也会按句返回 `2pass-offline`。
`wav_name`：表示需要推理音频文件名
`text`：表示语音识别输出文本
`is_final`：表示当前 segment 的最终结果。客户端发送 `{"is_speaking": false}` 后，服务端返回该 segment 的完整最终文本，并置 `is_final=true`。
`timestamp`：如果AM为时间戳模型，会返回此字段，表示时间戳，格式为 "[[100,200], [200,500]]"(ms)
`stamp_sents`：如果AM为时间戳模型，会返回此字段，表示句子级别时间戳，格式为 [{"text_seg":"正 是 因 为","punc":",","start":430,"end":1130,"ts_list":[[430,670],[670,810],[810,1030],[1030,1130]]}]
```
