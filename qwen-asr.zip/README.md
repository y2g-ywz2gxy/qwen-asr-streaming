# Qwen3-ASR WebSocket 服务

基于 `Qwen3-ASR-1.7B` 的 WebSocket 语音识别服务，提供 `offline`、`online`、`2pass` 三种模式，以及热词、中文最终结果 `itn`、浏览器调试页、健康检查和压测脚本。

## 主要能力

- 支持 `offline`、`online`、`2pass`
- 支持单连接多段识别
- 支持中文最终结果 `itn`
- 提供 `GET /healthz`、`GET /metrics`、浏览器调试页
- 提供测试与压测脚本

`2pass` 的行为是：

- 流式阶段返回中间结果，回包 `mode=2pass-online`
- 句末阶段对整段音频再做一次离线识别，回包 `mode=2pass-offline`

## 项目结构

- `server/app.py`：FastAPI 与 WebSocket 入口
- `server/engine.py`：推理调度与会话管理
- `server/protocol.py`：协议解析与回包格式
- `server/audio.py`：PCM 处理与音频工具
- `server/vad.py`：可选服务端 VAD
- `frontend/index.html`：浏览器调试页面
- `tests/`：测试与压测脚本

## 快速开始

环境要求：

- Python 3.10+
- NVIDIA 驱动与 CUDA 环境
- 本地可用的 `Qwen3-ASR-1.7B` 模型目录，或按下文步骤下载

推荐使用 Makefile：

```bash
make venv
make install
cp config/example.env .env
make download-model
make run
```

`make download-model` 会先执行 `make install`，因为模型下载命令依赖已安装的 `modelscope`。

手动启动：

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip setuptools wheel
pip install -r requirements.txt
pip install -U qwen-asr[vllm]
cp config/example.env .env
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
python -m server.app --host 0.0.0.0 --port 8001
```

默认模型目录：

```text
./models/Qwen3-ASR-1.7B
```

如果不使用 `make download-model`，请在完成依赖安装后手动下载模型：

```bash
mkdir -p models
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
```

如果 `modelscope download` 报错 `No module named 'pkg_resources'`，执行：

```bash
.venv/bin/pip install -U setuptools wheel
```

## Docker 启动

Docker 方式不会在容器内下载模型。执行 `docker compose up` 前，请先在宿主机准备好完整模型目录，并让 `MODEL_PATH_HOST` 指向该目录。

```bash
cp config/docker.env.example .env
mkdir -p logs
docker compose build
docker compose up -d
```

如果模型还没下载，请先在宿主机按上文方式完成下载；如果模型在仓库外，再修改 `.env` 中的：

```bash
MODEL_PATH_HOST=/absolute/path/to/Qwen3-ASR-1.7B
MODEL_PATH=/models/Qwen3-ASR-1.7B
```

常用命令：

```bash
docker compose ps
docker compose logs -f
docker compose down
```

## 服务入口

- `GET /`：浏览器调试页面
- `GET /healthz`：健康检查
- `GET /metrics`：运行指标
- `WS /ws/asr`：识别入口

## 协议摘要

发送顺序：

1. 发送首包 JSON 配置
2. 发送 PCM `bytes`
3. 每段结束发送 `{"is_speaking": false}`

首包示例：

```json
{
  "mode": "2pass",
  "wav_name": "demo-session",
  "is_speaking": true,
  "wav_format": "pcm",
  "audio_fs": 16000,
  "chunk_size": [5, 10, 5],
  "hotwords": "{\"阿里巴巴\":20,\"通义实验室\":30}",
  "itn": true
}
```

约束：

- `wav_format` 只支持 `pcm`
- `audio_fs` 只支持 `8000` 或 `16000`
- 推荐输入 `16kHz / 16-bit / 单声道`
- 推荐按约 `60ms` 的节奏发送音频帧
- `hotwords` 只兼容字符串对象格式，例如 `"{\"阿里巴巴\":20,\"通义实验室\":30}"`
- `itn=true` 时，仅对最终中文结果做归一化，流式中间结果保持原样

连接建立后可以动态更新热词：

```json
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}"}
```

也可以与断句结束一起发送：

```json
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}","is_speaking":false}
```

说明：

- 热词会映射到 Qwen `context` 做增强
- 热词权重仅做格式兼容，不等价于 FunASR/FST 热词权重语义
- 当前 `qwen-asr` Python API 没有原生 `itn` 参数，`itn` 由服务端在最终文本阶段处理

回包策略：

- `offline`：只返回最终结果
- `online`：返回中间结果和最终结果
- `2pass`：返回 `2pass-online` 中间结果，句末返回 `2pass-offline` 最终结果

## 测试与压测

```bash
make test
make loadtest LOADTEST_WAV=./sample.wav
make loadtest LOADTEST_WAV=./sample.wav LOADTEST_SERVER_VAD=1
```

## 更多说明

- 部署、配置、排障、压测：`docs/deploy.md`
- 协议示例：`example/websocket_protocol_zh.md`
