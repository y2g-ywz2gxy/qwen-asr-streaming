# Qwen3-ASR WebSocket 服务

基于 `Qwen3-ASR-1.7B` 的 WebSocket 语音识别服务，提供 `offline`、`online`、`2pass` 三种模式，以及热词、中文最终结果 `itn`、浏览器调试页、健康检查和压测脚本。

## 主要能力

- 支持 `offline`、`online`、`2pass`
- 默认开启服务端 VAD，支持按句返回
- 支持中文最终结果 `itn`
- 提供 `GET /healthz`、`GET /ready`、`GET /metrics`、浏览器调试页
- 提供测试与压测脚本

`2pass` 的行为是：

- 流式阶段返回中间结果，回包 `mode=2pass-online`
- 句末阶段对整段音频再做一次离线识别，回包 `mode=2pass-offline`

## 项目结构

- `server/app.py`：FastAPI 与 WebSocket 入口
- `server/engine.py`：推理调度与会话管理
- `server/protocol.py`：协议解析与回包格式
- `server/audio.py`：PCM 处理与音频工具
- `server/vad.py`：服务端 VAD 与静音切分
- `frontend/index.html`：浏览器调试页面
- `tests/`：测试与压测脚本

## 快速开始

环境要求：

- Python 3.10+
- NVIDIA 驱动与 CUDA 环境
- 本地可用的 `Qwen3-ASR-1.7B` 模型目录，或按下文步骤下载
- 已验证基线：`Tesla V100-SXM2-32GB / Driver 535.129.03 / CUDA 12.2`
- 固定运行时版本：`qwen-asr 0.0.6`、`vllm 0.14.0`、`torch 2.9.1`、`torchaudio 2.9.1`、`torchvision 0.24.1`

运行时兼容说明：

- `V100` 属于 `SM 7.0`，项目默认走 `VLLM_ATTENTION_BACKEND=TORCH_SDPA`
- 默认关闭 `FlashInfer sampler`，即 `VLLM_USE_FLASHINFER_SAMPLER=0`
- `make run` 和 Docker 容器启动前都会先执行 `python -m server.runtime_check`

推荐使用 Makefile：

```bash
make venv
make install
cp config/example.env .env
make download-model
make run
```

`make download-model` 会先执行 `make install`，因为模型下载命令依赖已安装的 `modelscope`。

手动启动：

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip setuptools wheel
pip install -r requirements.runtime-gpu.txt
cp config/example.env .env
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
python -m server.runtime_check
python -m server.app --host 0.0.0.0 --port 8001
```

推荐先执行一次运行时自检：

```bash
.venv/bin/python -m server.runtime_check
```

通过时会输出当前 Python 包版本、`torch.version.cuda`、GPU 名称、compute capability，以及最终生效的 vLLM backend。

默认模型目录：

```text
./models/Qwen3-ASR-1.7B
```

如果不使用 `make download-model`，请在完成依赖安装后手动下载模型：

```bash
mkdir -p models
.venv/bin/modelscope download --model Qwen/Qwen3-ASR-1.7B --local_dir ./models/Qwen3-ASR-1.7B
```

如果 `modelscope download` 报错 `No module named 'pkg_resources'`，执行：

```bash
.venv/bin/pip install -U setuptools wheel
```

## Docker 启动

Docker 方式不会在容器内下载模型。执行 `docker compose up` 前，请先在宿主机准备好完整模型目录，并让 `MODEL_PATH_HOST` 指向该目录。

默认基础镜像已固定到经 V100 验证的 digest，而不是浮动 `latest`。

```bash
cp config/docker.env.example .env
mkdir -p logs
docker compose build
docker compose up -d
```

容器启动时会自动执行一次运行时自检；如果版本不匹配、GPU 不可见，或 V100 上误配了不安全 backend，容器会直接退出。

推荐的 V100 `.env` 基线：

```bash
GPU_MEMORY_UTILIZATION=0.8
VLLM_ATTENTION_BACKEND=TORCH_SDPA
VLLM_USE_FLASHINFER_SAMPLER=0
MAX_MODEL_LEN=4096
MAX_SESSIONS=8
```

如果模型还没下载，请先在宿主机按上文方式完成下载；如果模型在仓库外，再修改 `.env` 中的：

```bash
MODEL_PATH_HOST=/absolute/path/to/Qwen3-ASR-1.7B
MODEL_PATH=/models/Qwen3-ASR-1.7B
```

常用命令：

```bash
docker compose ps
docker compose logs -f
docker compose down
```

## 服务入口

- `GET /`：浏览器调试页面
- `GET /healthz`：健康检查
- `GET /ready`：就绪检查，返回内容与 `GET /healthz` 相同
- `GET /metrics`：运行指标
- `WS /ws/asr`：识别入口

## 协议摘要

发送顺序：

1. 发送首包 JSON 配置
2. 发送 PCM `bytes`
3. 如需手动结束当前 segment 或冲刷尾部音频，发送 `{"is_speaking": false}`

协议语义变化：

- 请求 `mode` 用来决定服务端内部运行策略，不直接决定回包里的 `mode` 字面值
- 回包 `mode` 只使用 `2pass-online` 和 `2pass-offline`
- `is_speaking=false` 只结束当前 segment，不关闭 WebSocket 连接
- `is_final=true` 表示当前 segment 的最终结果

首包示例：

```json
{
  "mode": "2pass",
  "wav_name": "demo-session",
  "is_speaking": true,
  "wav_format": "pcm",
  "audio_fs": 16000,
  "chunk_size": [5, 10, 5],
  "hotwords": "{\"阿里巴巴\":20,\"通义实验室\":30}",
  "itn": true,
  "turn_detection": {"type": "server_vad", "silence_duration_ms": 600}
}
```

约束：

- `wav_format` 只支持 `pcm`
- `audio_fs` 只支持 `8000` 或 `16000`
- 推荐输入 `16kHz / 16-bit / 单声道`
- 推荐按约 `60ms` 的节奏发送音频帧
- `hotwords` 只兼容字符串对象格式，例如 `"{\"阿里巴巴\":20,\"通义实验室\":30}"`
- `itn=true` 时，仅对最终中文结果做归一化，流式中间结果保持原样
- 默认开启 `server_vad`；如果要关闭，首包显式传 `{"turn_detection":{"type":"none"}}`

连接建立后可以动态更新热词：

```json
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}"}
```

也可以与断句结束一起发送：

```json
{"hotwords":"{\"阿里巴巴\":20,\"通义实验室\":30}","is_speaking":false}
```

说明：

- 热词会映射到 Qwen `context` 做增强
- 热词权重仅做格式兼容，不等价于 FunASR/FST 热词权重语义
- 当前 `qwen-asr` Python API 没有原生 `itn` 参数，`itn` 由服务端在最终文本阶段处理
- 开启 `server_vad` 时，连续静音达到 `silence_duration_ms` 会自动结束当前 segment；`max_segment_ms` 只作为兜底上限

请求与回包关系：

| 请求 `mode` | 运行方式 | 自动切段时的句级结果 | 手动 `{"is_speaking": false}` 的最终回包 |
| --- | --- | --- | --- |
| `offline` | 只做离线识别 | `mode=2pass-offline, is_final=false` | `mode=2pass-offline, is_final=true` |
| `online` | 只做流式识别 | `mode=2pass-online, is_final=false` | `mode=2pass-online, is_final=true` |
| `2pass` | 同时做流式和离线识别 | `mode=2pass-offline, is_final=false` | `mode=2pass-offline, is_final=true` |

回包策略：

- `2pass-online` 表示流式中间结果
- `2pass-offline` 表示句级离线修正结果；`offline` 和 `2pass` 都会按句返回这一类消息
- 开启 `server_vad` 时，服务端会在检测到静音阈值后自动返回当前 segment 的句级结果；这类自动切段结果通常 `is_final=false`
- 客户端显式发送 `{"is_speaking": false}` 时，服务端会返回当前 segment 的完整最终结果，并置 `is_final=true`
- 服务端不会再额外发送空的结束确认包；需要结束整个 WebSocket 会话时由客户端主动关闭连接

典型回包序列：

```text
{"mode":"2pass-online","wav_name":"demo","text":"今天天气","is_final":false}
{"mode":"2pass-offline","wav_name":"demo","text":"今天天气不错","is_final":false}
{"mode":"2pass-offline","wav_name":"demo","text":"我们出发吧","is_final":true}
```

理解方式：

- `mode=2pass-online` 且 `is_final=false` 时，更新流式中间文本
- 收到 `mode=2pass-offline` 或 `is_final=true` 时，将该条消息作为一个完整 segment 结果处理
- 收到 `is_final=true` 后不要自动断开连接；如果还要继续识别，客户端可以在同一 WebSocket 上继续发送下一段音频

## 测试与压测

```bash
make test
make loadtest LOADTEST_WAV=./sample.wav
make loadtest LOADTEST_WAV=./sample.wav LOADTEST_SERVER_VAD=0
```

说明：

- `make loadtest` 默认开启服务端 VAD
- 如果要验证“仅依赖客户端发送 `{"is_speaking": false}` 才结束”的行为，使用 `LOADTEST_SERVER_VAD=0`

## 更多说明

- 部署、配置、排障、压测：`docs/deploy.md`
- 协议示例：`example/websocket_protocol_zh.md`
