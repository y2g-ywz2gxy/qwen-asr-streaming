from __future__ import annotations

import argparse
import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse

from server.audio import INTERNAL_SAMPLE_RATE, normalize_pcm_bytes, pcm_duration_ms
from server.engine import BackendError, InferenceWorker
from server.hotwords import MISSING, ParsedHotwords, summarize_hotwords
from server.logging_utils import configure_logging, log_event
from server.protocol import (
    ProtocolError,
    format_response,
    is_heartbeat,
    parse_init_message,
    parse_hotwords_value,
    parse_json_text,
    RUNTIME_CONTROL_KEYS,
)
from server.settings import AppSettings, SessionConfig
from server.vad import SilenceState, create_vad, update_silence_state


LOGGER = logging.getLogger(__name__)
ACCESS_LOGGER = logging.getLogger("access")
MAX_LOG_TEXT_CHARS = 200


@dataclass(slots=True)
class ConnectionState:
    session_id: str
    config: SessionConfig
    byte_buffer: bytearray = field(default_factory=bytearray)
    segment_active: bool = False
    last_partial_text: str = ""
    silence_state: SilenceState = field(default_factory=SilenceState)
    last_activity_at: float = field(default_factory=time.time)
    total_segment_ms: int = 0
    vad: object | None = None
    segments_completed: int = 0

    @property
    def step_bytes(self) -> int:
        return INTERNAL_SAMPLE_RATE * self.config.step_ms // 1000 * 2


def compact_text(value: str | None, limit: int = MAX_LOG_TEXT_CHARS) -> str:
    if not value:
        return ""
    compact = " ".join(value.split())
    if len(compact) <= limit:
        return compact
    return f"{compact[: limit - 3]}..."


def session_log_context(state: ConnectionState | None) -> dict[str, Any]:
    if state is None:
        return {}
    return {
        "session_id": state.session_id,
        "wav_name": state.config.wav_name,
        "mode": state.config.mode,
        "segment_index": state.segments_completed + 1,
    }


def init_payload_summary(payload: dict[str, Any]) -> dict[str, Any]:
    turn_detection = payload.get("turn_detection")
    turn_detection_summary: dict[str, Any] | None = None
    hotword_summary = summarize_hotwords(
        payload["hotwords"] if "hotwords" in payload else MISSING
    )
    if isinstance(turn_detection, dict):
        turn_detection_summary = {
            "type": turn_detection.get("type"),
            "silence_duration_ms": turn_detection.get("silence_duration_ms"),
            "max_segment_ms": turn_detection.get("max_segment_ms"),
            "aggressiveness": turn_detection.get("aggressiveness"),
        }
    return {
        "mode": payload.get("mode"),
        "wav_name": payload.get("wav_name"),
        "wav_format": payload.get("wav_format"),
        "audio_fs": payload.get("audio_fs"),
        "chunk_size": payload.get("chunk_size"),
        "itn": payload.get("itn"),
        "has_hotwords": hotword_summary["has_hotwords"],
        "hotword_count": hotword_summary["hotword_count"],
        "hotword_terms_preview": hotword_summary["hotword_terms_preview"],
        "hotwords_error": hotword_summary.get("hotwords_error"),
        "turn_detection": turn_detection_summary,
    }


def outbound_payload_summary(payload: dict[str, Any]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "event": payload.get("event"),
        "code": payload.get("code"),
        "mode": payload.get("mode"),
        "wav_name": payload.get("wav_name"),
        "is_final": payload.get("is_final"),
    }
    if "message" in payload:
        message = str(payload.get("message") or "")
        summary["message"] = compact_text(message)
        summary["message_len"] = len(message)
    if "text" in payload:
        text = str(payload.get("text") or "")
        summary["text"] = compact_text(text)
        summary["text_len"] = len(text)
    return summary


def hotword_summary_fields(parsed_hotwords: ParsedHotwords) -> dict[str, Any]:
    return {
        "hotwords_present": bool(parsed_hotwords.terms),
        "hotword_count": len(parsed_hotwords.terms),
        "hotword_terms_preview": list(parsed_hotwords.terms[:3]),
    }


def log_outbound_payload(
    event_name: str,
    payload: dict[str, Any],
    state: ConnectionState | None = None,
    level: int = logging.INFO,
) -> None:
    LOGGER.log(
        level,
        event_name,
        extra={
            "extra_data": {
                **session_log_context(state),
                "payload": outbound_payload_summary(payload),
            }
        },
    )


def create_app(
    settings: AppSettings | None = None,
    backend_factory=None,
) -> FastAPI:
    app_settings = settings or AppSettings()
    configure_logging(app_settings)
    worker = InferenceWorker(app_settings, backend_factory=backend_factory)
    app = FastAPI(title="Qwen3-ASR WebSocket Service")
    app.state.settings = app_settings
    app.state.worker = worker
    app.state.active_connections = 0
    app.state.completed_segments = 0
    app.state.rejected_sessions = 0
    app.state.error_count = 0

    @app.on_event("startup")
    async def startup() -> None:
        await worker.start()
        log_event(LOGGER, "service_started", model_path=app_settings.model_path, port=app_settings.port)

    @app.on_event("shutdown")
    async def shutdown() -> None:
        await worker.stop()
        log_event(LOGGER, "service_stopped")

    @app.get("/", response_class=HTMLResponse)
    async def index() -> HTMLResponse:
        frontend_path = app_settings.frontend_path
        if frontend_path.exists():
            return HTMLResponse(frontend_path.read_text(encoding="utf-8"))
        return HTMLResponse("<h1>Qwen3-ASR service is running.</h1>")

    @app.get("/healthz")
    async def healthz() -> JSONResponse:
        return JSONResponse(
            {
                "status": "ok",
                "active_connections": app.state.active_connections,
                "completed_segments": app.state.completed_segments,
                "max_sessions": app_settings.default_max_sessions,
            }
        )

    @app.get("/metrics")
    async def metrics() -> JSONResponse:
        engine_metrics = await worker.metrics()
        return JSONResponse(
            {
                "active_connections": app.state.active_connections,
                "completed_segments": app.state.completed_segments,
                "rejected_sessions": app.state.rejected_sessions,
                "errors": app.state.error_count,
                "engine": engine_metrics,
            }
        )

    @app.websocket("/ws/asr")
    async def websocket_asr(websocket: WebSocket) -> None:
        await websocket.accept()
        app.state.active_connections += 1
        session_state: ConnectionState | None = None
        try:
            if app.state.active_connections > app_settings.default_max_sessions:
                app.state.rejected_sessions += 1
                await send_error(
                    websocket,
                    "MAX_SESSIONS",
                    "max sessions reached",
                    close_code=1013,
                )
                return
            session_state = await receive_init(websocket, worker, app_settings)
            ACCESS_LOGGER.info(
                "session_connected",
                extra={
                    "extra_data": {
                        "session_id": session_state.session_id,
                        "wav_name": session_state.config.wav_name,
                        "mode": session_state.config.mode,
                    }
                },
            )
            while True:
                try:
                    message = await asyncio.wait_for(
                        websocket.receive(),
                        timeout=app_settings.connection_idle_timeout_sec,
                    )
                except asyncio.TimeoutError:
                    LOGGER.warning(
                        "connection_idle_timeout",
                        extra={"extra_data": session_log_context(session_state)},
                    )
                    await send_error(
                        websocket,
                        "IDLE_TIMEOUT",
                        "connection idle timeout",
                        close_code=1000,
                        state=session_state,
                    )
                    return
                if message.get("type") == "websocket.disconnect":
                    break
                if "text" in message:
                    text = message["text"]
                    if is_heartbeat(text):
                        log_event(LOGGER, "heartbeat_echo", **session_log_context(session_state))
                        await websocket.send_text("HeartBeat")
                        continue
                    payload = parse_json_text(text)
                    if not payload:
                        raise ProtocolError(
                            "UNEXPECTED_TEXT",
                            "only hotwords updates and is_speaking control are allowed after init",
                        )
                    unexpected_keys = set(payload) - RUNTIME_CONTROL_KEYS
                    if unexpected_keys:
                        raise ProtocolError(
                            "UNEXPECTED_TEXT",
                            "only hotwords updates and is_speaking control are allowed after init",
                        )
                    hotwords_updated = False
                    if "hotwords" in payload:
                        parsed_hotwords = parse_hotwords_value(payload["hotwords"])
                        log_event(
                            LOGGER,
                            "hotwords_update_received",
                            **session_log_context(session_state),
                            **hotword_summary_fields(parsed_hotwords),
                        )
                        await worker.update_hotwords(
                            session_state.session_id,
                            parsed_hotwords,
                        )
                        hotwords_updated = True
                    if payload.get("is_speaking") is False:
                        log_event(
                            LOGGER,
                            "segment_end_received",
                            **session_log_context(session_state),
                            payload={"is_speaking": False},
                        )
                        await finalize_and_emit(websocket, worker, session_state)
                        continue
                    if hotwords_updated or payload.get("is_speaking") is True:
                        session_state.last_activity_at = time.time()
                        continue
                    raise ProtocolError(
                        "UNEXPECTED_TEXT",
                        "only hotwords updates and is_speaking control are allowed after init",
                    )
                if "bytes" in message:
                    audio_bytes = message["bytes"] or b""
                    if not audio_bytes:
                        continue
                    await handle_audio(websocket, worker, session_state, audio_bytes)
                    continue
        except WebSocketDisconnect:
            pass
        except ProtocolError as exc:
            app.state.error_count += 1
            LOGGER.warning(
                "websocket_protocol_error",
                extra={
                    "extra_data": {
                        **session_log_context(session_state),
                        "error_code": exc.code,
                        "message": exc.message,
                    }
                },
            )
            await send_error(
                websocket,
                exc.code,
                exc.message,
                close_code=1008,
                state=session_state,
            )
        except BackendError as exc:
            app.state.error_count += 1
            LOGGER.error(
                "websocket_backend_error",
                extra={
                    "extra_data": {
                        **session_log_context(session_state),
                        "message": str(exc),
                    }
                },
            )
            await send_error(
                websocket,
                "BACKEND_ERROR",
                str(exc),
                close_code=1011,
                state=session_state,
                level=logging.ERROR,
            )
        except Exception as exc:
            app.state.error_count += 1
            LOGGER.exception(
                "unhandled_websocket_error",
                extra={"extra_data": session_log_context(session_state)},
            )
            try:
                await send_error(
                    websocket,
                    "INTERNAL_ERROR",
                    str(exc),
                    close_code=1011,
                    state=session_state,
                    level=logging.ERROR,
                )
            except Exception:
                pass
        finally:
            app.state.active_connections = max(0, app.state.active_connections - 1)
            if session_state is not None:
                await worker.close_session(session_state.session_id)
                ACCESS_LOGGER.info(
                    "session_disconnected",
                    extra={
                        "extra_data": {
                            "session_id": session_state.session_id,
                            "wav_name": session_state.config.wav_name,
                            "mode": session_state.config.mode,
                            "segments_completed": session_state.segments_completed,
                        }
                    },
                )
                log_event(
                    LOGGER,
                    "session_closed",
                    session_id=session_state.session_id,
                    wav_name=session_state.config.wav_name,
                    segments_completed=session_state.segments_completed,
                )

    return app


async def receive_init(
    websocket: WebSocket,
    worker: InferenceWorker,
    settings: AppSettings,
) -> ConnectionState:
    raw_message = await asyncio.wait_for(
        websocket.receive_text(), timeout=settings.connection_idle_timeout_sec
    )
    if is_heartbeat(raw_message):
        await websocket.send_text("HeartBeat")
        raw_message = await asyncio.wait_for(
            websocket.receive_text(), timeout=settings.connection_idle_timeout_sec
        )
    payload = parse_json_text(raw_message)
    log_event(LOGGER, "init_message_received", payload=init_payload_summary(payload))
    config = parse_init_message(raw_message)
    session_id = uuid.uuid4().hex
    await worker.open_session(session_id, config)
    connection = ConnectionState(session_id=session_id, config=config)
    if config.turn_detection.enabled:
        connection.vad = create_vad(config.turn_detection.aggressiveness)
    log_event(
        LOGGER,
        "session_initialized",
        session_id=session_id,
        wav_name=config.wav_name,
        mode=config.mode,
        audio_fs=config.audio_fs,
        chunk_size=config.chunk_size,
        hotwords_present=bool(config.hotword_terms),
        hotword_count=len(config.hotword_terms),
        hotword_terms_preview=list(config.hotword_terms[:3]),
        turn_detection={
            "enabled": config.turn_detection.enabled,
            "silence_duration_ms": config.turn_detection.silence_duration_ms,
            "max_segment_ms": config.turn_detection.max_segment_ms,
            "aggressiveness": config.turn_detection.aggressiveness,
        },
    )
    return connection


async def handle_audio(
    websocket: WebSocket,
    worker: InferenceWorker,
    state: ConnectionState,
    audio_bytes: bytes,
) -> None:
    app = websocket.scope["app"]
    normalized_bytes = normalize_pcm_bytes(audio_bytes, state.config.audio_fs)
    if not normalized_bytes:
        return
    projected_buffer_ms = pcm_duration_ms(bytes(state.byte_buffer) + normalized_bytes)
    if projected_buffer_ms > app.state.settings.max_buffer_ms:
        raise ProtocolError("BUFFER_OVERFLOW", "client is sending audio faster than the server can consume")
    state.last_activity_at = time.time()
    state.segment_active = True
    state.byte_buffer.extend(normalized_bytes)
    while len(state.byte_buffer) >= state.step_bytes:
        chunk = bytes(state.byte_buffer[: state.step_bytes])
        del state.byte_buffer[: state.step_bytes]
        await process_chunk(websocket, worker, state, chunk)


async def process_chunk(
    websocket: WebSocket,
    worker: InferenceWorker,
    state: ConnectionState,
    chunk: bytes,
) -> None:
    state.segment_active = True
    state.total_segment_ms += pcm_duration_ms(chunk)
    chunk_index = max(1, state.total_segment_ms // state.config.step_ms)
    log_event(
        LOGGER,
        "audio_chunk_processed",
        **session_log_context(state),
        chunk_index=int(chunk_index),
        chunk_bytes=len(chunk),
        chunk_ms=pcm_duration_ms(chunk),
        buffered_segment_ms=state.total_segment_ms,
    )
    if state.vad is not None:
        update_silence_state(state.vad, state.silence_state, chunk)
    result = await worker.process_stream_chunk(state.session_id, chunk)
    if (
        state.config.streaming_enabled
        and result.text
        and result.text != state.last_partial_text
    ):
        state.last_partial_text = result.text
        payload = format_response(
            state.config.mode,
            state.config.wav_name,
            result.text,
            is_final=False,
        )
        log_outbound_payload("ws_partial_sent", payload, state=state)
        await websocket.send_json(payload)
    should_auto_finalize = False
    if state.vad is not None:
        should_auto_finalize = (
            state.silence_state.speech_detected
            and state.silence_state.consecutive_silence_ms
            >= state.config.turn_detection.silence_duration_ms
        )
    if state.total_segment_ms >= state.config.turn_detection.max_segment_ms:
        should_auto_finalize = True
    if should_auto_finalize:
        log_event(
            LOGGER,
            "segment_auto_finalize_triggered",
            **session_log_context(state),
            silence_ms=state.silence_state.consecutive_silence_ms,
            total_segment_ms=state.total_segment_ms,
        )
        await finalize_and_emit(websocket, worker, state)


async def finalize_and_emit(
    websocket: WebSocket,
    worker: InferenceWorker,
    state: ConnectionState,
) -> None:
    app = websocket.scope["app"]
    if state.byte_buffer:
        chunk = bytes(state.byte_buffer)
        state.byte_buffer.clear()
        state.total_segment_ms += pcm_duration_ms(chunk)
        log_event(
            LOGGER,
            "segment_tail_flushed",
            **session_log_context(state),
            chunk_bytes=len(chunk),
            chunk_ms=pcm_duration_ms(chunk),
            buffered_segment_ms=state.total_segment_ms,
        )
        result = await worker.process_stream_chunk(state.session_id, chunk)
        if (
            state.config.streaming_enabled
            and result.text
            and result.text != state.last_partial_text
        ):
            state.last_partial_text = result.text
            payload = format_response(
                state.config.mode,
                state.config.wav_name,
                result.text,
                is_final=False,
            )
            log_outbound_payload("ws_partial_sent", payload, state=state)
            await websocket.send_json(payload)
    if not state.segment_active:
        return
    final_result = await worker.finalize_segment(state.session_id)
    payload = format_response(
        state.config.mode,
        state.config.wav_name,
        final_result.text,
        is_final=True,
    )
    log_outbound_payload("ws_final_sent", payload, state=state)
    await websocket.send_json(payload)
    state.segment_active = False
    state.total_segment_ms = 0
    state.last_partial_text = ""
    state.silence_state = SilenceState()
    state.segments_completed += 1
    app.state.completed_segments += 1


async def send_error(
    websocket: WebSocket,
    code: str,
    message: str,
    close_code: int,
    state: ConnectionState | None = None,
    level: int = logging.WARNING,
) -> None:
    payload = {"event": "error", "code": code, "message": message}
    log_outbound_payload("ws_error_sent", payload, state=state, level=level)
    await websocket.send_json(payload)
    await websocket.close(code=close_code)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Qwen3-ASR WebSocket server.")
    parser.add_argument("--host", default=None)
    parser.add_argument("--port", type=int, default=None)
    args = parser.parse_args()

    settings = AppSettings()
    if args.host:
        settings.host = args.host
    if args.port:
        settings.port = args.port

    import uvicorn

    uvicorn.run(create_app(settings=settings), host=settings.host, port=settings.port)


app = create_app()


if __name__ == "__main__":
    main()
