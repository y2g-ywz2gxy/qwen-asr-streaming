from __future__ import annotations

import json
import logging
from logging.handlers import RotatingFileHandler
from typing import Any

from server.settings import AppSettings


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        extra = getattr(record, "extra_data", None)
        if isinstance(extra, dict):
            payload.update(extra)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


class MinLevelFilter(logging.Filter):
    def __init__(self, min_level: int):
        super().__init__()
        self._min_level = min_level

    def filter(self, record: logging.LogRecord) -> bool:
        return record.levelno >= self._min_level


def configure_logging(settings: AppSettings) -> None:
    settings.logs_dir.mkdir(parents=True, exist_ok=True)
    service_log = settings.logs_dir / "service.log"
    access_log = settings.logs_dir / "access.log"
    error_log = settings.logs_dir / "error.log"

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    for handler in root.handlers:
        handler.close()
    root.handlers.clear()

    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    console.setLevel(logging.INFO)

    service_handler = RotatingFileHandler(
        service_log,
        maxBytes=settings.log_rotate_max_bytes,
        backupCount=settings.log_backup_count,
        encoding="utf-8",
    )
    service_handler.setFormatter(JsonFormatter())
    service_handler.setLevel(logging.INFO)

    error_handler = RotatingFileHandler(
        error_log,
        maxBytes=settings.log_rotate_max_bytes,
        backupCount=settings.log_backup_count,
        encoding="utf-8",
    )
    error_handler.setFormatter(JsonFormatter())
    error_handler.setLevel(logging.WARNING)
    error_handler.addFilter(MinLevelFilter(logging.WARNING))

    access_handler = RotatingFileHandler(
        access_log,
        maxBytes=settings.log_rotate_max_bytes,
        backupCount=settings.log_backup_count,
        encoding="utf-8",
    )
    access_handler.setFormatter(JsonFormatter())
    access_handler.setLevel(logging.INFO)

    root.addHandler(console)
    root.addHandler(service_handler)
    root.addHandler(error_handler)

    access_logger = logging.getLogger("access")
    access_logger.setLevel(logging.INFO)
    for handler in access_logger.handlers:
        handler.close()
    access_logger.handlers.clear()
    access_logger.addHandler(access_handler)
    access_logger.propagate = False


def log_event(logger: logging.Logger, message: str, **extra_data: Any) -> None:
    logger.info(message, extra={"extra_data": extra_data})
