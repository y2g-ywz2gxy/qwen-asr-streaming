from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from server.hotwords import HotwordError, ParsedHotwords, parse_hotwords
from server.settings import SessionConfig, build_session_config


class ProtocolError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


SUPPORTED_MODES = {"offline", "online", "2pass"}
SUPPORTED_SAMPLE_RATES = {8000, 16000}
RUNTIME_CONTROL_KEYS = {"hotwords", "is_speaking"}


@dataclass(slots=True)
class ResultMessage:
    wav_name: str
    text: str
    is_final: bool
    mode: str | None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "wav_name": self.wav_name,
            "text": self.text,
            "is_final": self.is_final,
        }
        if self.mode:
            payload["mode"] = self.mode
        return payload


def parse_json_text(text: str) -> dict[str, Any]:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ProtocolError("INVALID_JSON", "message is not valid JSON") from exc
    if not isinstance(payload, dict):
        raise ProtocolError("INVALID_JSON", "message must be a JSON object")
    return payload


def parse_init_message(text: str) -> SessionConfig:
    payload = parse_json_text(text)
    mode = payload.get("mode")
    wav_name = payload.get("wav_name")
    wav_format = payload.get("wav_format", "pcm")
    chunk_size = payload.get("chunk_size", [5, 10, 5])
    try:
        audio_fs = int(payload.get("audio_fs", 16_000))
    except (TypeError, ValueError) as exc:
        raise ProtocolError("INVALID_SAMPLE_RATE", "audio_fs must be 8000 or 16000") from exc

    if mode not in SUPPORTED_MODES:
        raise ProtocolError("INVALID_MODE", "mode must be offline, online, or 2pass")
    if not wav_name:
        raise ProtocolError("MISSING_WAV_NAME", "wav_name is required")
    if wav_format != "pcm":
        raise ProtocolError("INVALID_FORMAT", "wav_format must be pcm")
    if audio_fs not in SUPPORTED_SAMPLE_RATES:
        raise ProtocolError("INVALID_SAMPLE_RATE", "audio_fs must be 8000 or 16000")
    if (
        not isinstance(chunk_size, list)
        or len(chunk_size) != 3
        or any(int(item) <= 0 for item in chunk_size)
    ):
        raise ProtocolError("INVALID_CHUNK_SIZE", "chunk_size must contain 3 positive ints")
    is_speaking = payload.get("is_speaking", True)
    if is_speaking is False:
        raise ProtocolError("INVALID_INIT_STATE", "init message must not end a segment")
    try:
        return build_session_config(payload)
    except HotwordError as exc:
        raise ProtocolError("INVALID_HOTWORDS", str(exc)) from exc


def is_heartbeat(text: str) -> bool:
    return text == "HeartBeat"


def is_segment_end(payload: dict[str, Any]) -> bool:
    return payload.get("is_speaking") is False


def parse_hotwords_value(value: Any) -> ParsedHotwords:
    try:
        return parse_hotwords(value)
    except HotwordError as exc:
        raise ProtocolError("INVALID_HOTWORDS", str(exc)) from exc


def format_response(mode: str, wav_name: str, text: str, is_final: bool) -> dict[str, Any]:
    response_mode: str | None
    if not text and is_final:
        response_mode = None
    elif mode == "2pass":
        response_mode = "2pass-offline" if is_final else "2pass-online"
    else:
        response_mode = mode
    return ResultMessage(
        wav_name=wav_name,
        text=text,
        is_final=is_final,
        mode=response_mode,
    ).to_payload()
