from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from server.hotwords import MISSING, ParsedHotwords, parse_hotwords


PROJECT_ROOT = Path(__file__).resolve().parents[1]

try:
    from dotenv import load_dotenv

    load_dotenv(PROJECT_ROOT / ".env")
except ImportError:
    pass


def optional_int_env(name: str) -> int | None:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return None
    return int(raw)


@dataclass(slots=True)
class TurnDetectionConfig:
    enabled: bool = False
    silence_duration_ms: int = 600
    max_segment_ms: int = 20_000
    aggressiveness: int = 2


@dataclass(slots=True)
class SessionConfig:
    mode: str
    wav_name: str
    wav_format: str
    audio_fs: int
    chunk_size: list[int]
    itn: bool = True
    hotwords: str | None = None
    hotword_terms: tuple[str, ...] = ()
    hotword_context: str = ""
    turn_detection: TurnDetectionConfig = field(default_factory=TurnDetectionConfig)

    @property
    def streaming_enabled(self) -> bool:
        return self.mode in {"online", "2pass"}

    @property
    def offline_enabled(self) -> bool:
        return self.mode in {"offline", "2pass"}

    @property
    def step_ms(self) -> int:
        return int(self.chunk_size[1] * 60)


def apply_hotwords(config: SessionConfig, parsed_hotwords: ParsedHotwords) -> None:
    config.hotwords = parsed_hotwords.raw
    config.hotword_terms = parsed_hotwords.terms
    config.hotword_context = parsed_hotwords.context


@dataclass(slots=True)
class AppSettings:
    model_path: str = os.environ.get(
        "MODEL_PATH", str(PROJECT_ROOT / "models" / "Qwen3-ASR-1.7B")
    )
    host: str = os.environ.get("WS_HOST", "0.0.0.0")
    port: int = int(os.environ.get("WS_PORT", "8001"))
    gpu_memory_utilization: float = float(
        os.environ.get("GPU_MEMORY_UTILIZATION", "0.8")
    )
    max_model_len: int | None = optional_int_env("MAX_MODEL_LEN")
    connection_idle_timeout_sec: int = int(
        os.environ.get("CONNECTION_IDLE_TIMEOUT_SEC", "60")
    )
    default_max_sessions: int = int(os.environ.get("MAX_SESSIONS", "8"))
    executor_shutdown_timeout_sec: int = int(
        os.environ.get("EXECUTOR_SHUTDOWN_TIMEOUT_SEC", "10")
    )
    logs_dir: Path = Path(os.environ.get("LOGS_DIR", str(PROJECT_ROOT / "logs")))
    log_rotate_max_bytes: int = int(
        os.environ.get("LOG_ROTATE_MAX_BYTES", str(100 * 1024 * 1024))
    )
    log_backup_count: int = int(os.environ.get("LOG_BACKUP_COUNT", "10"))
    frontend_path: Path = Path(
        os.environ.get("FRONTEND_PATH", str(PROJECT_ROOT / "frontend" / "index.html"))
    )
    warmup_enabled: bool = os.environ.get("WARMUP_ENABLED", "1") != "0"
    metric_history_size: int = int(os.environ.get("METRIC_HISTORY_SIZE", "256"))
    max_buffer_ms: int = int(os.environ.get("MAX_BUFFER_MS", "3000"))
    max_pending_tasks_per_session: int = int(
        os.environ.get("MAX_PENDING_TASKS_PER_SESSION", "8")
    )


def build_session_config(payload: dict[str, Any]) -> SessionConfig:
    chunk_size = payload.get("chunk_size") or [5, 10, 5]
    turn_detection_payload = payload.get("turn_detection") or {}
    parsed_hotwords = parse_hotwords(payload["hotwords"] if "hotwords" in payload else MISSING)
    turn_detection = TurnDetectionConfig(
        enabled=turn_detection_payload.get("type") == "server_vad",
        silence_duration_ms=int(
            turn_detection_payload.get("silence_duration_ms", 600)
        ),
        max_segment_ms=int(turn_detection_payload.get("max_segment_ms", 20_000)),
        aggressiveness=int(turn_detection_payload.get("aggressiveness", 2)),
    )
    return SessionConfig(
        mode=str(payload["mode"]),
        wav_name=str(payload["wav_name"]),
        wav_format=str(payload.get("wav_format", "pcm")),
        audio_fs=int(payload.get("audio_fs", 16_000)),
        chunk_size=[int(item) for item in chunk_size],
        itn=bool(payload.get("itn", True)),
        hotwords=parsed_hotwords.raw,
        hotword_terms=parsed_hotwords.terms,
        hotword_context=parsed_hotwords.context,
        turn_detection=turn_detection,
    )
