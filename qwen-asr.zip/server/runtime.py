from __future__ import annotations

import importlib
import os
import platform
from dataclasses import dataclass, field
from importlib.metadata import PackageNotFoundError, version
from typing import Any


EXPECTED_RUNTIME_PACKAGES: dict[str, str] = {
    "qwen-asr": "0.0.6",
    "vllm": "0.14.0",
    "torch": "2.9.1",
    "torchaudio": "2.9.1",
    "torchvision": "0.24.1",
}
MIN_VLLM_COMPUTE_CAPABILITY = (7, 0)
MIN_FLASHINFER_COMPUTE_CAPABILITY = (7, 5)
SAFE_ATTENTION_BACKEND = "TORCH_SDPA"
SAFE_FLASHINFER_SAMPLER = "0"


class RuntimeValidationError(RuntimeError):
    pass


@dataclass(slots=True)
class RuntimeInfo:
    python_version: str
    package_versions: dict[str, str | None] = field(default_factory=dict)
    torch_available: bool = False
    torch_cuda_version: str | None = None
    gpu_available: bool = False
    gpu_count: int = 0
    gpu_name: str | None = None
    capability_major: int | None = None
    capability_minor: int | None = None
    attention_backend: str | None = None
    attention_backend_source: str = "unset"
    flashinfer_sampler: str | None = None
    flashinfer_sampler_source: str = "unset"

    @property
    def capability(self) -> str | None:
        if self.capability_major is None or self.capability_minor is None:
            return None
        return f"{self.capability_major}.{self.capability_minor}"

    @property
    def capability_tuple(self) -> tuple[int, int] | None:
        if self.capability_major is None or self.capability_minor is None:
            return None
        return (self.capability_major, self.capability_minor)

    def as_log_fields(self) -> dict[str, Any]:
        return {
            "python_version": self.python_version,
            "package_versions": self.package_versions,
            "torch_available": self.torch_available,
            "torch_cuda_version": self.torch_cuda_version,
            "gpu_available": self.gpu_available,
            "gpu_count": self.gpu_count,
            "gpu_name": self.gpu_name,
            "gpu_compute_capability": self.capability,
            "vllm_attention_backend": self.attention_backend,
            "vllm_attention_backend_source": self.attention_backend_source,
            "vllm_use_flashinfer_sampler": self.flashinfer_sampler,
            "vllm_use_flashinfer_sampler_source": self.flashinfer_sampler_source,
        }


def get_installed_package_versions() -> dict[str, str | None]:
    versions: dict[str, str | None] = {}
    for package_name in EXPECTED_RUNTIME_PACKAGES:
        try:
            versions[package_name] = version(package_name)
        except PackageNotFoundError:
            versions[package_name] = None
    return versions


def validate_installed_package_versions() -> dict[str, str]:
    installed = get_installed_package_versions()
    mismatches: list[str] = []
    resolved: dict[str, str] = {}
    for package_name, expected in EXPECTED_RUNTIME_PACKAGES.items():
        actual = installed.get(package_name)
        if actual != expected:
            mismatches.append(f"{package_name}={actual or 'missing'} (expected {expected})")
            continue
        resolved[package_name] = expected
    if mismatches:
        raise RuntimeValidationError(
            "runtime package versions do not match the supported V100 baseline: "
            + ", ".join(mismatches)
        )
    return resolved


def detect_runtime() -> RuntimeInfo:
    info = RuntimeInfo(
        python_version=platform.python_version(),
        package_versions=get_installed_package_versions(),
    )
    try:
        torch = importlib.import_module("torch")
    except ImportError:
        return info

    info.torch_available = True
    info.torch_cuda_version = getattr(getattr(torch, "version", None), "cuda", None)
    cuda = getattr(torch, "cuda", None)
    if cuda is None:
        return info
    try:
        info.gpu_available = bool(cuda.is_available())
    except Exception:
        return info
    if not info.gpu_available:
        return info
    try:
        info.gpu_count = int(cuda.device_count())
    except Exception:
        info.gpu_count = 0
    try:
        info.gpu_name = str(cuda.get_device_name(0))
    except Exception:
        info.gpu_name = None
    try:
        major, minor = cuda.get_device_capability(0)
        info.capability_major = int(major)
        info.capability_minor = int(minor)
    except Exception:
        info.capability_major = None
        info.capability_minor = None
    return info


def prepare_runtime_environment() -> RuntimeInfo:
    info = detect_runtime()
    backend_source = "env" if os.environ.get("VLLM_ATTENTION_BACKEND") else "unset"
    sampler_source = "env" if os.environ.get("VLLM_USE_FLASHINFER_SAMPLER") is not None else "unset"
    capability = info.capability_tuple
    if info.gpu_available and capability is not None and capability < MIN_FLASHINFER_COMPUTE_CAPABILITY:
        if not os.environ.get("VLLM_ATTENTION_BACKEND"):
            os.environ["VLLM_ATTENTION_BACKEND"] = SAFE_ATTENTION_BACKEND
            backend_source = "auto_v100_compat"
        if os.environ.get("VLLM_USE_FLASHINFER_SAMPLER") is None:
            os.environ["VLLM_USE_FLASHINFER_SAMPLER"] = SAFE_FLASHINFER_SAMPLER
            sampler_source = "auto_v100_compat"
    info.attention_backend = os.environ.get("VLLM_ATTENTION_BACKEND")
    info.attention_backend_source = backend_source
    info.flashinfer_sampler = os.environ.get("VLLM_USE_FLASHINFER_SAMPLER")
    info.flashinfer_sampler_source = sampler_source
    return info


def is_feature_enabled(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() not in {"", "0", "false", "no", "off"}


def validate_runtime_configuration(
    info: RuntimeInfo,
    *,
    allow_no_gpu: bool = False,
) -> None:
    if not info.torch_available:
        raise RuntimeValidationError("torch is not importable")
    if not info.gpu_available:
        if allow_no_gpu:
            return
        raise RuntimeValidationError("no CUDA GPU is available")
    capability = info.capability_tuple
    if capability is None:
        raise RuntimeValidationError("unable to determine GPU compute capability")
    if capability < MIN_VLLM_COMPUTE_CAPABILITY:
        raise RuntimeValidationError(
            f"GPU compute capability {info.capability} is below the minimum {MIN_VLLM_COMPUTE_CAPABILITY[0]}.{MIN_VLLM_COMPUTE_CAPABILITY[1]} required by vLLM"
        )
    if capability < MIN_FLASHINFER_COMPUTE_CAPABILITY:
        if (info.attention_backend or "").upper() != SAFE_ATTENTION_BACKEND:
            raise RuntimeValidationError(
                f"GPU compute capability {info.capability} requires VLLM_ATTENTION_BACKEND={SAFE_ATTENTION_BACKEND}"
            )
        if is_feature_enabled(info.flashinfer_sampler):
            raise RuntimeValidationError(
                f"GPU compute capability {info.capability} requires VLLM_USE_FLASHINFER_SAMPLER=0"
            )
