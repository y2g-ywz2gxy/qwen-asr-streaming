from __future__ import annotations

import logging
import re
from functools import lru_cache
from typing import Any


LOGGER = logging.getLogger(__name__)
MAX_LOG_TEXT_CHARS = 200
NUMERAL_CHARS = "零〇一二两三四五六七八九十百千万亿点负"
NUMERAL_SEQUENCE_PATTERN = re.compile(rf"[{NUMERAL_CHARS}]{{2,}}")
NUMERAL_UNIT_PATTERN = re.compile(
    rf"[{NUMERAL_CHARS}]+(?:年|月|日|号|点|时|分|秒|元|块|毛|角|岁|人|次|件|台|公里|千米|米|厘米|毫米|斤|周|天|小时|分钟)"
)
RATIO_PATTERN = re.compile(rf"[{NUMERAL_CHARS}]+分之[{NUMERAL_CHARS}]+")
PERCENT_PATTERN = re.compile(rf"百分之[{NUMERAL_CHARS}]+")


def compact_text(value: str | None, limit: int = MAX_LOG_TEXT_CHARS) -> str:
    if not value:
        return ""
    compact = " ".join(value.split())
    if len(compact) <= limit:
        return compact
    return f"{compact[: limit - 3]}..."


def has_chinese_itn_features(text: str) -> bool:
    if not text:
        return False
    return any(
        pattern.search(text)
        for pattern in (
            NUMERAL_SEQUENCE_PATTERN,
            NUMERAL_UNIT_PATTERN,
            RATIO_PATTERN,
            PERCENT_PATTERN,
        )
    )


@lru_cache(maxsize=1)
def _load_cn2an() -> Any:
    import cn2an

    return cn2an


def _transform_text(text: str) -> str:
    return _load_cn2an().transform(text, "cn2an")


def normalize_final_text(text: str, enabled: bool) -> str:
    if not enabled or not text:
        return text
    if not has_chinese_itn_features(text):
        return text
    try:
        return _transform_text(text)
    except Exception:
        LOGGER.warning(
            "itn_transform_failed",
            extra={
                "extra_data": {
                    "text": compact_text(text),
                    "text_len": len(text),
                }
            },
            exc_info=True,
        )
        return text
