from __future__ import annotations

import io
import wave

import numpy as np


PCM_WIDTH_BYTES = 2
INTERNAL_SAMPLE_RATE = 16_000


def bytes_to_int16(audio_bytes: bytes) -> np.ndarray:
    if len(audio_bytes) % PCM_WIDTH_BYTES != 0:
        raise ValueError("PCM payload must align to 16-bit samples")
    return np.frombuffer(audio_bytes, dtype=np.int16)


def int16_to_bytes(audio: np.ndarray) -> bytes:
    return np.asarray(audio, dtype=np.int16).tobytes()


def int16_to_float32(audio: np.ndarray) -> np.ndarray:
    return (audio.astype(np.float32) / 32768.0).astype(np.float32)


def resample_int16(audio: np.ndarray, src_rate: int, dst_rate: int) -> np.ndarray:
    if src_rate == dst_rate or audio.size == 0:
        return np.asarray(audio, dtype=np.int16)
    duration = audio.shape[0] / float(src_rate)
    dst_len = max(1, int(round(duration * dst_rate)))
    src_x = np.linspace(0.0, duration, num=audio.shape[0], endpoint=False)
    dst_x = np.linspace(0.0, duration, num=dst_len, endpoint=False)
    resampled = np.interp(dst_x, src_x, audio.astype(np.float32))
    clipped = np.clip(np.round(resampled), -32768, 32767)
    return clipped.astype(np.int16)


def normalize_pcm_bytes(audio_bytes: bytes, src_rate: int) -> bytes:
    audio = bytes_to_int16(audio_bytes)
    audio = resample_int16(audio, src_rate, INTERNAL_SAMPLE_RATE)
    return int16_to_bytes(audio)


def pcm_duration_ms(audio_bytes: bytes, sample_rate: int = INTERNAL_SAMPLE_RATE) -> int:
    sample_count = len(audio_bytes) // PCM_WIDTH_BYTES
    return int(round((sample_count / float(sample_rate)) * 1000.0))


def pcm_to_wav_bytes(audio_bytes: bytes, sample_rate: int = INTERNAL_SAMPLE_RATE) -> bytes:
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(PCM_WIDTH_BYTES)
        wav.setframerate(sample_rate)
        wav.writeframes(audio_bytes)
    return buffer.getvalue()

