"""Qwen3 ASR WebSocket service package."""

