from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from server.audio import INTERNAL_SAMPLE_RATE, bytes_to_int16

VAD_FRAME_DURATION_MS = 20
VAD_FRAME_BYTES = int(INTERNAL_SAMPLE_RATE * VAD_FRAME_DURATION_MS / 1000) * 2


@dataclass(slots=True)
class SilenceState:
    speech_detected: bool = False
    consecutive_silence_ms: int = 0


class BaseVad:
    frame_duration_ms: int = VAD_FRAME_DURATION_MS
    frame_bytes: int = VAD_FRAME_BYTES

    def process(self, audio_bytes: bytes) -> bool:
        raise NotImplementedError


class RmsVad(BaseVad):
    def __init__(self, threshold: float = 300.0):
        self.threshold = threshold

    def process(self, audio_bytes: bytes) -> bool:
        audio = bytes_to_int16(audio_bytes).astype(np.float32)
        if audio.size == 0:
            return False
        rms = float(np.sqrt(np.mean(np.square(audio))))
        return rms >= self.threshold


class WebRtcVad(BaseVad):
    def __init__(self, aggressiveness: int):
        import webrtcvad

        self.sample_rate = INTERNAL_SAMPLE_RATE
        self.vad = webrtcvad.Vad(aggressiveness)

    def process(self, audio_bytes: bytes) -> bool:
        if len(audio_bytes) < self.frame_bytes:
            return False
        return self.vad.is_speech(audio_bytes[: self.frame_bytes], self.sample_rate)


def create_vad(aggressiveness: int) -> BaseVad:
    try:
        return WebRtcVad(aggressiveness)
    except Exception:
        return RmsVad()


def process_vad_frame(vad: BaseVad, state: SilenceState, audio_bytes: bytes) -> bool:
    has_speech = vad.process(audio_bytes)
    if has_speech:
        state.speech_detected = True
        state.consecutive_silence_ms = 0
    else:
        state.consecutive_silence_ms += vad.frame_duration_ms
    return has_speech


def update_silence_state(
    vad: BaseVad, state: SilenceState, audio_bytes: bytes
) -> SilenceState:
    for start in range(0, len(audio_bytes), vad.frame_bytes):
        frame = audio_bytes[start : start + vad.frame_bytes]
        if len(frame) < vad.frame_bytes:
            break
        process_vad_frame(vad, state, frame)
    return state
