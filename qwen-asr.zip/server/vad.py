from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from server.audio import INTERNAL_SAMPLE_RATE, bytes_to_int16


@dataclass(slots=True)
class SilenceState:
    speech_detected: bool = False
    consecutive_silence_ms: int = 0


class BaseVad:
    def process(self, audio_bytes: bytes) -> tuple[bool, int]:
        raise NotImplementedError


class RmsVad(BaseVad):
    def __init__(self, threshold: float = 300.0):
        self.threshold = threshold

    def process(self, audio_bytes: bytes) -> tuple[bool, int]:
        audio = bytes_to_int16(audio_bytes).astype(np.float32)
        if audio.size == 0:
            return False, 0
        rms = float(np.sqrt(np.mean(np.square(audio))))
        duration_ms = int(round((audio.size / float(INTERNAL_SAMPLE_RATE)) * 1000.0))
        return rms >= self.threshold, duration_ms


class WebRtcVad(BaseVad):
    def __init__(self, aggressiveness: int):
        import webrtcvad

        self.sample_rate = INTERNAL_SAMPLE_RATE
        self.frame_duration_ms = 20
        self.frame_bytes = int(self.sample_rate * self.frame_duration_ms / 1000) * 2
        self.vad = webrtcvad.Vad(aggressiveness)

    def process(self, audio_bytes: bytes) -> tuple[bool, int]:
        speech = False
        silence_ms = 0
        for start in range(0, len(audio_bytes), self.frame_bytes):
            frame = audio_bytes[start : start + self.frame_bytes]
            if len(frame) < self.frame_bytes:
                break
            is_speech = self.vad.is_speech(frame, self.sample_rate)
            if is_speech:
                speech = True
                silence_ms = 0
            else:
                silence_ms += self.frame_duration_ms
        return speech, silence_ms


def create_vad(aggressiveness: int) -> BaseVad:
    try:
        return WebRtcVad(aggressiveness)
    except Exception:
        return RmsVad()


def update_silence_state(
    vad: BaseVad, state: SilenceState, audio_bytes: bytes
) -> SilenceState:
    has_speech, silence_ms = vad.process(audio_bytes)
    if has_speech:
        state.speech_detected = True
        state.consecutive_silence_ms = 0
    else:
        state.consecutive_silence_ms += silence_ms
    return state
