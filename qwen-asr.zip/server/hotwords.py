from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


MISSING = object()

HOTWORD_CONTEXT_HEADER = "以下是需要重点关注的热词和上下文短语："
HOTWORD_CONTEXT_FOOTER = "如果音频中出现这些词，请优先输出与这里一致的写法。"


class HotwordError(ValueError):
    pass


@dataclass(slots=True, frozen=True)
class ParsedHotwords:
    raw: str | None
    terms: tuple[str, ...]
    context: str


def build_hotword_context(terms: tuple[str, ...]) -> str:
    if not terms:
        return ""
    return "\n".join((HOTWORD_CONTEXT_HEADER, *terms, HOTWORD_CONTEXT_FOOTER))


def parse_hotwords(value: Any = MISSING) -> ParsedHotwords:
    if value is MISSING:
        return ParsedHotwords(raw=None, terms=(), context="")
    if not isinstance(value, str):
        raise HotwordError(
            "hotwords must be a JSON string encoded object like "
            '{"Alibaba":20,"TongyiLab":30}'
        )
    if value == "":
        return ParsedHotwords(raw=value, terms=(), context="")
    try:
        payload = json.loads(value)
    except json.JSONDecodeError as exc:
        raise HotwordError(
            "hotwords must be a JSON string encoded object like "
            '{"Alibaba":20,"TongyiLab":30}'
        ) from exc
    if not isinstance(payload, dict):
        raise HotwordError(
            "hotwords must decode to a JSON object like "
            '{"Alibaba":20,"TongyiLab":30}'
        )

    terms: list[str] = []
    seen: set[str] = set()
    for key, weight in payload.items():
        if not isinstance(key, str) or not key.strip():
            raise HotwordError("hotwords keys must be non-empty strings")
        if isinstance(weight, bool) or not isinstance(weight, (int, float)):
            raise HotwordError("hotwords weights must be numbers")
        normalized = key.strip()
        if normalized in seen:
            continue
        seen.add(normalized)
        terms.append(normalized)

    term_tuple = tuple(terms)
    return ParsedHotwords(
        raw=value,
        terms=term_tuple,
        context=build_hotword_context(term_tuple),
    )


def summarize_hotwords(value: Any = MISSING) -> dict[str, Any]:
    if value is MISSING:
        return {
            "has_hotwords": False,
            "hotword_count": 0,
            "hotword_terms_preview": [],
        }
    try:
        parsed = parse_hotwords(value)
    except HotwordError as exc:
        return {
            "has_hotwords": bool(value),
            "hotword_count": None,
            "hotword_terms_preview": [],
            "hotwords_error": str(exc),
        }
    return {
        "has_hotwords": bool(parsed.terms),
        "hotword_count": len(parsed.terms),
        "hotword_terms_preview": list(parsed.terms[:3]),
    }
