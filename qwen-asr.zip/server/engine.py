from __future__ import annotations

import asyncio
import logging
import subprocess
import time
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from statistics import mean
from typing import Any, Callable

import numpy as np

from server.audio import INTERNAL_SAMPLE_RATE, int16_to_float32, pcm_duration_ms
from server.hotwords import ParsedHotwords
from server.itn import normalize_final_text
from server.logging_utils import log_event
from server.settings import AppSettings, SessionConfig, apply_hotwords


LOGGER = logging.getLogger(__name__)
MAX_LOG_TEXT_CHARS = 200


class BackendError(RuntimeError):
    pass


def compact_text(value: str | None, limit: int = MAX_LOG_TEXT_CHARS) -> str:
    if not value:
        return ""
    compact = " ".join(value.split())
    if len(compact) <= limit:
        return compact
    return f"{compact[: limit - 3]}..."


@dataclass(slots=True)
class StreamResult:
    text: str
    language: str | None = None


class BackendProtocol:
    def warmup(self) -> None:
        raise NotImplementedError

    def create_stream_state(self, config: SessionConfig) -> Any:
        raise NotImplementedError

    def refresh_stream_context(self, state: Any, config: SessionConfig) -> Any:
        raise NotImplementedError

    def streaming_transcribe(self, pcm_bytes: bytes, state: Any) -> StreamResult:
        raise NotImplementedError

    def finish_stream(self, state: Any) -> StreamResult:
        raise NotImplementedError

    def transcribe_segment(self, pcm_bytes: bytes, config: SessionConfig) -> StreamResult:
        raise NotImplementedError


class QwenBackend(BackendProtocol):
    def __init__(self, settings: AppSettings):
        try:
            from qwen_asr import Qwen3ASRModel
        except ImportError as exc:
            raise BackendError(
                "qwen_asr is not installed. Install with: pip install \"qwen-asr[vllm]\""
            ) from exc
        self._settings = settings
        model_kwargs: dict[str, Any] = {
            "model": settings.model_path,
            "gpu_memory_utilization": settings.gpu_memory_utilization,
        }
        if settings.max_model_len is not None:
            model_kwargs["max_model_len"] = settings.max_model_len
        self._model = Qwen3ASRModel.LLM(**model_kwargs)

    def warmup(self) -> None:
        dummy = np.zeros(INTERNAL_SAMPLE_RATE, dtype=np.float32)
        state = self._init_stream_state("")
        self._model.streaming_transcribe(dummy, state)
        self._model.finish_streaming_transcribe(state)

    def _init_stream_state(self, context: str) -> Any:
        return self._model.init_streaming_state(
            context=context,
            unfixed_chunk_num=2,
            unfixed_token_num=5,
            chunk_size_sec=2.0,
        )

    def create_stream_state(self, config: SessionConfig) -> Any:
        return self._init_stream_state(config.hotword_context)

    def refresh_stream_context(self, state: Any, config: SessionConfig) -> Any:
        refreshed = self._init_stream_state(config.hotword_context)
        for attr in (
            "chunk_id",
            "buffer",
            "audio_accum",
            "language",
            "text",
            "_raw_decoded",
        ):
            if hasattr(state, attr) and hasattr(refreshed, attr):
                setattr(refreshed, attr, getattr(state, attr))
        return refreshed

    def streaming_transcribe(self, pcm_bytes: bytes, state: Any) -> StreamResult:
        audio = np.frombuffer(pcm_bytes, dtype=np.int16)
        self._model.streaming_transcribe(int16_to_float32(audio), state)
        return StreamResult(text=(state.text or "").strip(), language=getattr(state, "language", None))

    def finish_stream(self, state: Any) -> StreamResult:
        self._model.finish_streaming_transcribe(state)
        return StreamResult(text=(state.text or "").strip(), language=getattr(state, "language", None))

    def transcribe_segment(self, pcm_bytes: bytes, config: SessionConfig) -> StreamResult:
        audio = np.frombuffer(pcm_bytes, dtype=np.int16)
        float_audio = int16_to_float32(audio)
        results = self._model.transcribe(
            audio=(float_audio, INTERNAL_SAMPLE_RATE),
            context=config.hotword_context,
            return_time_stamps=False,
        )
        if isinstance(results, list) and results:
            result = results[0]
            return StreamResult(
                text=(getattr(result, "text", "") or "").strip(),
                language=getattr(result, "language", None),
            )
        raise BackendError("transcribe returned no result")


@dataclass(slots=True)
class EngineTask:
    kind: str
    session_id: str
    payload: Any | None
    future: asyncio.Future
    queued_at: float


@dataclass(slots=True)
class EngineSession:
    config: SessionConfig
    state: Any | None = None
    segment_bytes: bytearray = field(default_factory=bytearray)
    chunk_count: int = 0
    segment_index: int = 0
    last_language: str | None = None


class InferenceWorker:
    def __init__(
        self,
        settings: AppSettings,
        backend_factory: Callable[[AppSettings], BackendProtocol] | None = None,
    ):
        self.settings = settings
        self._backend_factory = backend_factory or QwenBackend
        self._backend: BackendProtocol | None = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="asr-worker")
        self._queue_event = asyncio.Event()
        self._ready_sessions: deque[str] = deque()
        self._session_order: set[str] = set()
        self._session_queues: dict[str, deque[EngineTask]] = defaultdict(deque)
        self._sessions: dict[str, EngineSession] = {}
        self._scheduler_task: asyncio.Task | None = None
        self._stopping = False
        self._recent_stream_ms: deque[float] = deque(maxlen=settings.metric_history_size)
        self._recent_finalize_ms: deque[float] = deque(maxlen=settings.metric_history_size)

    async def start(self) -> None:
        loop = asyncio.get_running_loop()
        self._backend = await loop.run_in_executor(self._executor, self._init_backend)
        self._scheduler_task = asyncio.create_task(self._scheduler_loop(), name="asr-scheduler")

    def _init_backend(self) -> BackendProtocol:
        backend = self._backend_factory(self.settings)
        if self.settings.warmup_enabled:
            backend.warmup()
        return backend

    async def stop(self) -> None:
        self._stopping = True
        self._queue_event.set()
        if self._scheduler_task:
            await self._scheduler_task
        self._executor.shutdown(wait=True, cancel_futures=True)

    async def open_session(self, session_id: str, config: SessionConfig) -> None:
        if session_id in self._sessions:
            raise BackendError(f"session {session_id} already exists")
        self._sessions[session_id] = EngineSession(config=config)
        if config.streaming_enabled:
            state = await self._run_blocking(
                "open",
                session_id,
                lambda: self._create_stream_state(config),
            )
            self._sessions[session_id].state = state
        log_event(
            LOGGER,
            "session_opened",
            session_id=session_id,
            wav_name=config.wav_name,
            mode=config.mode,
            audio_fs=config.audio_fs,
            itn=config.itn,
            hotwords_supported=True,
            hotwords_present=bool(config.hotword_terms),
            hotword_count=len(config.hotword_terms),
            hotword_terms_preview=list(config.hotword_terms[:3]),
        )

    async def process_stream_chunk(self, session_id: str, audio_bytes: bytes) -> StreamResult:
        session = self._sessions[session_id]
        session.segment_bytes.extend(audio_bytes)
        session.chunk_count += 1
        if not session.config.streaming_enabled:
            return StreamResult(text="", language=session.last_language)
        return await self._submit_task("stream", session_id, audio_bytes)

    async def finalize_segment(self, session_id: str) -> StreamResult:
        return await self._submit_task("finalize", session_id, None)

    async def update_hotwords(
        self, session_id: str, parsed_hotwords: ParsedHotwords
    ) -> None:
        await self._submit_task("hotwords", session_id, parsed_hotwords)

    async def close_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)
        self._session_queues.pop(session_id, None)
        self._session_order.discard(session_id)

    async def metrics(self) -> dict[str, Any]:
        return {
            "active_sessions": len(self._sessions),
            "pending_tasks": sum(len(queue) for queue in self._session_queues.values()),
            "recent_stream_ms_avg": round(mean(self._recent_stream_ms), 2)
            if self._recent_stream_ms
            else 0.0,
            "recent_finalize_ms_avg": round(mean(self._recent_finalize_ms), 2)
            if self._recent_finalize_ms
            else 0.0,
            "gpu": await asyncio.get_running_loop().run_in_executor(
                None, query_gpu_stats
            ),
        }

    async def _run_blocking(
        self, kind: str, session_id: str, fn: Callable[[], Any]
    ) -> Any:
        start = time.perf_counter()
        result = await asyncio.get_running_loop().run_in_executor(self._executor, fn)
        elapsed_ms = (time.perf_counter() - start) * 1000.0
        if kind == "stream":
            self._recent_stream_ms.append(elapsed_ms)
        elif kind == "finalize":
            self._recent_finalize_ms.append(elapsed_ms)
        log_event(LOGGER, "engine_task_done", kind=kind, session_id=session_id, elapsed_ms=round(elapsed_ms, 2))
        return result

    async def _submit_task(
        self, kind: str, session_id: str, payload: Any | None
    ) -> Any:
        loop = asyncio.get_running_loop()
        future: asyncio.Future = loop.create_future()
        queue = self._session_queues[session_id]
        if len(queue) >= self.settings.max_pending_tasks_per_session:
            raise BackendError("session task queue is full")
        queue.append(
            EngineTask(
                kind=kind,
                session_id=session_id,
                payload=payload,
                future=future,
                queued_at=time.perf_counter(),
            )
        )
        if session_id not in self._session_order:
            self._ready_sessions.append(session_id)
            self._session_order.add(session_id)
        self._queue_event.set()
        return await future

    async def _scheduler_loop(self) -> None:
        while not self._stopping:
            await self._queue_event.wait()
            self._queue_event.clear()
            while self._ready_sessions:
                session_id = self._ready_sessions.popleft()
                self._session_order.discard(session_id)
                queue = self._session_queues.get(session_id)
                if not queue:
                    continue
                task = queue.popleft()
                if queue:
                    self._ready_sessions.append(session_id)
                    self._session_order.add(session_id)
                try:
                    result = await self._execute_task(task)
                    if not task.future.done():
                        task.future.set_result(result)
                except Exception as exc:
                    if not task.future.done():
                        task.future.set_exception(exc)

    async def _execute_task(self, task: EngineTask) -> Any:
        session = self._sessions[task.session_id]
        queue_ms = (time.perf_counter() - task.queued_at) * 1000.0
        log_event(
            LOGGER,
            "engine_task_start",
            session_id=task.session_id,
            kind=task.kind,
            queue_ms=round(queue_ms, 2),
        )
        if task.kind == "stream":
            return await self._run_blocking(
                "stream",
                task.session_id,
                lambda: self._stream_blocking(session, task.payload or b""),
            )
        if task.kind == "finalize":
            return await self._run_blocking(
                "finalize",
                task.session_id,
                lambda: self._finalize_blocking(task.session_id, session),
            )
        if task.kind == "hotwords":
            return await self._run_blocking(
                "hotwords",
                task.session_id,
                lambda: self._update_hotwords_blocking(
                    task.session_id,
                    session,
                    task.payload,
                ),
            )
        raise BackendError(f"unknown task kind: {task.kind}")

    def _create_stream_state(self, config: SessionConfig) -> Any:
        if self._backend is None:
            raise BackendError("backend is not initialized")
        return self._backend.create_stream_state(config)

    def _update_hotwords_blocking(
        self,
        session_id: str,
        session: EngineSession,
        parsed_hotwords: Any,
    ) -> None:
        if self._backend is None:
            raise BackendError("backend is not initialized")
        if not isinstance(parsed_hotwords, ParsedHotwords):
            raise BackendError("invalid hotwords payload")

        apply_hotwords(session.config, parsed_hotwords)
        if session.config.streaming_enabled and session.state is not None:
            session.state = self._backend.refresh_stream_context(
                session.state,
                session.config,
            )
        log_event(
            LOGGER,
            "session_hotwords_updated",
            session_id=session_id,
            wav_name=session.config.wav_name,
            mode=session.config.mode,
            hotwords_present=bool(session.config.hotword_terms),
            hotword_count=len(session.config.hotword_terms),
            hotword_terms_preview=list(session.config.hotword_terms[:3]),
            hotword_context=compact_text(session.config.hotword_context),
        )

    def _stream_blocking(self, session: EngineSession, audio_bytes: bytes) -> StreamResult:
        if self._backend is None or session.state is None:
            raise BackendError("stream state is not initialized")
        result = self._backend.streaming_transcribe(audio_bytes, session.state)
        session.last_language = result.language or session.last_language
        return result

    def _finalize_blocking(self, session_id: str, session: EngineSession) -> StreamResult:
        if self._backend is None:
            raise BackendError("backend is not initialized")
        if not session.segment_bytes:
            return StreamResult(text="", language=session.last_language)
        segment_bytes = bytes(session.segment_bytes)
        segment_duration_ms = pcm_duration_ms(segment_bytes)
        segment_index = session.segment_index + 1
        log_event(
            LOGGER,
            "segment_finalize_start",
            session_id=session_id,
            wav_name=session.config.wav_name,
            mode=session.config.mode,
            segment_index=segment_index,
            chunk_count=session.chunk_count,
            audio_bytes=len(segment_bytes),
            audio_ms=segment_duration_ms,
        )
        if session.config.mode == "offline":
            result = self._backend.transcribe_segment(segment_bytes, session.config)
        elif session.config.mode == "online":
            if session.state is None:
                raise BackendError("stream state is not initialized")
            result = self._backend.finish_stream(session.state)
        else:
            if session.state is None:
                raise BackendError("stream state is not initialized")
            self._backend.finish_stream(session.state)
            result = self._backend.transcribe_segment(segment_bytes, session.config)
        result = StreamResult(
            text=normalize_final_text(result.text, enabled=session.config.itn),
            language=result.language,
        )
        session.segment_index += 1
        session.chunk_count = 0
        session.segment_bytes.clear()
        session.last_language = result.language or session.last_language
        if session.config.streaming_enabled:
            session.state = self._backend.create_stream_state(session.config)
        log_event(
            LOGGER,
            "segment_finalize_done",
            session_id=session_id,
            wav_name=session.config.wav_name,
            mode=session.config.mode,
            segment_index=session.segment_index,
            text=compact_text(result.text),
            text_len=len(result.text),
            language=result.language,
        )
        return result


def query_gpu_stats() -> dict[str, float]:
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=memory.used,memory.total,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            used, total, util = result.stdout.strip().split(",")
            return {
                "memory_used_mb": float(used),
                "memory_total_mb": float(total),
                "utilization_pct": float(util),
            }
    except Exception:
        pass
    return {
        "memory_used_mb": 0.0,
        "memory_total_mb": 0.0,
        "utilization_pct": 0.0,
    }
