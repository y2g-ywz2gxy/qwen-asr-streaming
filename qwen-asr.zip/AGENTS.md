# Repository Guidelines

## Project Structure & Module Organization
Primary application code lives in `server/`. Key modules include `app.py` for the FastAPI/WebSocket entrypoint, `engine.py` for inference orchestration, `protocol.py` for message parsing, and `settings.py` for environment-backed configuration. Browser debugging assets live in `frontend/index.html`. Tests are under `tests/` and currently cover protocol parsing and WebSocket flows; `tests/loadtest_ws.py` is for manual load testing, not unit coverage. Deployment notes are in `docs/deploy.md`, example clients are in `example/`, and `config/example.env` is the baseline for local `.env` files. Treat `models/` and `logs/` as runtime data, not source.

## Build, Test, and Development Commands
Use the Makefile targets instead of ad hoc commands when possible:

- `make venv`: create `.venv` and upgrade `pip`, `setuptools`, and `wheel`.
- `make install`: install `requirements.txt` and `qwen-asr[vllm]`.
- `make run`: start the service on `WS_HOST`/`WS_PORT` from `.env`.
- `make test`: run `pytest tests/test_protocol.py tests/test_app.py`.
- `make loadtest LOADTEST_WAV=./sample.wav`: exercise `ws://127.0.0.1:8001/ws/asr`.
- `make clean`: remove `__pycache__` and `.pytest_cache`.

For manual startup, copy `config/example.env` to `.env`, then run `python -m server.app --host 0.0.0.0 --port 8001`.

## Coding Style & Naming Conventions
Follow the existing Python style: 4-space indentation, type hints on public functions, dataclasses for structured state, and `snake_case` for modules, functions, and variables. Keep classes in `PascalCase` and tests named `test_*`. No formatter or linter config is committed here, so match the surrounding code closely and keep imports grouped as standard library, third-party, then local modules.

## Testing Guidelines
Add or update pytest coverage with every behavior change in `server/`. Prefer focused unit tests beside protocol or settings changes, and WebSocket integration tests in `tests/test_app.py` for session flow changes. Run `make test` before opening a PR; use `python tests/loadtest_ws.py ...` when changing buffering, concurrency, or protocol timing.

## Commit & Pull Request Guidelines
This workspace does not include accessible `.git` history, so no local commit convention can be inferred. Use short imperative commit subjects such as `server: tighten init message validation`. PRs should describe the user-visible change, list config impacts, mention test coverage, and include request/response samples or UI screenshots when touching `frontend/` or the WebSocket protocol.

## Configuration & Assets
Keep secrets in `.env` only; never commit real credentials or machine-specific paths. Large model files belong under `models/` or an external path referenced by `MODEL_PATH`. Do not commit generated logs, caches, or downloaded weights unless the change explicitly updates repository fixtures.
